<?php

/*
  Plugin Name: Order Limitation
  Plugin URI: http://
  Description: Promera webshop extra functions
  Version: 0.1.0
  Author: Peter Schveitzer / WBS
  Author URI: http://
  Text Domain: promera
  Domain Path: /languages
 */

function get_user_product_ids($user_id) {
    global $wpdb;
    $product_ids = array();
    $sql = "
    SELECT t.`meta_value` AS 'prod_id' FROM `{$wpdb->prefix}woocommerce_order_itemmeta` AS t
    LEFT JOIN `{$wpdb->prefix}woocommerce_order_items` AS t2 ON t2.`order_item_id` = t.`order_item_id`
    WHERE t.`meta_key` = '_product_id'
        AND t2.`order_item_type` = 'line_item'
        AND t2.`order_id` IN (
            SELECT t5.`ID` FROM `{$wpdb->prefix}users` AS t3
                LEFT JOIN `{$wpdb->prefix}postmeta` AS t4 ON t3.`ID` = t4.`meta_value`
                LEFT JOIN `{$wpdb->prefix}posts` AS t5 ON t5.`ID` = t4.`post_id`
                WHERE t5.`post_type` = 'shop_order'
                    AND t5.`post_status` NOT IN ('wc-cancelled')
                    AND t4.`meta_key` = '_customer_user'
                    AND t3.`ID` = {$user_id})";
    $obj = $wpdb->get_results($sql, 'ARRAY_A');
    foreach ($obj as $v) {
        $product_ids[] = $v['prod_id'];
    }
    return $product_ids;
}

function get_billing_product_ids($address) {
    global $wpdb;
    $product_ids = array();
    $sql = "
    SELECT t.`meta_value` AS 'prod_id' FROM `{$wpdb->prefix}woocommerce_order_itemmeta` AS t
    LEFT JOIN `{$wpdb->prefix}woocommerce_order_items` AS t2 ON t2.`order_item_id` = t.`order_item_id`
    WHERE t.`meta_key` = '_product_id'
        AND t2.`order_item_type` = 'line_item'
        AND t2.`order_id` IN (
            SELECT t5.`ID` FROM `{$wpdb->prefix}users` AS t3
                LEFT JOIN `{$wpdb->prefix}postmeta` AS t4 ON t3.`ID` = t4.`meta_value`
                LEFT JOIN `{$wpdb->prefix}posts` AS t5 ON t5.`ID` = t4.`post_id`
                WHERE t5.`post_type` = 'shop_order'
                    AND t5.`post_status` NOT IN ('wc-cancelled')
                    AND t4.`meta_key` = '_customer_user'
                    AND t3.`ID` = {$user_id})";
    $obj = $wpdb->get_results($sql, 'ARRAY_A');
    foreach ($obj as $v) {
        $product_ids[] = $v['prod_id'];
    }
    return $product_ids;
}

add_action('woocommerce_before_cart', 'order_limitation_as_cart', 10, 2);
add_action('woocommerce_before_checkout_form', 'order_limitation_as_checkout', 10, 2);
add_filter('woocommerce_checkout_process', 'order_limitation_as_checkout_process', 10, 2);

function order_limitation_as_pre() {
    $on_sale_item_ids = array();
    $order_history = get_user_product_ids(get_current_user_id());
    $order_history = array_unique($order_history);
    //print_r($order_history);exit;
    foreach (WC()->cart->get_cart() as $cart_item) {
        /* @var $prod WC_Product_Simple */
        $prod = $cart_item['data'];
        if ($prod->get_sold_individually() == 'abs') {
            $on_sale_item_ids[] = $prod->get_id();
        }
    }
    $result = array_intersect($order_history, $on_sale_item_ids);
    if ($result != null) {
        $msg = '<div><font color="red">Egy vagy több olyan akciós termék van a kosarában amiből korábban már rendelt! Csak az akciós termék(ek) kosárból történő eltávolítása után folytathatja a fizetést.</font><br>Eltávolítandó termék(ek):<br><ul>';
        foreach ($result as $v) {
            $product = wc_get_product($v);
            $msg .= '<li>' . $product->get_title() . '</li>';
        }
        print $msg . '</ul></div>';
    }
    return $result;
}

function order_limitation_as_cart() {
    $result = order_limitation_as_pre();
    if ($result != null) {
        // XXX ha kell valami extra
    }
}

function order_limitation_as_checkout() {
    $result = order_limitation_as_pre();
    if ($result != null) {
        global $woocommerce;
        wp_redirect($woocommerce->cart->get_cart_url());
        exit;
    }
}

function order_limitation_as_checkout_process() {
    $on_sale_item_ids = array();
    foreach (WC()->cart->get_cart() as $cart_item) {
        /* @var $prod WC_Product_Simple */
        $prod = $cart_item['data'];
        if ($prod->get_sold_individually() == 'abs') {
            $on_sale_item_ids[] = $prod->get_id();
        }
    }
    if (!empty($on_sale_item_ids)) {
        $orders = wc_get_orders(
                array(
                    'billing_postcode' => $_POST['billing_postcode'],
                    'billing_city' => $_POST['billing_city'],
                    'billing_address_1' => $_POST['billing_address_1'],
                    'billing_address_2' => $_POST['billing_address_2'],
                    'billing_address_3' => $_POST['billing_address_3'],
                    'billing_address_4' => $_POST['billing_address_4'],
                )
        );
        $order_history = array();
        /* @var $order WC_Order */
        foreach ($orders as $order) {
            foreach ($order->get_items() as $item_data) {
                /* @var $product WC_Product */
                $product = $item_data->get_product();
                if ($product) {
                    if (in_array($product->get_id(), $on_sale_item_ids)) {
                        $order_history[] = $product->get_id();
                    }
                }
            }
        }
        $order_history = array_unique($order_history);
        if (!empty($order_history)) {
            foreach ($order_history as $pid) {
                wc_add_notice('A lentebb kijelölt akciós limitált termék(ek) van(ak) a kosarában amiből korábban már rendelt! Ezen termék(ek) kosárból történő eltávolítása után folytathatja a fizetést.', 'error', 'error__cartitem_prod_' . $pid . '__r' . rand(1000, 9999));
            }
        }
    }
}
