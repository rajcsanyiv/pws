<?php

include_once('Barcode_InstallIndicator.php');

class Barcode_LifeCycle extends Barcode_InstallIndicator {

    public function install() {

        $this->initOptions();
        $this->otherInstall();
        $this->saveInstalledVersion();
        $this->markAsInstalled();
    }

    public function uninstall() {
        $this->otherUninstall();
        $this->unInstallDatabaseTables();
        $this->deleteSavedOptions();
        $this->markAsUnInstalled();
    }

    public function upgrade() {
    }

    public function activate() {
    }

    public function deactivate() {
    }

    protected function initOptions() {
    }

    public function addActionsAndFilters() {
    }

    protected function unInstallDatabaseTables() {
    }

    protected function otherInstall() {
    }

    protected function otherUninstall() {
    }

    public function addSettingsSubMenuPage() {
        $this->addSettingsSubMenuPageToPluginsMenu();
        $this->addBarcodeMenus();
    }

    public function adminScripts() {
        // script hozzarendeles
        admin_enqueue_script('barcode', plugin_dir_url(__FILE__) .
        '/js/barcode.js', array('jquery'), '1.0.0', true);
    }

    protected function requireExtraPluginFiles() {
        require_once(ABSPATH . 'wp-includes/pluggable.php');
        require_once(ABSPATH . 'wp-admin/includes/plugin.php');
    }

    protected function getSettingsSlug() {
        return get_class($this) . 'Settings';
    }

    protected function addBarcodeMenus() {
        $this->requireExtraPluginFiles();
        // fomenu
        add_menu_page('Vonalkód funkciók',
                      'Barcode',
                      'manage_options',
                      'barcode_top',
                      array(&$this, 'topLevelMenu'));
        // almenuk
        $subMenus = array();
        $subMenus['Vonalkód'] = 'barcode';
        $subMenus['Szállítólevél'] = 'barcode_reader';
        foreach($subMenus as $key => $value) {
            add_submenu_page('barcode_top',
                             $key,
                             $key,
                             'manage_options',
                             $value,
                             array(&$this, $value));
        }
    }

    protected function addSettingsSubMenuPageToPluginsMenu() {
        $this->requireExtraPluginFiles();
        $displayName = $this->getPluginDisplayName();
        add_submenu_page('plugins.php',
                         $displayName,
                         $displayName,
                         'manage_options',
                         $this->getSettingsSlug(),
                         array(&$this, 'settingsPage'));
    }

    protected function addSettingsSubMenuPageToSettingsMenu() {
        $this->requireExtraPluginFiles();
        $displayName = $this->getPluginDisplayName();
        add_options_page($displayName,
                         $displayName,
                         'manage_options',
                         $this->getSettingsSlug(),
                         array(&$this, 'settingsPage'));
    }

    protected function prefixTableName($name) {
        global $wpdb;
        return $wpdb->prefix .  strtolower($this->prefix($name));
    }

    public function getAjaxUrl($actionName) {
        return admin_url('admin-ajax.php') . '?action=' . $actionName;
    }
}
