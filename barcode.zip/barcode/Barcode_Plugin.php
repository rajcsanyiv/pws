<?php

include_once('Barcode_LifeCycle.php');

class Barcode_Plugin extends Barcode_LifeCycle {

    public function getOptionMetaData() {
        return array();
    }

    protected function initOptions() {
        $options = $this->getOptionMetaData();
        if (!empty($options)) {
            foreach ($options as $key => $arr) {
                if (is_array($arr) && count($arr > 1)) {
                    $this->addOption($key, $arr[1]);
                }
            }
        }
    }

    public function getPluginDisplayName() {
        return 'Barcode';
    }

    protected function getMainPluginFileName() {
        return 'barcode.php';
    }

    protected function unInstallDatabaseTables() {
    }

    public function upgrade() {
        
    }

    public function addActionsAndFilters() {
        add_action('admin_menu', array(&$this, 'addSettingsSubMenuPage'));
        add_action('admin_enqueue_scripts', function() {
            wp_enqueue_style('admin-styles', plugins_url('css/admin.css', __FILE__));
            wp_enqueue_script('admin-scripts', plugins_url('js/admin.js', __FILE__));
        });
    }
}
