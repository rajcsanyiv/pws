<?php
/*
Plugin Name: Barcode handler
Description: Pugin for packing slip barcodes
Version: 1.0
Author: Viktor Rajcsanyi / Promera
Author URI: http://promera.hu
Text Domain: barcode
Domain Path: /languages
*/

$Barcode_minimalRequiredPhpVersion = '5.0';

function Barcode_noticePhpVersionWrong() {
    global $Barcode_minimalRequiredPhpVersion;
    echo '<div class="updated fade">' .
      __('Error: plugin Barcode handler requires a newer version of PHP to be running.',
      'barcode').
            '<br/>' . __('Minimal version of PHP required: ', 'barcode') .
            '<strong>' . $Barcode_minimalRequiredPhpVersion . '</strong>' .
            '<br/>' . __('Your server\'s PHP version: ', 'barcode') . '<strong>' .
            phpversion() . '</strong>' .
         '</div>';
}

function Barcode_PhpVersionCheck() {
    global $Barcode_minimalRequiredPhpVersion;
    if (version_compare(phpversion(), $Barcode_minimalRequiredPhpVersion) < 0) {
        add_action('admin_notices', 'Barcode_noticePhpVersionWrong');
        return false;
    }
    return true;
}

function Barcode_i18n_init() {
    $pluginDir = dirname(plugin_basename(__FILE__));
    load_plugin_textdomain('barcode', false, $pluginDir . '/languages/');
}

add_action('plugins_loadedi','Barcode_i18n_init');

if (Barcode_PhpVersionCheck()) {
    include_once('barcode_init.php');
    Barcode_init(__FILE__);
}
