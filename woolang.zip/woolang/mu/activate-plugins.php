<?php
/*
Plugin Name:  Active plugins
Description:  Activate needed plugins
Version:      1.0
Author:       Viktor Rajcsanyi
Author URI:   http://www.promera.hu/
*/

include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

$pluginjson = file_get_contents(ABSPATH.'plugins.json');

$arr = json_decode($pluginjson, true);

$jsonIterator = new RecursiveIteratorIterator(
    new RecursiveArrayIterator(json_decode($pluginjson, TRUE)),
    RecursiveIteratorIterator::SELF_FIRST);

foreach ($jsonIterator as $key => $val) {
    if(is_array($val)) {
	if (in_array("AdvancedOrderFiltering", $val)) {
		$result = activate_plugin( 'advanced-order-filtering/advanced-order-filtering.php' );
		if ( is_wp_error( $result ) ) {
		    error_log("advancedorderfiltering activation error",0);
		}
	}
	if (in_array("Barcode", $val)) {
		$result = activate_plugin( 'barcode/barcode.php' );
		echo array_search("red",$val);
		if ( is_wp_error( $result ) ) {
		    error_log("barcode activation error",0);
		}
	}
	if (in_array("Changestock", $val)) {
		$result = activate_plugin( 'changestock/newstock.php' );
		if ( is_wp_error( $result ) ) {
		    error_log("changestock activation error",0);
		}
	}
	if (in_array("CollectiveDelivery", $val)) {
		$result = activate_plugin( 'wc_collective_delivery/wc_collective_delivery.php' );
		if ( is_wp_error( $result ) ) {
		    error_log("collectivedelivery activation error",0);
		}
	}
	if (in_array("CustomerOrders", $val)) {
		$result = activate_plugin( 'customersplugin/customers.php' );
		if ( is_wp_error( $result ) ) {
		    error_log("customerorders activation error",0);
		}
	}
	if (in_array("Szamlazz", $val)) {
		$result = activate_plugin( 'integration-for-szamlazzhu-woocommerce/index.php' );
		if ( is_wp_error( $result ) ) {
		    error_log("szamlazz activation error",0);
		}
	}
	if (in_array("NewOrderStates", $val)) {
		$result = activate_plugin( 'new_order_states/new_order_states.php' );
		if ( is_wp_error( $result ) ) {
		    error_log("neworderstates activation error",0);
		}
	}
	if (in_array("OrderLimitation", $val)) {
		$result = activate_plugin( 'order-limitation/order-limitation.php' );
		if ( is_wp_error( $result ) ) {
		    error_log("orderlimitation activation error",0);
		}
	}			
	if (in_array("Regularprice", $val)) {
		$result = activate_plugin( 'regular_price/regularprice.php' );
		if ( is_wp_error( $result ) ) {
		    error_log("reguarprice activation error",0);
		}
	}	
	if (in_array("Sprinter", $val)) {
		$result = activate_plugin( 'wc_sprinter/wc_sprinter.php' );
		if ( is_wp_error( $result ) ) {
		    error_log("sprinter activation error",0);
		}
	}
	if (in_array("SuperSocializer", $val)) {
		$result = activate_plugin( 'super-socializer/super_socializer.php' );
		if ( is_wp_error( $result ) ) {
		    error_log("supersocializer activation error",0);
		}
	}
	if (in_array("DiscountRules", $val)) {
		$result = activate_plugin( 'woo-discount-rules/woo-discount-rules.php' );
		if ( is_wp_error( $result ) ) {
		    error_log("discountrules activation error",0);
		}
	}
	if (in_array("OrdersDateRangeFilter", $val)) {
		$result = activate_plugin( 'woo-orders-date-range-filter/woo-orders-date-range-filter.php' );
		if ( is_wp_error( $result ) ) {
		    error_log("ordersdatarangefilter activation error",0);
		}
	}
	if (in_array("BackorderManager", $val)) {
		$result = activate_plugin( 'woo-backorder-manager/woo-backorder-manager.php' );
		if ( is_wp_error( $result ) ) {
		    error_log("backordermanager activation error",0);
		}
	}
	if (in_array("BACSOrderEmail", $val)) {
		$result = activate_plugin( 'woocommerce-bacs-order-email/woocommerce-bacs-order-email.php' );
		if ( is_wp_error( $result ) ) {
		    error_log("BACSOrderEmail activation error",0);
		}
	}
	if (in_array("PayOnPickup", $val)) {
		$result = activate_plugin( 'woocommerce-pay-on-pickup/wc-pay-on-pickup.php' );
		if ( is_wp_error( $result ) ) {
		    error_log("payonpickup activation error",0);
		}
	}
	if (in_array("Paypal", $val)) {
		$result = activate_plugin( 'woocommerce-gateway-paypal-express-checkout/woocommerce-gateway-paypal-express-checkout.php' );
		if ( is_wp_error( $result ) ) {
		    error_log("paypal activation error",0);
		}
	}
	if (in_array("PDFInvoice", $val)) {
		$result = activate_plugin( 'woocommerce-pdf-invoices-packing-slips/woocommerce-pdf-invoices-packingslips.php' );
		if ( is_wp_error( $result ) ) {
		    error_log("pdfinvoice activation error",0);
		}
	}
        echo "$key:\n";
    } else {
        echo "$key => $val\n";
    }
}
