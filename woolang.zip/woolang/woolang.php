<?php
/*
Plugin Name: Woocommerce language helper
Version: 1.0
Description: Just a place where we store the Woocommerce language files
Author: Viktor Rajcsanyi
Author URI: viktor.rajcsanyi@promera.hu
Text Domain: woolang
*/

