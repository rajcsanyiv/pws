Build Guide
================

This document provides information about automatization system, which is manage a build and packaging process of ShopMagic plugin.

Overview
--------
Build system based on Gulp.JS scripts, which is Node.JS based taskrunner. System allows to prepare plugin release archive file and prepare js and css file to production mode.

TODO
----
In future (I hope it is nearest future :)) this system should perform unit, integration and selenium test

Prerequisites
-------------
To work with build system we should install Node.JS for our system [to install follow this link](https://nodejs.org/en/). And also we use npm package manager to install Gulp.JS.
After installing Node.JS we should enter into project directory and type:
```
npm install
```
This command should install all needed scripts.

Commands
--------
Default command is create release package, so if we type
```
gulp
```
then we have got `shopmagic.zip` file with minified JS and CSS files in `build` directory.

There is some additional targets (parameters for gulp command)

Command             |Description
--------------------|-----------
`gulp clean`        | Cleanup `build` directory
`gulp build:plugin` |Create production directory structure and perform minification of all js and css files
`gulp build:archive`|Create zip archive with files form `build` directory





