Developer Guide
================

This document provides information about an architecture and basic concepts of plugin "ShopMagic".
Minimal requirement version of PHP is 5.3

Plugin description
------------------
Plugin provides ability to user without coding experience create conditional processes, based on events form WordPress and it plugins (WooCommerce, in example).
Main concepts of plugins is:

*   Automation - base entity of plugins, contains event, this triggers set of actions.
*   Event - some event in WordPress, maybe with condition.
*   Action - predefined action with parameters, which runs, when Automation executes.
*   Placeholders - part of Event. Provides values to actions. In example, order number, which fires particular event or user email address.


Directory structure
-------------------
Plugin Folder Structure:

Folders:

*   /assets
*   /assets/css
*   /assets/images
*   /assets/js - all js files
*   /includes
*   /includes/admin - all settings files
*   /includes/api - main entity classes
*   /includes/api/actions - classes of built-in actions
*   /includes/api/events - classes of built-in events
*   /includes/emails/ - functions and functionality for emails
*   /includes/libraries - misc included libraries
*   /languages
*   /templates
*   /templates/emails - html bodies for emails

Files:

*   shopMagic.php - Main plugin file
*   readme.txt
*   uninstall.php

Naming agreement
-----------------

### PHP sources
Class names starts with capital letter, each part of name starts with capital letter and `_` used as a word separator. So it is snake case style with capital letters. Each class is in separate file, file name consists form class name and extension `class.php`, so if class name is `ShopMagic_Action_Metabox`,  then file name is `ShopMagic_Action_Metabox.class.php`. Methid and variables named in snake case style, in example: `simple_method`, `more_complex_method`. Each entity commented in PHPDoc format. If needed, PHPDoc comments can be applied inside functions, to help properly work code completion in IDE.

### JavaScript sources
Each variable and method names in camel case style.


Classes herarchy
-----------------
Classes in this plugin splits in two parts:

*   first one is service classes, which wraps service functions by meaning.
*   second is plugin entity classes, which realise plugin functionality.

### Service classes
#### Main classes

 Class Name                 | Description
----------------------------|-------------------
`ShopMagic`                 | Main plugin class, register and manage plugin, register Automation hooks, initialize admin area manager class when needed
`Automations_PostType`      | Contains automation post type description


#### Admin area classes

Class Name                  | Description
----------------------------|------------------
`ShopMagic_Admin`           | Manage admin area classes and files
`ShopMagic_WC_Settings_Tab` | Contains functions to show and operate settings tab in WooCommerce setting area
`ShopMagic_Action_Metabox`  | Contains functions to show and operate Action Meta Box in automations page
`ShopMagic_Event_Metabox`   | Contains functions to show and operate Event Meta Box in automations page
`ShopMagic_Placeholders_Metabox`| Contains functions to create area in an edit automation page

### Entity classes
Base class of each business entity is `ShopMagic_Entity`. It contains base methods and functions to provide class registration for execution and show it in admin area.

`ShopMagic_Event` and `ShopMagic_Actions` - classes which is provides some methods and variables  for ations and events. Each action and event class must inherits this class

#### ShopMagic_Entity
This class provides basic metadata manipulation  of event and action and perform some shared initialization.

This class is abstract.

#####Properties:

Name            | Description
----------------|----------------
`$name`         |Name of entity, it shows in user interface. Must be override  in child classes.
`$slug`         |Internal identification of entity, used for internal addressing. Must be override  in child classes.
`$core`         |Reference to main class of plugin `ShopMagic`, used for some internal data manipulation, initialized in constructor
`$automation_id`|ID of automation, which  is creates this instance  of entity
`$data_domains` |List of  used data domains (user info, order info e.t.c.)

#####Methods:
Name            | Description
----------------|----------------
`__construct`   |Default constructor, accepts reference to `ShopMagic` class and ID of Automation, to store in internal variables
`get_name`      |Static getter of `$name` property
`get_slug`      |Static getter of `$slug` property
`get_automation_id`      |Getter of `$automation_id` property
`get_data_domains`      |Getter of `$data_domains` property

#### ShopMagic_Event
This class provides common methods for events and standardized some interface methods for events manipulation.
This class is abstract.

#####Properties:

Name                    | Description
------------------------|----------------
`$group`                |Event group slug, used for admin area select box
`$placeholders`         |Associative array of available placeholders, provided by particular event in format `"slug"=>"Name"`, where `Name` is name of placeholder in user interface (not used yet :), in the interface actually shows only a slug, surrounded by doubled curly brackets)
`$placeholders_values`  |Associative array of initialized placeholder values, filled before actions call and values taken accordingly current Automation.


#####Methods:
Name                 | Description
---------------------|----------------
`__construct`        |Default constructor, when new instance created call setup_hook method, to initialize event triggers.
`get_group`          |Static getter of `$group` property
`setup_hook`         |Abstract method, must be implemented in a concrete class. Here we should initialize wordpress actions callback
`setup_placeholders` |Abstract method, must be implemented in a concrete class. Here we extract variables and fill `$placeholders_values` array by values.
`run_actions`        |Common method, where runs each action from Automation. Here we call setup_placeholders method.
`show_parameters`    |Static method, must be implemented in a concrete class. Method used as a standrad interface between metabox and particular event class, here we create HTML code which is shows form and fill it by values. Values can be extracted from passed `$automation_id` variable
`save_parameters`    |Static method, must be implemented in a concrete class. Method used as a standrad interface between metabox and particular event class, here we store given values from `$_POST` variable into desired  store, which can be accessed when WordPress action fires and our callback runs.
`get_placeholders`   |Static getter of `$placeholders` property
`show_placeholders`  |Common static method. Used to generate content for a "Palceholders" metabox in admin interface
`process_string`     |Common method. Used to process string with placeholders and replace it by values.

#### ShopMagic_Action
This class provides common methods for actions and standardized some interface methods for actions manipulation.
This class is abstract.

#####Properties:

Name                    | Description
------------------------|----------------
`$data`                 |Stores current action settings


#####Methods:
Name                 | Description
---------------------|----------------
`__construct`        |Default constructor, accepts also `$data` array, where stored values for options for a concrete instance of action for given Automation.
`execute`            |Abstract method, used as interface to execute an action. Passed reference to `$event` which is runs this action. Event reference may be used to call `process_string` method to replace placeholders by it values.
`show_parameters`    |Static method, must be implemented in a concrete class. Method used as a standard interface between metabox and particular action class, here we create HTML code which is shows form and fill it by values. Echa field name should use prefix from `$name_prefix` variable, values can be taken from `$data` array
`save_parameters`    |Static method, must be implemented in a concrete class. Method used as a standrad interface between metabox and particular action class, here we store given values from `$post` variable into `$data` array. This values will be stored then in a Automation post meta accordingly each action and will be extracted and passed to each action instance when action runs.



Plugin life cycle
-----------------
On plugin startup we firstly initialize actions and automations, which can be used in our plugins. In first, we initialize array with active plugin entities (Actions and events): `ShopMagic::setup_entities` and then we apply filters to this  arrays `shopmagic_events`, `shopmagic_event_groups` and `shopmagic_actions`.  Then we include files with particular classes to get this class names visible in our namespace via actions `initialize_default_events` and `initialize_default_actions`.

Then we select active automations in  method `ShopMagic::register_active_automations`. For each active automation we create event class and pass in constructor method automation id and reference to the base plugin class.

Event classes on initialization register their action listeners. In example, an event which is triggers on order processing event from WooCommerce, register `woocommerce_order_status_processing` action hook handler. In this action handler we can create some logic, to check event conditions, and if we are ready, we call `run_actions()` method, which is runs actions form particular automation.

When an action runs (logic is placed in `execute()` method) we can run placeholders substation process by call `process_string()` function from event class, which is run this action (reference on event passed in `execute()` method.

Used filters and actions
----------------------

### Filters:

Filter name                    | Description
-------------------------------|-------------
`shopmagic_events`             | this filter can be used to add new items in events array
`shopmagic_event_groups`       | this filter can be used to add new items in event groups array
`shopmagic_actions`            | this filter can be used to add new items in actions array


### Actions:

Action name                    | Description
-------------------------------|-------------
`shopmagic_initialize_events`  | this action used to load event classes into current namespace
`shopmagic_initialize_actions` | this action used to load actions classes into current namespace

Data domains concept
----------------------
Each event can provide different kind of data depending of its hook. In example, New User event can provide user information, but New Order event provides order info too. Moreover, actions can use  different kind of data to do its work. When we are creating automation by combining event and action, we may faced with a situation, when some actions need data which is not provided by event. To catch this situation and notify user about this we put in each Entity class information about data domains where this Entity works. So, in our examples New User event works in data domain `user` and New Order in domains `user` and `order`, in this way, if action used order information in self internal code, we should point that and set data domain `order`.

This can be achieved by static variale `$data_domain` which is conatains string array with data domain labels. By default this array is empty.

In admin area, when selected action that requires data from domains not provided by event, user  will be notified.

### Predefined data domains:
Data domain label| Description
-----------------|----------------------
`user`           | User infromation, event may provide WP_User object
`order`          | Order informatio, event may provide WP_Order object

How to build new event
----------------------
Event must inherit class `ShopMagic_Events`. In our example we creating class `Example_Event`, which is stored in file `/includes/api/events/ExampleEvent.class.php`. It is important to name class file in this way, because class loader function use class name in a file name template to perform automatic class loading.
To properly create new event in the plugin we must perform following steps:

###  Register class in the plugin
Firstly we need to set plugin name and slug. In our class need to define static properties:

```
#!php5
static protected $name = "Example event";
static protected $slug = "shopmagic_example_event";
static protected $group = 'orders';
static protected $data_domains = array('order');
```

There variable `$group` refers to event group slug. This groups used only to grouping events in an admin area select box.

Then we need to modify ShopMagic's methods:

```
#!php
    function setup_entities() {

        $this->events = array(
            'shopmagic_order_processing_event'=>'ShopMagic_OrderProcessing_Event',
            'shopmagic_example_event'=>'Example_Event'
        );
```

After this plugin will be visible in event list in automation selectbox.

### Placeholders registration
To deal with placeholders we need to declare available placeholders, and then charge it with particular values.

Placeholders declaration carried in static variable of class:

```
#!php5
    static protected $placeholders = array(
            'user_id' => "User ID",
            'user_name' => "User Name",
            'user_email' => "User Email"
        );
```
This placeholders automatically will be visible in placeholders box, when our event is selected.

To provide placeholders values we need to override method `setup_placeholders()`. This method will be calling before action execution. In this method we should to fill `placholders_values` array with actual values of placeholders:

```
#!php

    $this->placeholders_values = array(
            'user_id' => $user->ID,
            'user_name' => $user->display_name,
            'user_email' => $user->user_email (or $order->billing_email on non-account related events)
        );
```
### Event parameters
To show parameters form in admin area we need to override method `show_parameters()`

```
#!php
  static function show_parameters($automation_id)
  {
        $example_value = get_post_meta($automation_id,'_example_value',true);
        ?>
        <label for="event_example">Example Event Parameter:</label><br/>
        <input type="text" name="event_example" value="<?php echo $example_value; ?>"/>
        <?php
  }
```
Here we just put html code, which is will be a part of automation form. Here we should read values and provide default values.

When automation form saving, plugin core call `save_parameters` function

```
#!php
static function save_parameters($automation_id)
    {
        update_post_meta($automation_id,'_example_value',$_POST["event_example"]);
    }
```
here we should  process POST data and save data in desired way.

### Event registration
To register handler of particular WP event we should override function `setup_hook`:

```
#!php
 protected function setup_hook() {

         add_action('woocommerce_order_status_processing', array($this, 'process_order'));
     }
```
name of callback function can be any desired.

### Event processing
When callback function runs (in our example it is `process_order`) we can perform some additional conditional check and if we ready to run actions we should call method `run_actions()`, this methods will setup and run actions from parent automation.


How to build new action
-----------------------
Action must inherit class `ShopMagic_Action`. In our example we creating class `Example_Action`, which is stored in file `/includes/api/action/ExampleAction.class.php`. It is important to name class file in this way, because class loader function use class name in a file name template to perform automatic class loading.
To properly create new action in the plugin we must perform following steps:

###  Register class in the plugin
Firstly we need to set plugin name and slug. In our class need to define static properties:

```
#!php
static protected $name = "Example Action";
static protected $slug = "shopmagic_example_action";
static protected $data_domains = array('order');
```


Then we need to modify ShopMagic's methods:

```
#!php
    function setup_entities() {

        $this->actions = array(
            'shopmagic_sendemail_action'=>'ShopMagic_SendEmail_Action',
            'shopmagic_example_action'=>'Example_Action'
        );
```
After this plugin will be visible in action list in automation selectbox.

### Action parameters
Because one automation can use more than one action at once, action parameter page is more complex, than event page.
To show parameters form in admin area we need to override method `show_parameters()`

```
#!php
  static function show_parameters($automation_id, $data, $name_prefix)
    {

        if ($data['_action'] != self::$slug) { // if data are from other class type then cleanup data array
            $data = array();
        }
        ?>
        <label for="action_example">Subject:</label><br/>
        <input type="text" name="<?php echo $name_prefix;?>[_example_value]" id="action_example" value="<?php echo $data['_example_value']; ?>"/>
        <?php
    }
```

Here we put html code, which is will be a part of automation form. But we should use $name prefix variable and for default values we should use `$data` variable. Action MetaBox by himself manages data and sotre it in post meta by WP functions.

When automation form saving, plugin core call `save_parameters` function which is provides reference to `$data` array with data to save in post meta.

```
#!php
static function save_parameters($automation_id, &$data, $post)
    {
        $data['_example_value'] = $post["_example_value"];
    }
```
here we should  get data form  `$post` array and in simple case just save in `$data` array, but, of course, we can perform some manipulation before save.

### Action processing
Action code should placed in method `execute()`. Here we can put desired code to achieve our goals. Here is accessible caller event in variable `$event` and we can replace placeholders in our string by actual values.

```
#!php
function execute($event)
    {
        // TODO: Implement execute() method.

        $new_data = $event->process_string($this->data['_example_value']);
        error_log('Example action call');
    }
```

