<?php 
// Silence is gold
?>