<?php
/*
Plugin Name: DPDClassic
Description: DPD Classic delivery
Version: 1.0
Author: Viktor Rajcsányi / Promera
Author URI: http://promera.hu
Text Domain: dpdclassic
Domain Path: /languages/
*/

if ( ! defined( 'WPINC' ) ){
	die('Permission denied');
}

add_action('admin_menu', 'dpdclassic_create_page');

function dpdclassic_create_page() {
    add_menu_page('DPD csomagok', 'DPD csomagok', 'list_users', 'dpdclassic', 'dpdclassic_menu', 'dashicons-admin-generic', 51);
    add_submenu_page('dpdclassic', 'Csomag keresés', 'Csomag keresés', 'list_users', 'dpdclassic', 'dpdclassic_menu');
}

function dpdclassic_menu() {
    echo "<h1 class=\"wp-heading-inline\">DPD csomagok lekérdezése</h1><br/>";
	$orderid = isset($_GET['orderid']) ? $_GET['orderid'] : '';
?>
		<hr>
		Az összes kinyomtatott cimkéjű csomag rögzítése a DPD rendszerében.<br/>
		A csomagok utána már nem módosíthatók! 
		<form>
                    <input type="hidden" name="page" value="dpdclassic">
			        <input type="hidden" name="action" value="save">
                    <input type="submit" class="button action" value="<?php esc_html_e('VÉGLEGESÍTÉS', 'dpdclassic'); ?>">
		</form>
             <div class="wrap">
                <hr>
                <form method="GET">
                    <input type="hidden" name="page" value="dpdclassic">
                    <label for="orderid"><font size="3"><?php esc_html_e('Rendelés azonosító', 'dpdclassic'); ?></font></label>
                    <input type="text" name="orderid" id="orderid" value="<?php echo $orderid; ?>">
                    <input type="submit" class="button action" value="<?php esc_html_e('LEKÉRDEZ', 'dpdclassic'); ?>">
                </form>
            </div>
<?php
if (isset($_GET["action"]) && $_GET["action"]=="save") {

	$api = new DPD\API([
		    'username' => get_option('weblabeluser'),
		    'password' => get_option('weblabelpass'),
		    'log_dir'  => dirname(__FILE__).'/'
	]);
$number_parcels_sent = $api->transferData();
echo "Feldolgozott csomagok: ".$number_parcels_sent;

}


    if(isset($_GET['orderid'])){
        $api = new DPD\API([
               'username' => get_option('weblabeluser'),
	    'password' => get_option('weblabelpass'),
	    'log_dir'  => dirname(__FILE__).'/log/'
	]);
        $parcel=get_post_meta($orderid,'dpdparcel',true);
        if(empty($parcel)){
            echo "Nincs találat a rendelés azonosítóra: ".$orderid;
        }
        if(!empty($parcel)){
            echo "Csomagazonosító: ".print_r($parcel,true);
?>
<form method="GET">
                    <input type="hidden" name="page" value="dpdclassic">
                    <input type="hidden" name="orderid" value="<?php echo $orderid; ?>">
    <fieldset>
        <legend>A lehetséges műveletek</legend>
        <input type="radio" name="action" value="print">Nyomtatás<br>
        <input type="radio" name="action" value="status">Státusz lekérdezés<br>
        <input type="radio" name="action" value="del">Törlés<br>
        <br>
                    <input type="submit" class="button action" value="<?php esc_html_e('Végrehajtás', 'dpdclassic'); ?>">
    </fieldset>
</form>
<?php
//nyomtat, tesztelve, nem működik, de az oldal is üres lapod ad a lekérdezésre, lehet a demo miatt
            if (isset($_GET["action"]) && $_GET["action"]=="print") {
                $parcel_array = array($parcel);
                $parcel_response_json = $api->getParcelLabels($parcel_array);
if($parcel_response_json['status'] == 'err'){
	echo $parcel_response_json['errlog'];
}
else{
                header("Content-type:application/pdf");
//error_log (print_r($parcel_response_json['pdf'],true),0);
                echo $parcel_response_json['pdf'];
}
            }
//töröl, tesztelve, működik
            if (isset($_GET["action"]) && $_GET["action"]=="del") {
                $parcel_array = array($parcel);
                $parcel_delete_status = $api->deleteParcel($parcel_array);
if($parcel_delete_status['status'] == 'err'){
	echo $parcel_delete_status['errlog'];
}
else{
                echo "A ".$parcel." azonosítójú csomag törölve.";
}
            }
//adatlekérdezés
            if (isset($_GET["action"]) && $_GET["action"]=="status") {
                $parcel_array = array($parcel);
                $status_msg = $api->getParcelStatus($parcel);
                if(strpos($status_msg,"status doesn't exist")===FALSE)
                    echo $status_msg;
                else{
                    echo "Nem áll rendelkezésre adat.";
                }
            }
        }
    }
}

add_action( 'woocommerce_shipping_init', 'dpdclassic_shipping_method' );
function dpdclassic_shipping_method() {
	if ( ! class_exists( 'WC_DPDClassic_Shipping_Method' ) ) {
		class WC_DPDClassic_Shipping_Method extends WC_Shipping_Method {
			public function __construct( $instance_id = 0 ) {
			        $this->instance_id 	  = absint( $instance_id );
			        $this->id                 = 'dpdclassic';
			        $this->method_title       = __( 'DPD Classic delivery', 'dpdclassic' );
			        $this->method_description = __( 'DPD Classic delivery shipping option', 'dpdclassic' );
			        $this->supports = array(
		        	'shipping-zones',
        			'instance-settings',
				'instance-settings-modal',
			        );
				$this->title = __( 'DPD Classic Delivery', 'dpdclassic' );
        			$this->enabled = 'yes';
        			$this->init();
      			}
      			function init() {
        			$this->init_form_fields();
        			$this->init_settings();
        			add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
      			}
      			function init_form_fields() {
        			$this->instance_form_fields = array(
          			'title' => array(
             				'title' => __( 'Megnevezés', 'dpdclassic' ),
               				'type' => 'text',
               				'description' => __( 'Az oldalon látható megnevezés', 'dpdclassic' ),
               				'default' => __( 'DPD Classic futár csomagszállítás', 'dpdclassic' )
               				),
          			'cost' => array(
             				'title' => __( 'Alap ár (Ft)', 'dpdclassic' ),
               				'type' => 'number',
               				'description' => __( 'Címen történő feladás esetén 1905 Ft, depoban 0', 'dpdclassic' ),
               				'default' => 1905
               				)
          			);
      			}
      			public function calculate_shipping( $package = array()) {
        			$intance_settings =  $this->instance_settings;
        			$this->add_rate( array(
            			'id'      => $this->id,
            			'label'   => $intance_settings['title'],
            			'cost'    => $intance_settings['cost'],
            			'package' => $package,
            			'taxes'   => false,
          			));
      			}
    		}
  	}
	add_filter( 'woocommerce_shipping_methods', 'add_dpdclassic_shipping_method' );
	function add_dpdclassic_shipping_method( $methods ) {
      		$methods['dpdclassic'] = 'WC_DPDClassic_Shipping_Method';
      		return $methods;
	}
	//add_action( 'woocommerce_shipping_init', 'dpdclassic_cod_shipping_method' );

	if ( ! class_exists( 'WC_DPDClassic_COD_Shipping_Method' ) ) {
		class WC_DPDClassic_COD_Shipping_Method extends WC_Shipping_Method {
      			public function __construct( $instance_id = 0 ) {
        			$this->instance_id 	  = absint( $instance_id );
        			$this->id                 = 'dpdclassic_cod';
        			$this->method_title       = __( 'DPD Classic COD delivery', 'dpdclassic' );
        			$this->method_description = __( 'DPD Classic COD delivery shipping option', 'dpdclassic' );
        			$this->supports = array(
        			'shipping-zones',
        			'instance-settings',
				'instance-settings-modal',
        			);
				$this->title = __( 'DPD Classic COD Delivery', 'dpdclassic' );
        			$this->enabled = 'yes';
        			$this->init();
      			}
      			function init() {
        			$this->init_form_fields();
        			$this->init_settings();
        			add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
      			}
      			function init_form_fields() {
        			$this->instance_form_fields = array(
          			'title' => array(
             				'title' => __( 'Megnevezés', 'dpdclassic' ),
               				'type' => 'text',
               				'description' => __( 'Az oldalon látható megnevezés', 'dpdclassic' ),
               				'default' => __( 'DPD Classic utánvéttel', 'dpdclassic' )
               				),
          			'cost' => array(
             				'title' => __( 'Alap ár (Ft)', 'dpdclassic' ),
               				'type' => 'number',
               				'description' => __( 'Címen történő feladás esetén 2405 Ft, depoban 500', 'dpdclassic' ),
               				'default' => 2405
               				)
          			);
      			}
      			public function calculate_shipping( $package = array()) {
        			$intance_settings =  $this->instance_settings;
        			$this->add_rate( array(
            			'id'      => $this->id,
            			'label'   => $intance_settings['title'],
            			'cost'    => $intance_settings['cost'],
            			'package' => $package,
            			'taxes'   => false,
          			));
      			}
    		}
  	}

  	add_filter( 'woocommerce_shipping_methods', 'add_dpdclassic_cod_shipping_method' );
  	function add_dpdclassic_cod_shipping_method( $methods ) {
      		$methods['dpdclassic_cod'] = 'WC_DPDClassic_COD_Shipping_Method';
      		return $methods;
  	}

function dpdclassic_validate_order($posted) {
	$packages = WC()->shipping->get_packages();
	$chosen_methods = WC()->session->get('chosen_shipping_methods');
 	if (is_array($chosen_methods) && (in_array('dpdclassic', $chosen_methods) || in_array('dpdclassic_cod', $chosen_methods))) {
		$weightLimit=30;
 		foreach ($packages as $i => $package) {
 			if (($chosen_methods[$i] != "dpdclassic") || ($chosen_methods[$i] != "dpdclassic_cod")) {
 				continue;
 			}
			foreach ($package['contents'] as $item_id => $values) {
				$_product = $values['data'];
				$weight = $weight + $_product->get_weight() * $values['quantity'];
			}
			$weight = wc_get_weight($weight, 'kg');
			if ($weight > $weightLimit) {
				$message = sprintf(__('%d kg meghaladja a megengedett súlyt (%d kg)', 'dpdclassic'), $weight, $weightLimit);
				$messageType = "error";
				if (!wc_has_notice($message, $messageType)) {
					wc_add_notice($message, $messageType);
				}
			}
		}
	}
}

add_action('woocommerce_after_checkout_validation', 'dpdclassic_validate_order', 10);
add_action( 'woocommerce_checkout_order_processed', 'dpdclassic_checkout_order_processed' );

function dpdclassic_checkout_order_processed( $order_id ) {
	$order = wc_get_order( $order_id );
	$order_id  = $order->get_id(); 
	$user_id   = $order->get_user_id();
	$user = $order->get_user();
	$cart_contents_weight = WC()->cart->get_cart_contents_weight();
	$shipping_method_title="";
	foreach( $order->get_items( 'shipping' ) as $item_id => $shipping_item_obj ){
		$order_item_name = $shipping_item_obj->get_name();
		$order_item_type             = $shipping_item_obj->get_type();
		$shipping_method_title       = $shipping_item_obj->get_method_title();
		$shipping_method_id          = $shipping_item_obj->get_method_id(); // The method ID
		$shipping_method_instance_id = $shipping_item_obj->get_instance_id(); // The instance ID
		$shipping_method_total       = $shipping_item_obj->get_total();
		$shipping_method_total_tax   = $shipping_item_obj->get_total_tax();
		$shipping_method_taxes       = $shipping_item_obj->get_taxes();
	}
	if ($shipping_method_id=='dpdclassic' || $shipping_method_id=='dpdclassic_cod') {
		if (is_file('/var/www/html/bedrock/vendor/autoload.php')) {
			require '/var/www/html/bedrock/vendor/autoload.php';
		}
		$api = new DPD\API([
		    'username' => get_option('weblabeluser'),
		    'password' => get_option('weblabelpass'),
		    'log_dir'  => dirname(__FILE__).'/log/'
		]);
		$parcel_generate = array(
		        'setName1' => $order->get_shipping_last_name().' '.$order->get_shipping_first_name(),
		        'setStreet' => $order->get_shipping_address_1(),
		        'setCity' => $order->get_shipping_city(),
		        'setCountry' => $order->get_shipping_country(),
		        'setPcode' => $order->get_shipping_postcode(),
		        'setWeight' => $cart_contents_weight,
		        'setNumOfParcel' => 1,
		        'setParcelType' => 'D',
		        'setOrderNumber' => $order_id,
		        'setCodAmount' => '',
		        'setCodPurpose' => '',
		        'setEmail' => $order->get_billing_email(),
		        'setPhone' => $order->get_billing_phone(),
		        'setSMSNumber' => $order->get_billing_phone(),
		        'setRemark' => $order->get_customer_note()
		);
		$parcel_number = $api->generateParcel($parcel_generate);
     		update_post_meta( $order_id, 'dpdparcel', $parcel_number );
	}
}



}



if ( ! class_exists( 'WC_Settings_DPDClassic' ) ) :

if ( ! class_exists( 'WC_Settings_Page' ) ) {
	require_once( substr(plugin_dir_path(__FILE__),0,strlen(plugin_dir_path(__FILE__))-12) . '/woocommerce/includes/admin/settings/class-wc-settings-page.php' );
}

function dpdclassic_add_settings() {
	class WC_Settings_DPDClassic extends WC_Settings_Page {
		public function __construct() {
			$this->id    = 'dpdclassic';
			$this->label = __( 'DPDClassic', 'dpd' );
			add_filter( 'woocommerce_settings_tabs_array',        array( $this, 'add_settings_page' ), 20 );
			add_action( 'woocommerce_settings_' . $this->id,      array( $this, 'output' ) );
			add_action( 'woocommerce_sections_' . $this->id,      array( $this, 'output_sections' ) );
			add_action( 'woocommerce_settings_save_' . $this->id, array( $this, 'save' ) );
		}

		public function get_sections() {		
			$sections = array(
				'setup' => __( 'Árak', 'dpdclassic' ),
			);
			return apply_filters( 'woocommerce_get_sections_' . $this->id, $sections );
		}

		public function get_settings( $current_section = 'Árak' ) {
			$settings = apply_filters( 'dpdclassic_section1_settings', array(
				array(
				'name' => __('DPD díjak beállítása', 'dpdclassic'),
				'type' => 'title',
				'desc' => '',
				'id' => 'dpdclassic_main_title',
				),	
				array(
				'type'     => 'text',
				'id'       => 'dpdclassic_3kg',
				'name'     => __( '0-3,00 kg', 'dpdclassic' ),
				'desc'     => __( '', 'dpdclassic' ),
				'default'  => '1355',
				),
				array(
				'type'     => 'text',
				'id'       => 'dpdclassic_5kg',
				'name'     => __( '3,01-5,00 kg', 'dpdclassic' ),
				'desc'     => __( '', 'dpdclassic' ),
				'default'  => '1355',
				),
				array(
				'type'     => 'text',
				'id'       => 'dpdclassic_10kg',
				'name'     => __( '5,01-10,00 kg', 'dpdclassic' ),
				'desc'     => __( '', 'dpdclassic' ),
				'default'  => '1775',
				),
				array(
				'type'     => 'text',
				'id'       => 'dpdclassic_20kg',
				'name'     => __( '10,01-20,00 kg', 'dpdclassic' ),
				'desc'     => __( '', 'dpdclassic' ),
				'default'  => '2300',
				),
				array(
				'type'     => 'text',
				'id'       => 'dpdclassic_31kg',
				'name'     => __( '20,01-31,50 kg', 'dpdclassic' ),
				'desc'     => __( '', 'dpdclassic' ),
				'default'  => '3140',
				),
				array(
				'type'     => 'text',
				'id'       => 'dpdclassic_50kg',
				'name'     => __( '31,51-50,00 kg', 'dpdclassic' ),
				'desc'     => __( '', 'dpdclassic' ),
				'default'  => '5240',
				),
				array(
				'type' => 'sectionend',
				 'id' => 'vendor' 
				)
			)							
			);
			return apply_filters( 'woocommerce_get_settings_' . $this->id, $settings, $current_section );
		}
		
		public function output() {		
			global $current_section;
			$settings = $this->get_settings( $current_section );
			WC_Admin_Settings::output_fields( $settings );
		}

		public function save() {		
			global $current_section;			
			$settings = $this->get_settings( $current_section );
			WC_Admin_Settings::save_fields( $settings );
		}
	}
	return new WC_Settings_DPDClassic();
}

add_filter( 'woocommerce_get_settings_pages', 'dpdclassic_add_settings', 15 );

endif;

add_filter( 'woocommerce_get_sections_dpdclassic', 'weblabel_add_section' );
function weblabel_add_section( $sections ) {
	
	$sections['weblabel'] = __( 'Weblabel beállítások', 'dpdclassic' );
	return $sections;
	
}

add_filter( 'woocommerce_get_settings_dpdclassic', 'weblabel_all_settings', 10, 2 );
function weblabel_all_settings( $settings, $current_section ) {
	if ( $current_section == 'weblabel' ) {
		$settings_weblabel = array();
		$settings_weblabel[] = array( 'name' => __( 'Weblabel hozzáférés adatai', 'dpdclassic' ), 'type' => 'title', 'desc' => __( 'A DPD Weblabel oldalhoz tartozó hozzáférés', 'dpdclassic' ), 'id' => 'weblabel' );
		$settings_weblabel[] = array(
			'name'     => __( 'DPD Weblabel felhasználónév', 'dpdclassic' ),
			'desc_tip' => __( 'A Weblabel internetes feülethez tartozó felhasználónév', 'dpdclassic' ),
			'id'       => 'weblabeluser',
			'type'     => 'text',
			'desc'     => __( 'A Weblabel internetes feülethez tartozó felhasználónév', 'dpdclassic' ),
			'default'     => __( 'demo' ),
		);
		$settings_weblabel[] = array(
			'name'     => __( 'DPD Weblabel jelszó', 'dpdclassic' ),
			'desc_tip' => __( 'A Weblabel internetes feülethez tartozó jelszó', 'dpdclassic' ),
			'id'       => 'weblabelpass',
			'type'     => 'text',
			'desc'     => __( 'A Weblabel internetes feülethez tartozó jelszó', 'dpdclassic' ),
			'default'     => __( 'o2Ijwe2!', 'dpdclassic' ),
		);
		$settings_weblabel[] = array( 'type' => 'sectionend', 'id' => 'weblabel' );
		return $settings_weblabel;
	} else {
		return $settings;
	}
}

add_filter( 'woocommerce_get_sections_dpdclassic', 'vendor_add_section' );
function vendor_add_section( $sections ) {
	
	$sections['vendor'] = __( 'Függőség beállítások', 'dpdclassic' );
	return $sections;
	
}

add_filter( 'woocommerce_get_settings_dpdclassic', 'vendor_all_settings', 10, 2 );
function vendor_all_settings( $settings, $current_section ) {
	if ( $current_section == 'vendor' ) {
		$settings_vendor = array();
		$settings_vendor[] = array( 'name' => __( 'Külső csomagok élérése', 'dpdclassic' ), 'type' => 'title', 'desc' => __( 'A Bedrock almappából nem látható csomagok elérési útja.', 'dpdclassic' ), 'id' => 'vendor' );
		$settings_vendor[] = array(
			'name'     => __( 'Elérési út', 'dpdclassic' ),
			'desc_tip' => __( 'A vendor mappa betöltő elérési útja', 'dpdclassic' ),
			'id'       => 'vendorpath',
			'type'     => 'text',
			'desc'     => __( 'A vendor mappa betöltő elérési útja', 'dpdclassic' ),
			'default'     => __( '/var/www/html/bedrock/vendor/autoload.php', 'dpdclassic' ),
		);
		$settings_vendor[] = array( 'type' => 'sectionend', 'id' => 'vendor' );
		return $settings_vendor;
	} else {
		return $settings;
	}
}

add_action( 'woocommerce_order_details_after_order_table', 'dpd_custom_field_display_cust_order_meta', 10, 1 );
add_action( 'woocommerce_admin_order_data_after_shipping_address', 'dpd_custom_field_display_cust_order_meta', 10, 1 );

function dpd_custom_field_display_cust_order_meta($order){
    $parcel=get_post_meta($order->get_id(),'dpdparcel',true);
    if(!empty($parcel)){
	$api = new DPD\API([
		    'username' => get_option('weblabeluser'),
		    'password' => get_option('weblabelpass'),
		    'log_dir'  => dirname(__FILE__).'/log/'
	]);
	$status_msg = $api->getParcelStatus($parcel);
        echo '<p><strong>'.__('DPD csomag állapota:').':</strong> ' .$status_msg. '</p>';
    }
}
