<?php
/*
  Plugin Name: WooCommerce ProNewsletter
  Description: Plugin for newsletter subscription.
  Version: 1.0
  Author: Viktor Rajcsanyi
  Author URI:  http://promera.hu
  Text Domain: pronewsletter
  Domain Path: /languages
 */

if (!defined('ABSPATH'))
    exit;

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

if (!class_exists('Newsletter_Table')) {
    require_once( plugin_dir_path(__FILE__) . 'newsletter-table.php' );
}

$orderstatuses = array();

add_action('plugins_loaded', 'newsletter_init', 10, 1);
add_action('admin_menu', 'newsletter_create_page');

function newsletter_create_page() {
    add_menu_page(__('Hírlevélre feliratkozók','pronewsletter'), __('Hírlevélre feliratkozók','pronewsletter'), 'list_users', 'newsletter', 'newsletter_menu', 'dashicons-admin-generic', 51);
    add_submenu_page('newsletter', __('Feliratkozók','pronewsletter'), __('Feliratkozók','pronewsletter'), 'list_users', 'newsletter', 'newsletter_menu');
}

function newsletter_init() {
	load_plugin_textdomain( 'pronewsletter', false, dirname(plugin_basename(__FILE__)).'/languages/' );
}

function newsletter_menu() {
    echo "<h1 class=\"wp-heading-inline\">".__('Hírlevél','pronewsletter')."</h1><br/>".__('A hírlevélre feliratkozott vásárlók listája.','pronewsletter');
    wp_reset_query();
    $newsletter_table = new Newsletter_Table();
    $newsletter_table->prepare_items();
    echo "<form id=\"newsletter-table\" method=\"get\">";
    $newsletter_table->display();
    echo "</form>";
}

if (!class_exists('WC_Settings_Newsletter')) :
    if (!class_exists('WC_Settings_Page')) {
        require_once( substr(plugin_dir_path(__FILE__), 0, strlen(plugin_dir_path(__FILE__)) - 14) . '/woocommerce/includes/admin/settings/class-wc-settings-page.php' );
    }

    function newsletter_add_settings() {

        class WC_Settings_Newsletter extends WC_Settings_Page {

            public function __construct() {
                $this->id = 'newsletter';
                $this->label = __('Hírlevél', 'pronewsletter');
                add_filter('woocommerce_settings_tabs_array', array($this, 'add_settings_page'), 20);
                add_action('woocommerce_settings_' . $this->id, array($this, 'output'));
                add_action('woocommerce_settings_save_' . $this->id, array($this, 'save'));
                add_action('woocommerce_sections_' . $this->id, array($this, 'output_sections'));
            }

            public function get_sections() {
                $sections = array(
                    'setup' => __('Section 1', 'pronewsletter')
                );
                return apply_filters('woocommerce_get_sections_' . $this->id, $sections);
            }

            public function get_settings($current_section = '') {
                $settings = apply_filters('newsletter_section1_settings', array(
                    array(
                        'type' => 'checkbox',
                        'id' => 'send_newsletter',
                        'name' => __('Hírlevél küldése', 'pronewsletter'),
                        'desc' => __('A hírlevél küldésének ki-be kapcsolása', 'pronewsletter'),
                        'default' => 'yes',
                    ))
                );
                return apply_filters('woocommerce_get_settings_' . $this->id, $settings, $current_section);
            }

            public function output() {
                global $current_section;
                $settings = $this->get_settings($current_section);
                WC_Admin_Settings::output_fields($settings);
            }

            public function save() {
                global $current_section;
                $settings = $this->get_settings($current_section);
                WC_Admin_Settings::save_fields($settings);
            }

        }

        return new WC_Settings_Newsletter();
    }

    add_filter('woocommerce_get_settings_pages', 'newsletter_add_settings', 15);
endif;

add_action('register_form', 'newsletter_registration_form');

function newsletter_registration_form() {
    if (!empty($_POST['pronewsletter']))
        $pronewsletter = $_POST['pronewsletter'];
    else
        $pronewsletter = "";    
?>
<p>
    <label for="pronewsletter"><?php esc_html_e('Hírlevél', 'pronewsletter') ?><br/>
    <input type="checkbox"
           id="pronewsletter"
           name="pronewsletter"
           class="checkbox"
           />
    </label>
</p>
<?php
}

    add_filter('registration_errors', 'newsletter_registration_errors', 10, 3);

    function newsletter_registration_errors($errors, $sanitized_user_login, $user_email) {
            if (empty($_POST['pronewsletter'])) {
/*nem kötelező a mező, a későbbieben pl ha valami mnyereményjátékhoz kell, így lehet ellenőrizni
                $errors->add('pronewsletter', __('<strong>HIBA</strong>: Kérem, fogadja el a lehetőséget!', 'pronewsletter'));
*/
            }
        return $errors;
    }

    add_action('user_register', 'newsletter_user_register');
    add_action('personal_options_update', 'newsletter_user_register' );
    add_action('edit_user_profile_update', 'newsletter_user_register' );

    function newsletter_user_register($user_id) {
        if (!empty($_POST['pronewsletter'])) {
            update_user_meta($user_id, 'pronewsletter', $_POST['pronewsletter']);
        }
        else{
	    update_user_meta( $user_id, 'pronewsletter', 'off' );
    	}
    }



    add_action('user_profile_update_errors', 'newsletter_user_profile_update_errors', 10, 3);

    function newsletter_user_profile_update_errors($errors, $update, $user) {
            if (empty($_POST['pronewsletter'])) {
//nem kötelező mező                $errors->add('pronewsletter', __('<strong>HIBA</strong>: Kérem fogadja el a lehetőséget!', 'pronewsletter'));
            }
    }

    add_action('edit_user_created_user', 'newsletter_user_register');


/**
* Backend
*/
add_action( 'show_user_profile', 'newsletter_show_extra_profile_fields' );
add_action( 'edit_user_profile', 'newsletter_show_extra_profile_fields' );
function newsletter_show_extra_profile_fields( $user ) {
    ?>
    <h3><?php esc_html_e( 'Hírlevél', 'pronewsletter' ); ?></h3>
        <table class="form-table">
        <tr>
        <th><label for="pronewsletter"><?php esc_html_e('Hírlevél', 'pronewsletter'); ?></label></th>
            <td>
                <input type="checkbox"
                       id="pronewsletter"
                       name="pronewsletter"
                       class="checkbox"
<?php
if(get_the_author_meta('pronewsletter', $user->ID)=='on' ){
    echo "checked"; 
} 
?>
                       />
            </td>
        </tr>
        </table>
<?php
}
    

 
