<?php
if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class Newsletter_Table extends WP_List_Table {
   
    public static function get_subscribers() {
	global $wpdb;
	$sql2 ="SELECT user_login,user_nicename,user_email FROM {$wpdb->prefix}users INNER JOIN {$wpdb->prefix}usermeta ON {$wpdb->prefix}users.ID = {$wpdb->prefix}usermeta.user_id WHERE meta_key='pronewsletter' AND meta_value='on' ORDER BY ID;  ";
        $result = $wpdb->get_results( $sql2, 'ARRAY_A' );
	return $result;
    }   

    public function __construct() {
	parent::__construct( array(
		'singular' => __( 'feliratkozó', 'pronewsletter' ),     
		'plural'   => __( 'feliratkozók', 'pronewsletter' ),    
		'ajax'     => false,       
		) );
    }
	
    public function get_columns() {
        $columns = [
        	'user_login' => __( 'Login', 'pronewsletter' ),
        	'user_nicename' => __( 'Név', 'pronewsletter' ),
		'user_email' => __('Email', 'pronewsletter')
	];
        return $columns;
    }
	
    protected function get_sortable_columns() {
	$sortable_columns = array(
	);
        return $sortable_columns;
    }

    function column_user_login( $item ) {
        $title = $item['user_login'];
        return $title;
    }

    function column_user_nicename( $item ) {
        $title = $item['user_nicename'];
        return $title;
    }

    function column_user_email( $item ) {
        $title = $item['user_email'];
        return $title;
    }
    

    protected function column_default( $item, $column_name ) {
	switch ( $column_name ) {
		case 'Login':
		case 'user_nicename':
	        return $item[ $column_name ];
            default:
                return print_r( $item, true );
        }
    }

    function prepare_items() {
	global $wpdb; 
	$per_page = 25;
	$columns  = $this->get_columns();
	$hidden   = array();
	$sortable = $this->get_sortable_columns();
	$this->_column_headers = array( $columns, $hidden, $sortable );
		$data = $this->get_subscribers();
		usort( $data, array( $this, 'usort_reorder' ) );
		$current_page = $this->get_pagenum();
		$total_items = count( $data );
		$data = array_slice( $data, ( ( $current_page - 1 ) * $per_page ), $per_page );
		$this->items = $data;
		$this->set_pagination_args( array(
			'total_items' => $total_items,                    
			'per_page'    => $per_page,  
			'total_pages' => ceil( $total_items / $per_page ), 
		) );
	}


}

