<?php

namespace DPD\Exception;

class ParcelGeneration extends Response {

}
 