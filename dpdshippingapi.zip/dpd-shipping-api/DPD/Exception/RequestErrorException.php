<?php
namespace DPD\Exception;


class RequestErrorException extends Response
{

}