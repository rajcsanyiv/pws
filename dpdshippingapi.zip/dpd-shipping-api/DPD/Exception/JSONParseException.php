<?php
namespace DPD\Exception;

class JSONParseException extends \Exception
{

}