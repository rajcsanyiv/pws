<?php
/*
Plugin Name: Woocommerce picture storage
Version: 1.0
Description: A plugin where we store the pictures not connected to products.
Author: Viktor Rajcsanyi
Author URI: viktor.rajcsanyi@promera.hu
Text Domain: woopic
*/

