<?php

include_once('Promera_LifeCycle.php');

class Promera_Plugin extends Promera_LifeCycle {

    public function getOptionMetaData() {
        return array(
            'ATextInput' => array(__('Enter in some text', 'promera-plugin')),
            'AmAwesome' => array(__('I like this awesome plugin', 'promera-plugin'), 'false', 'true'),
            'CanDoSomething' => array(__('Which user role can do something', 'promera-plugin'), 'Administrator', 'Editor', 'Author', 'Contributor', 'Subscriber', 'Anyone')
        );
    }

    protected function initOptions() {
        $options = $this->getOptionMetaData();
        if (!empty($options)) {
            foreach ($options as $key => $arr) {
                if (is_array($arr) && count($arr > 1)) {
                    $this->addOption($key, $arr[1]);
                }
            }
        }
    }

    public function getPluginDisplayName() {
        return 'Promera';
    }

    protected function getMainPluginFileName() {
        return 'promera.php';
    }

    protected function unInstallDatabaseTables() {
    }

    public function upgrade() {
        
    }

    public function addActionsAndFilters() {
        add_action('admin_menu', array(&$this, 'addSettingsSubMenuPage'));
        add_action('admin_enqueue_scripts', function() {
            wp_enqueue_style('admin-styles', plugins_url('css/admin.css', __FILE__));
            wp_enqueue_script('admin-scripts', plugins_url('js/admin.js', __FILE__));
        });
        add_filter('woocommerce_cart_shipping_method_full_label', function($label, $method) {
            $cost = (int) $method->cost;
            if ($cost <= 0) {
                $label .= ': ' . ($cost == 0 ? wc_price(0) : '<span class="empty_amount amount">&nbsp;</span>');
            }
            $label = '<span class="ctitle col-md-8">' . str_replace([': ', ' amount'], ['</span>', ' amount col-md-3 text-right'], $label);
            return $label;
        }, 10, 2);
        // </editor-fold>
        // <editor-fold defaultstate="collapsed" desc="default shipping chosen method false">
        add_filter('woocommerce_shipping_chosen_method', '__return_false', 99);
        add_filter('pre_option_woocommerce_default_gateway' . '__return_false', 99);
        // </editor-fold>
        // <editor-fold defaultstate="collapsed" desc="free shipping">
        function isFree() {
            $free_shipping_settings = get_option('woocommerce_free_shipping_6_settings');
            $min_amount = (int)$free_shipping_settings['min_amount'];
            $total = WC()->cart->get_cart_contents_total();
            if (wc_prices_include_tax()) {
                $total += WC()->cart->get_cart_contents_tax();
            }
            if ($min_amount && $total >= $min_amount) {
                return true;
            }
            foreach (WC()->cart->get_applied_coupons() as $code) {
                $coupon = new WC_Coupon($code);
                if ($coupon->get_free_shipping()) {
                    return true;
                }
            }
            return false;
        };
        add_filter('woocommerce_shipping_rate_cost', function($value) {
            if (isFree()) {
                $value = 0;
            }
            return $value;
        });
        add_filter('woocommerce_shipping_rate_taxes', function($value) {
            if (isFree()) {
                $value = array();
            }
            return $value;
        });

        // </editor-fold>

        //wp_enqueue_script('checkout', plugins_url('js/checkout.js', __FILE__), array('jquery'));
        wp_localize_script('checkout', 'myAjaxObject', array(
            'ajax_url' => admin_url('admin-ajax.php')));
        // add_action('admin_enqueue_scripts', array(&$this, 'adminScripts'));
        // piktogrammok
        add_action('woocommerce_checkout_before_customer_details', array(&$this, 'checkout_extra'));
        // extra fieldek a fizeteshez
        add_filter('woocommerce_checkout_fields', array(&$this, 'override_checkout_fields'));
        // alapertelmezett dolgok megvaltoztatasa
        add_filter('woocommerce_default_address_fields', array(&$this, 'override_default_address_fields'));
        add_filter('woocommerce_billing_fields', array(&$this, 'custom_woocommerce_billing_fields'));
        add_filter('woocommerce_shipping_fields', array(&$this, 'custom_woocommerce_shipping_fields'));
        add_filter('woocommerce_form_field_select', array(&$this, 'custom_woocommerce_form_field_text'), 10, 2);
        add_filter('woocommerce_form_field_text', array(&$this, 'custom_woocommerce_form_field_text'), 10, 2);
        add_filter('woocommerce_form_field_tel', array(&$this, 'custom_woocommerce_form_field_text'), 10, 2);
        add_filter('woocommerce_form_field_email', array(&$this, 'custom_woocommerce_form_field_text'), 10, 2);
        add_filter('woocommerce_form_field_password', array(&$this, 'custom_woocommerce_form_field_text'), 10, 2);
        // szamlazasi adatok utani resz
        add_filter('woocommerce_after_checkout_billing_form', array(&$this, 'after_billing'));
        // szallitas utani resz
        add_filter('woocommerce_after_order_notes', array(&$this, 'after_shipping'));
        // a javascript miatt
        add_filter('woocommerce_after_checkout_form', array(&$this, 'after_all'));
        // uj account letrehozasa
        add_action('user_register', array(&$this, 'save_account'));
        // mini cart icon hook
        add_action('woocommerce_after_mini_cart', array(&$this, 'mini_cart'));
        // validalas
        add_filter('woocommerce_after_checkout_validation', array(&$this, 'validate_extra_co_fields'), 999, 2);
        add_filter('woocommerce_after_save_address_validation', array(&$this, 'validate_extra_fields'));
        // product oldalon extra infok
        add_action('woocommerce_product_options_inventory_product_data', array(&$this, 'product_extra'));
        // remove trash from pages
        add_filter('post_row_actions', array(&$this, 'disable_trash'));
        // disable auto empty trash
        add_action('init', array(&$this, 'remove_empty_trash'));
        // create phpmailer
        add_action('phpmailer_init', array(&$this, 'init_phpmailer'));
        // filter product price by customer
        add_filter('woocommerce_get_price_html', array(&$this, 'change_product_html'));
//        add_filter('woocommerce_cart_item_price',
//                   array(&$this, 'change_product_price_cart'));
        add_action('woocommerce_before_calculate_totals', array(&$this, 'add_custom_price'));
        // remove cart total
        add_action('woocommerce_after_cart', array(&$this, 'remove_cart_total'));
        // phone mező placeholder felülírás
        add_action('woocommerce_after_edit_account_address_form', array(&$this, 'override_changing_address_field'));
        // post input placeholder felülírás
        add_action('wp_footer', array(&$this, 'override_posts_input_fields'));
    }

}
/*
add_filter( 'woocommerce_localisation_address_formats' , 'woo_includes_address_formats', 10, 1);

function woo_includes_address_formats($address_formats) {

error_log("asdf",0);
error_log("{city}",0);
$address_formats['HU'] = "{name}\n{company}\n{city}\n{address_1}\n{address_2}, {address_3} emelet {address_4} ajtó\n{postcode}\n{country}";
//$address_formats['default'] = "{name}\n{company}\n{city}\n{address_1}\n{address_2}, {address_3} emelet {address_4} ajtó\n{postcode}\n{country}";
return $address_formats;
}
*/
add_filter( 'woocommerce_default_address_fields', 'woo_new_default_address_fields' );

function woo_new_default_address_fields( $fields ) {

    $fields['vat'] = array(

        'label' => __( 'adószám', 'woocommerce' )

    );

    $order = array(
        "first_name",
        "last_name",
        "vat",
        "company",
        "country",
        "address_1", 
        "address_2", 
        "address_3", 
        "city",
        "postcode"
    );

    foreach($order as $field) {

        $ordered_fields[$field] = $fields[$field];

    }

    $fields = $ordered_fields;

    return $fields;

}

add_filter( 'woocommerce_order_formatted_billing_address' , 'woo_custom_order_formatted_billing_address', 10, 2 );
add_filter( 'woocommerce_order_formatted_shipping_address' , 'woo_custom_order_formatted_shipping_address', 10, 2 );

function woo_custom_order_formatted_billing_address( $address, $WC_Order ) {

    $address = array(
        'first_name'    => $WC_Order->billing_first_name,
        'last_name'     => $WC_Order->billing_last_name,
        'vat'           => $WC_Order->billing_vat,
        'company'       => $WC_Order->billing_company,
        'address_1'     => $WC_Order->billing_address_1,
        'address_2'     => $WC_Order->billing_address_2);
    if(!empty($WC_Order->billing_address_3))
	$address['address_3'] = ", ".$WC_Order->billing_address_3.". emelet";
    else
	$address['address_3'] = $WC_Order->billing_address_3;
    if(!empty($WC_Order->billing_address_4))
	$address['address_4'] = $WC_Order->billing_address_4.". ajtó";
    else
	$address['address_4'] = $WC_Order->billing_address_4;
    $address['city'] = $WC_Order->billing_city;
    $address['postcode'] = $WC_Order->billing_postcode;
    $address['country'] = $WC_Order->billing_country;

    return $address;
}

function woo_custom_order_formatted_shipping_address( $address, $WC_Order ) {

    $address = array(
        'first_name'    => $WC_Order->shipping_first_name,
        'last_name'     => $WC_Order->shipping_last_name,
        'vat'           => $WC_Order->shipping_vat,
        'company'       => $WC_Order->shipping_company,
        'address_1'     => $WC_Order->shipping_address_1,
        'address_2'     => $WC_Order->shipping_address_2);
    if(!empty($WC_Order->shipping_address_3))
	$address['address_3'] = ", ".$WC_Order->shipping_address_3.". emelet";
    else
	$address['address_3'] = $WC_Order->shipping_address_3;
    if(!empty($WC_Order->shipping_address_4))
	$address['address_4'] = $WC_Order->shipping_address_4.". ajtó";
    else
	$address['address_4'] = $WC_Order->shipping_address_4;
    $address['city'] = $WC_Order->shipping_city;
    $address['postcode'] = $WC_Order->shipping_postcode;
    $address['country'] = $WC_Order->shipping_country;

    return $address;
}

add_filter( 'woocommerce_formatted_address_replacements', function( $replacements, $args ){

    $replacements['{vat}'] = $args['vat'];
    return $replacements;

}, 10, 2 );

add_filter( 'woocommerce_localisation_address_formats' , 'woo_includes_address_formats', 10, 1);

function woo_includes_address_formats($address_formats) {

    $address_formats['HU'] = "{name}\n{company}\n{vat}\n{address_1}\n{address_2} {address_3} {address_4}\n{postcode} {city}\n{country}";
    $address_formats['default'] = "{name}\n{company}\n{vat}\n{address_1}\n{address_2} {address_3} {address_4}\n{city} {postcode}\n{country}";

    return $address_formats;

}

function myscript() {
    echo "<script type=\"text/javascript\">";
    include dirname(__FILE__) . '/js/cart.js';
    echo "</script>";
}
add_action('wp_footer', 'myscript');

function email_readonly(){
    $pagename = get_query_var('pagename');  
    if ( !$pagename && $id > 0 ) {  
        $post = $wp_query->get_queried_object();  
        $pagename = $post->post_name;  
    }
    if(is_user_logged_in() && ($pagename != 'my-account')) {
        echo '<script type="text/javascript">
            if (document.getElementById("billing_email") && document.getElementById("billing_email_re")) {
                document.getElementById("billing_email").readOnly = true; 
                document.getElementById("billing_email_re").value = document.getElementById("billing_email").value;
                document.getElementById("billing_email_re").readOnly = true;
            }
        </script>';
    }    
}

add_action('wp_footer', 'email_readonly');

