<?php

class Promera_OptionsManager {

    public function getOptionNamePrefix() {
        return get_class($this) . '_';
    }

    public function getOptionMetaData() {
        return array();
    }

    public function getOptionNames() {
        return array_keys($this->getOptionMetaData());
    }

    protected function initOptions() {
        
    }

    protected function checkUserPermission() {
        // van-e a felhasznalonak legalabb szerkeszto jogosultsaga
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this
            page.', 'promera'));
        }
    }

    protected function deleteSavedOptions() {
        $optionMetaData = $this->getOptionMetaData();
        if (is_array($optionMetaData)) {
            foreach ($optionMetaData as $aOptionKey => $aOptionMeta) {
                $prefixedOptionName = $this->prefix($aOptionKey);
                delete_option($prefixedOptionName);
            }
        }
    }

    public function getPluginDisplayName() {
        return get_class($this);
    }

    public function prefix($name) {
        $optionNamePrefix = $this->getOptionNamePrefix();
        if (strpos($name, $optionNamePrefix) === 0) {
            return $name;
        }
        return $optionNamePrefix . $name;
    }

    public function &unPrefix($name) {
        $optionNamePrefix = $this->getOptionNamePrefix();
        if (strpos($name, $optionNamePrefix) === 0) {
            return substr($name, strlen($optionNamePrefix));
        }
        return $name;
    }

    public function getOption($optionName, $default = null) {
        $prefixedOptionName = $this->prefix($optionName);
        $retVal = get_option($prefixedOptionName);
        if (!$retVal && $default) {
            $retVal = $default;
        }
        return $retVal;
    }

    public function deleteOption($optionName) {
        $prefixedOptionName = $this->prefix($optionName);
        return delete_option($prefixedOptionName);
    }

    public function addOption($optionName, $value) {
        $prefixedOptionName = $this->prefix($optionName);
        return add_option($prefixedOptionName, $value);
    }

    public function updateOption($optionName, $value) {
        $prefixedOptionName = $this->prefix($optionName);
        return update_option($prefixedOptionName, $value);
    }

    public function getRoleOption($optionName) {
        $roleAllowed = $this->getOption($optionName);
        if (!$roleAllowed || $roleAllowed == '') {
            $roleAllowed = 'Administrator';
        }
        return $roleAllowed;
    }

    protected function roleToCapability($roleName) {
        switch ($roleName) {
            case 'Super Admin':
                return 'manage_options';
            case 'Administrator':
                return 'manage_options';
            case 'Editor':
                return 'publish_pages';
            case 'Author':
                return 'publish_posts';
            case 'Contributor':
                return 'edit_posts';
            case 'Subscriber':
                return 'read';
            case 'Anyone':
                return 'read';
        }
        return '';
    }

    public function isUserRoleEqualOrBetterThan($roleName) {
        if ('Anyone' == $roleName) {
            return true;
        }
        $capability = $this->roleToCapability($roleName);
        return current_user_can($capability);
    }

    public function canUserDoRoleOption($optionName) {
        $roleAllowed = $this->getRoleOption($optionName);
        if ('Anyone' == $roleAllowed) {
            return true;
        }
        return $this->isUserRoleEqualOrBetterThan($roleAllowed);
    }

    public function createSettingsMenu() {
        $pluginName = $this->getPluginDisplayName();

        add_menu_page($pluginName . ' Plugin Settings', $pluginName, 'administrator', get_class($this), array(&$this, 'settingsPage'));

        add_action('admin_init', array(&$this, 'registerSettings'));
    }

    public function registerSettings() {
        $settingsGroup = get_class($this) . '-settings-group';
        $optionMetaData = $this->getOptionMetaData();
        foreach ($optionMetaData as $aOptionKey => $aOptionMeta) {
            register_setting($settingsGroup, $aOptionMeta);
        }
    }

    public function settingsPage() {
        $this->checkUserPermission();

        $optionMetaData = $this->getOptionMetaData();

        if ($optionMetaData != null) {
            foreach ($optionMetaData as $aOptionKey => $aOptionMeta) {
                if (isset($_POST[$aOptionKey])) {
                    $this->updateOption($aOptionKey, $_POST[$aOptionKey]);
                }
            }
        }

        $settingsGroup = get_class($this) . '-settings-group';
        ?>
        <div class="wrap">
            <h2><?php _e('System Settings', 'promera'); ?></h2>
            <table cellspacing="1" cellpadding="2"><tbody>
                    <tr><td><?php _e('System', 'promera'); ?></td><td><?php echo php_uname(); ?></td></tr>
                    <tr><td><?php _e('PHP Version', 'promera'); ?></td>
                        <td><?php echo phpversion(); ?>
                            <?php
                            if (version_compare('5.2', phpversion()) > 0) {
                                echo '&nbsp;&nbsp;&nbsp;<span style="background-color: #ffcc00;">';
                                _e('(WARNING: This plugin may not work properly with versions earlier than PHP 5.2)', 'promera');
                                echo '</span>';
                            }
                            ?>
                        </td>
                    </tr>
                    <tr><td><?php _e('MySQL Version', 'promera'); ?></td>
                        <td><?php echo $this->getMySqlVersion() ?>
                            <?php
                            echo '&nbsp;&nbsp;&nbsp;<span style="background-color: #ffcc00;">';
                            if (version_compare('5.0', $this->getMySqlVersion()) > 0) {
                                _e('(WARNING: This plugin may not work properly with versions earlier than MySQL 5.0)', 'promera');
                            }
                            echo '</span>';
                            ?>
                        </td>
                    </tr>
                </tbody></table>

            <h2><?php
                echo $this->getPluginDisplayName();
                echo ' ';
                _e('Settings', 'promera');
                ?></h2>

            <form method="post" action="">
                <?php settings_fields($settingsGroup); ?>
                <style type="text/css">
                    table.plugin-options-table {width: 100%; padding: 0;}
                    table.plugin-options-table tr:nth-child(even) {background: #f9f9f9}
                    table.plugin-options-table tr:nth-child(odd) {background: #FFF}
                    table.plugin-options-table tr:first-child {width: 35%;}
                    table.plugin-options-table td {vertical-align: middle;}
                    table.plugin-options-table td+td {width: auto}
                    table.plugin-options-table td > p {margin-top: 0; margin-bottom: 0;}
                </style>
                <table class="plugin-options-table"><tbody>
                        <?php
                        if ($optionMetaData != null) {
                            foreach ($optionMetaData as $aOptionKey => $aOptionMeta) {
                                $displayText = is_array($aOptionMeta) ? $aOptionMeta[0] : $aOptionMeta;
                                ?>
                                <tr valign="top">
                                    <th scope="row"><p><label for="<?php echo $aOptionKey ?>"><?php echo $displayText ?></label></p></th>
                                    <td>
                                        <?php $this->createFormControl($aOptionKey, $aOptionMeta, $this->getOption($aOptionKey)); ?>
                                    </td>
                                </tr>
                                <?php
                            }
                        }
                        ?>
                    </tbody></table>
                <p class="submit">
                    <input type="submit" class="button-primary"
                           value="<?php _e('Save Changes', 'promera') ?>"/>
                </p>
            </form>
        </div>
        <?php
    }

    protected function createFormControl($aOptionKey, $aOptionMeta, $savedOptionValue) {
        if (is_array($aOptionMeta) && count($aOptionMeta) >= 2) {
            $choices = array_slice($aOptionMeta, 1);
            ?>
            <p><select name="<?php echo $aOptionKey ?>" id="<?php echo $aOptionKey ?>">
                    <?php
                    foreach ($choices as $aChoice) {
                        $selected = ($aChoice == $savedOptionValue) ? 'selected' : '';
                        ?>
                        <option value="<?php echo $aChoice ?>" <?php echo $selected ?>><?php echo $this->getOptionValueI18nString($aChoice) ?></option>
                        <?php
                    }
                    ?>
                </select></p>
            <?php
        } else {
            ?>
            <p><input type="text" name="<?php echo $aOptionKey ?>" id="<?php echo $aOptionKey ?>"
                      value="<?php echo esc_attr($savedOptionValue) ?>" size="50"/></p>
                <?php
            }
        }

        protected function getOptionValueI18nString($optionValue) {
            switch ($optionValue) {
                case 'true':
                    return __('true', 'promera');
                case 'false':
                    return __('false', 'promera');
                case 'Administrator':
                    return __('Administrator', 'promera');
                case 'Editor':
                    return __('Editor', 'promera');
                case 'Author':
                    return __('Author', 'promera');
                case 'Contributor':
                    return __('Contributor', 'promera');
                case 'Subscriber':
                    return __('Subscriber', 'promera');
                case 'Anyone':
                    return __('Anyone', 'promera');
            }
            return $optionValue;
        }

        protected function getMySqlVersion() {
            global $wpdb;
            $rows = $wpdb->get_results('select version() as mysqlversion');
            if (!empty($rows)) {
                return $rows[0]->mysqlversion;
            }
            return false;
        }

        public function getEmailDomain() {
            $sitename = strtolower($_SERVER['SERVER_NAME']);
            if (substr($sitename, 0, 4) == 'www.') {
                $sitename = substr($sitename, 4);
            }
            return $sitename;
        }

        public function topLevelMenu() {
            $this->checkUserPermission();
            ?>
        <div class="wrap">
            <h1><?= esc_html(get_admin_page_title()); ?></h1>
            <p>Üdvözöllek!
                Ebben a menüben tudod elérni a Promera webáruház extra funkcióit.
                Kérlek válassz az almenük közül.</p>
        </div>
        <?php
    }

    public function remove_empty_trash() {
        remove_action('wp_scheduled_delete', 'wp_scheduled_delete');
    }

    public function init_phpmailer(&$phpmailer) {
//        require_once ABSPATH . WPINC . '/class-phpmailer.php';
//        require_once ABSPATH . WPINC . '/class-smtp.php';
//        $phpmailer = new PHPMailer( true );
        // Set to use SMTP()
        $phpmailer->isSMTP();
        $phpmailer->Host = SMTP_HOST;
        $phpmailer->SMTPAuth = SMTP_AUTH;
        $phpmailer->Port = SMTP_PORT;
        $phpmailer->Username = SMTP_USER;
        $phpmailer->Password = SMTP_PASS;
        $phpmailer->SMTPSecure = SMTP_SECURE;
        $phpmailer->From = SMTP_FROM;
        $phpmailer->FromName = SMTP_NAME;
    }

    function disable_trash($actions) {
        unset($actions['trash']);
        return $actions;
    }

    public function product_extra() {
        global $woocommerce, $post, $product, $wpdb;
        $id = $post->ID;
        $sql = "SELECT p.meta_value FROM {$wpdb->prefix}postmeta p WHERE
        p.post_id = '$id' AND p.meta_key = '_stock'";
        $stock = $wpdb->get_var($sql);
        $sql = "SELECT SUM(woim.meta_value) FROM
        {$wpdb->prefix}woocommerce_order_itemmeta woim JOIN
        {$wpdb->prefix}woocommerce_order_items woi ON woi.order_item_id =
        woim.order_item_id JOIN {$wpdb->prefix}posts p ON p.id = woi.order_id
        WHERE woim.order_item_id IN (SELECT order_item_id FROM
        {$wpdb->prefix}woocommerce_order_itemmeta WHERE meta_key = '_product_id'
        AND meta_value = '$id') AND woim.meta_key = '_qty' AND p.post_type =
        'shop_order' AND p.post_status NOT IN ('wc-completed',
        'wc-cancelled');";
        $result = $wpdb->get_var($sql);
        echo '<p class="form-field"><label for="_fr">Függő rendelések</label>' . (string) $result . '</p>';
        $raktar = (int) $result + (int) $stock;
        echo '<p class="form-field"><label for="_rk">Raktárban</label>' . $raktar . '</p>';
    }

    public function validate_extra_co_fields(&$data, &$errors) {
        //email
        if ($_POST['billing_email'] != $_POST['billing_email_re']) {
            $errors->add('validation__billing_email_re', 'A két email cím nem egyezik!');
        }
        //phone
        if (!(preg_match('/^[0-9]{7,10}$/D', $_POST['billing_phone']))) {
            $errors->add('validation__billing_phone', 'Érvénytelen telefonszám. Kérem csak számokat írjon be, minimum 7, maximum 10 számjegy.');
        }
        //password
        if ('no' === get_option('woocommerce_registration_generate_password') && isset($_POST['account_password_re'])) {
            if ($_POST['account_password'] != $_POST['account_password_re']) {
                $errors->add('validation__account_password_re', 'A két jelszó nem egyezik!');
            }
        }
    }

    public function validate_extra_fields() {
        //phone
        if (isset($_POST['billing_phone']) && !(preg_match('/^[0-9]{7,10}$/D', $_POST['billing_phone']))) {
            wc_add_notice("Érvénytelen telefonszám. Kérem csak számokat írjon be, minimum 7, maximum 10 számjegy", 'error', 'error__validation__billing_phone__r' . rand(1000, 9999));
        }
        //email
        if ($_POST['billing_email'] != $_POST['billing_email_re']) {
            wc_add_notice('A két email cím nem egyezik!', 'error', 'error__validation__billing_email_re__r' . rand(1000, 9999));
        }
    }

    public function save_account($uid) {
        update_user_meta($uid, 'first_name', esc_sql($_POST['reg_first_name']));
        update_user_meta($uid, 'last_name', esc_sql($_POST['reg_last_name']));
        update_user_meta($uid, 'iscompany', esc_sql($_POST['billing_iscompany']));
    }

    public function override_default_address_fields($fields) {
        $forder = array(
            'iscompany',
            'title',
            'last_name',
            'first_name',
            'company',
            'vat',
            'country',
            'postcode',
            'city',
            'address_1',
            'address_2',
            'address_3',
            'address_4',
        );
        $fields = array_merge(array('iscompany' => array('type' => 'select', 'label' => 'Magánszemély vagy Cég', 'required' => true, 'options' => array('false' => 'Magánszemély', 'true' => 'Cég'),)), $fields);
        $fields = array_merge(array('title' => array('type' => 'select', 'label' => 'Megszólítás', 'required' => false, 'options' => array('option_0' => ' ', 'option_1' => 'Hölgy', 'option_2' => 'Úr'),)), $fields);
        $fields = array_merge(array('vat' => array('type' => 'text', 'label' => 'Adószám', 'required' => true,)), $fields);
        $fields = array_merge(array('address_3' => array('type' => 'text', 'label' => 'Ajtó', 'required' => false,)), $fields);
        $fields = array_merge(array('address_4' => array('type' => 'text', 'label' => 'Emelet', 'required' => false,)), $fields);
        $fields['address_2']['label'] = 'Házszám';
        $fields['address_2']['required'] = true;
        $fields['address_3']['label'] = 'Emelet';
        $fields['address_3']['required'] = false;
        $fields['address_4']['label'] = 'Ajtó';
        $fields['address_4']['required'] = false;
        foreach (array_keys($fields) as $idx) {
            unset($fields[$idx]['autofocus']);
            unset($fields[$idx]['class']);
            unset($fields[$idx]['placeholder']);
            if (!in_array($idx, $forder)) {
                unset($fields[$idx]);
            }
        }
        $fields['iscompany']['autofocus'] = true;
        $fields['title']['autofocus'] = true;
        $c = 10;
        $ordered_fields = array();
        foreach ($forder as $idx) {
            $fields[$idx]['priority'] = $c;
            $c += 10;
            $ordered_fields[$idx] = $fields[$idx];
        }
        $ordered_fields['company']['required'] = true;
        $ordered_fields['iscompany']['class'] = array('col100');
        $ordered_fields['title']['class'] = array('col10');
        $ordered_fields['last_name']['class'] = array('col20');
        $ordered_fields['first_name']['class'] = array('col20');
        $ordered_fields['company']['class'] = array('col25');
        $ordered_fields['vat']['class'] = array('col25');
        $ordered_fields['country']['class'] = array('col100');
        $ordered_fields['postcode']['class'] = array('col14');
        $ordered_fields['city']['class'] = array('col26');
        $ordered_fields['address_1']['class'] = array('col30');
        $ordered_fields['address_2']['class'] = array('col10');
        $ordered_fields['address_3']['class'] = array('col10');
        $ordered_fields['address_4']['class'] = array('col10');
        if (isset($_POST['billing_iscompany']) && (!$_POST['billing_iscompany'] || $_POST['billing_iscompany'] == 'false')) {
            $ordered_fields['company']['required'] = false;
            $ordered_fields['vat']['required'] = false;
        }
        //echo '<pre>' . print_r($ordered_fields, true) . '</pre>';
        return $ordered_fields;
    }

    public function custom_woocommerce_billing_fields($fields) {
        $forder = array(
            'billing_iscompany',
            'billing_title',
            'billing_last_name',
            'billing_first_name',
            'billing_company',
            'billing_vat',
            'billing_country',
            'billing_postcode',
            'billing_city',
            'billing_address_1',
            'billing_address_2',
            'billing_address_3',
            'billing_address_4',
            'billing_email',
            'billing_email_re',
            'billing_phone',
        );
        if (!isset($fields['billing_email'])) {
            $fields['billing_email'] = array('type' => 'email', 'label' => 'E-mail cím', 'required' => true, 'validate' => array('email'), 'autocomplete' => 'email username');
        }
        $fields['billing_email_re'] = $fields['billing_email'];
        $fields['billing_email_re']['label'] .= ' újra';
        if (!isset($fields['billing_phone'])) {
            $fields['billing_phone'] = array('type' => 'tel', 'label' => 'Telefonszám', 'required' => true, 'validate' => array('phone'), 'autocomplete' => 'tel');
        }
        foreach (array_keys($fields) as $idx) {
            if (!in_array($idx, $forder)) {
                unset($fields[$idx]);
            }
        }
        $c = 10;
        $ordered_fields = array();
        foreach ($forder as $idx) {
            $fields[$idx]['priority'] = $c;
            $c += 10;
            $ordered_fields[$idx] = $fields[$idx];
        }
        $ordered_fields['billing_email']['class'] = array('col50');
        $ordered_fields['billing_email_re']['class'] = array('col50');
        $ordered_fields['billing_phone']['class'] = array('col50');
        //echo '<pre>' . print_r($ordered_fields, true) . '</pre>';
        return $ordered_fields;
    }

    public function custom_woocommerce_shipping_fields($fields) {
        unset($fields['shipping_iscompany']);
        unset($fields['shipping_company']);
        unset($fields['shipping_vat']);
        //echo '<pre>' . print_r($fields, true) . '</pre>';
        return $fields;
    }

    public function override_checkout_fields($fields) {
        if ('no' === get_option('woocommerce_registration_generate_password')) {
            $fields['account']['account_password_re'] = array(
                'type' => 'password',
                'label' => esc_attr__('Jelszó újra', 'promera'),
                'required' => true,
                'placeholder' => '',
                'priority' => 500,
            );
        }
        if (isset($fields['account']['account_password'])) {
            if (!isset($fields['account']['account_password']['class']))
                $fields['account']['account_password']['class'] = array();
            $fields['account']['account_password']['class'][] = 'col50';
            if (!isset($fields['account']['account_password_re']['class']))
                $fields['account']['account_password_re']['class'] = array();
            $fields['account']['account_password_re']['class'][] = 'col50';
        }
        return $fields;
    }

    public function custom_woocommerce_form_field_text($field, $key) {
        //echo '<pre>' . print_r($key, true) . '</pre>';
        $field = str_replace('form-row ', 'form-row2 ', $field);
        if ($key == 'billing_phone') {
            if(is_user_logged_in()) {
//              $field = str_replace('<input', '<span class="phone-plus36">+36</span><input disabled', $field) . '<p class="form-row2 col50">&nbsp;</p>';
                $field = str_replace('<input', '<span class="phone-plus36">+36</span><input', $field) . '<p class="form-row2 col50">&nbsp;</p>';
            }
            else {
                $field = str_replace('<input', '<span class="phone-plus36">+36</span><input', $field) . '<p class="form-row2 col50">&nbsp;</p>';
            }
        } else if ($key == 'shipping_first_name') {
            $field .= '<p class="form-row2 col50">&nbsp;</p>';
        } else if ($key == 'billing_first_name') {
            $field .= '<script src="/wp-content/plugins/promera/js/checkout.js"></script>';
        }
        // if (in_array($key, array('billing_title', 'account_password', 'shipping_last_name'))) {
        //     $field = '<div class="col_left">' . $field;
        // } else if (in_array($key, array('billing_company', 'billing_address_2', 'shipping_company', 'shipping_address_2'))) {
        //     $field = '</div><div class="col_right">' . $field;
        // } else if (in_array($key, array('billing_postcode', 'billing_email', 'shipping_postcode'))) {
        //     $field = '</div><div class="col_left">' . $field;
        // } else if (in_array($key, array('billing_phone', 'account_password_re'))) {
        //     $field = '</div><div class="col_right">' . $field . '</div>';
        // } else if (in_array($key, array('shipping_address_4'))) {
        //     $field = $field . '</div>';
        // }
        return $field;
    }

    public function override_changing_address_field() {
        
    }

    public function override_posts_input_fields() {
        
    }

}
