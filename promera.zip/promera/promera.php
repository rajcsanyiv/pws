<?php
/*
Plugin Name: Promera Extension
Description: Promera webshop custom functions
Version: 0.1.0
Author: Zoltan Adorjan / Promera
Author URI: http://promera.hu
Text Domain: promera
Domain Path: /languages
*/

$Promera_minimalRequiredPhpVersion = '5.0';

function Promera_noticePhpVersionWrong() {
    global $Promera_minimalRequiredPhpVersion;
    echo '<div class="updated fade">' .
      __('Error: plugin "Promera" requires a newer version of PHP to be running.',
      'promera').
            '<br/>' . __('Minimal version of PHP required: ', 'promera') .
            '<strong>' . $Promera_minimalRequiredPhpVersion . '</strong>' .
            '<br/>' . __('Your server\'s PHP version: ', 'promera') . '<strong>' .
            phpversion() . '</strong>' .
         '</div>';
}

function Promera_PhpVersionCheck() {
    global $Promera_minimalRequiredPhpVersion;
    if (version_compare(phpversion(), $Promera_minimalRequiredPhpVersion) < 0) {
        add_action('admin_notices', 'Promera_noticePhpVersionWrong');
        return false;
    }
    return true;
}

function Promera_i18n_init() {
    $pluginDir = dirname(plugin_basename(__FILE__));
    load_plugin_textdomain('promera', false, $pluginDir . '/languages/');
}

add_action('plugins_loadedi','Promera_i18n_init');

if (Promera_PhpVersionCheck()) {
    include_once('promera_init.php');
    Promera_init(__FILE__);
}
