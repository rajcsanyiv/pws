(function ($) {
    initWCSPPP = function () {
        $('#sprinter_ppp_code').val('');
        $('#sprinter_ppp_name').val('');
        $('#sprinter_ppp_address').val('');
    };
})(jQuery);

function receiveMessage(event) {
    var data = jQuery.parseJSON(event.data);
    //console.log(data);
    jQuery('#sprinter_ppp_code').val(data.shopCode);
    jQuery('#sprinter_ppp_name').val(data.pppShopName ? data.pppShopName : data.shopName);
    jQuery('#sprinter_ppp_address').val(data.address);
}
