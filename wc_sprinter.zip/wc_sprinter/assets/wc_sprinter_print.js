jQuery(document).ready(function ($) {
    $('.s-print').on('keyup keypress', function (e) {
        var keyCode = e.keyCode || e.which;
        e.preventDefault();
        if (keyCode === 13) {
            $(this).trigger('click');
        }
    }).on('click', function (e) {
        e.preventDefault();
        var w = window.open($(this).attr('data'));
        w.print();
        //w.close();
    });
    if ($('#s-print-lpl').length) {
        $('#s-print-lpl').focus();
    }
});
