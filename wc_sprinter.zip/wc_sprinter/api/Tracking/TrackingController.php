<?php

//{"PartnerCode":"0000001000","TrackingInfoList":[{"TrackingID":1,"ParcelBarcode":"tracking_test_PPP","HomeDeliveryNoteNumber":null,"ShipmentID":"SP201802270000000012","OriginalBarCode":"tracking_test_PPP","AutorizationCode":"auth_tracking_test_PPP","InvoiceNumber":null,"EventCreatedTime":"2018-03-27T09:06:03.5249597+02:00","DeliveryMode":"PICKPACKPOINT","PartnerMainStatusName":"WAITING_FOR_PACKAGE","PartnerMainStatusDescriptionList":[{"LanguageName":"HU","TranslatedText":"A csomag beérkezésére várunk"},{"LanguageName":"EN","TranslatedText":"Waiting for the parcel toarrive"}],"PartnerSubStatusName":null,"PartnerSubStatusDescriptionList":null,"CustomerStatusName":"WAITING_FOR_PACKAGE_SENDER","CustomerStatusDescriptionList":[{"LanguageName":"HU","TranslatedText":"A csomagot még nem adta át a Feladó szállításra. További információért kérjükkeresse a Feladót (webáruházat)."},{"LanguageName":"EN","TranslatedText":"The sender haven'thanded over the parcel yet. For more information, please call the sender(webshop)."}],"RefuseReasonName":null,"RefuseReasonDescriptionList":null,"CustomerName":"Teszt Elek","ExpectedArrivalFrom":"2018-03-28T09:06:03.5259473+02:00","ExpectedArrivalTo":"2018-03-29T09:06:03.5259473+02:00","DestinationLocationCode":"0000101005","DestinationLocationName":"Teszt Shop","DestinationLocationAddress":"1164, Budapest, Szabadföldi út1.","InternationalDeliveryPartnerName":null,"MeasuredWeight":null},{"TrackingID":2,"ParcelBarcode":"tracking_test_HD","HomeDeliveryNoteNumber":"tracking_test_HD","ShipmentID":"SP201802270000000013","OriginalBarCode":"tracking_test_HD","AutorizationCode":"auth_tracking_test_HD","InvoiceNumber":null,"EventCreatedTime":"2018-03-27T09:06:03.5269488+02:00","DeliveryMode":"HOMEDELIVERY","PartnerMainStatusName":"WAITING_FOR_PACKAGE","PartnerMainStatusDescriptionList":[{"LanguageName":"HU","TranslatedText":"A csomag beérkezésére várunk"},{"LanguageName":"EN","TranslatedText":"Waiting for the parcel toarrive"}],"PartnerSubStatusName":null,"PartnerSubStatusDescriptionList":null,"CustomerStatusName":"SPRINTER_WAITING_FOR_PACKAGE_SENDER","CustomerStatusDescriptionList":[{"LanguageName":"HU","TranslatedText":"A csomagot még nem adta át a Feladó szállításra. További információért kérjük keresse a Feladót (webáruházat)."},{"LanguageName":"EN","TranslatedText":"The sender haven't handed over the parcel yet. For more information, please call the sender(webshop)."}],"RefuseReasonName":null,"RefuseReasonDescriptionList":null,"CustomerName":"Teszt Elek","ExpectedArrivalFrom":"2018-03-28T09:06:03.5269488+02:00","ExpectedArrivalTo":"2018-03-29T09:06:03.5269488+02:00","DestinationLocationCode":null,"DestinationLocationName":null,"DestinationLocationAddress":null,"InternationalDeliveryPartnerName":null,"MeasuredWeight":3.14}]}

function wc_sprinter_tracking_rest() {
    // <editor-fold defaultstate="collapsed" desc="init vars">
    $return = new stdClass();
    $return->format = 'text';
    //At the end return success with HTTP status 200
    $return->data = "success";
    $request = "";
    // </editor-fold>
    try {
        // <editor-fold defaultstate="collapsed" desc="pre check">
        // include other php files
        require_once "Model.php"; //Classes for Json model validation
        require_once ABSPATH . WPINC . "/JsonMapper/JsonMapper.php"; //Helper for Json validation
        require_once ABSPATH . WPINC . "/JsonMapper/Exception.php"; //JsonMapper exception classes
        //Make sure that it is a POST request.
        if (strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0) {
            http_response_code(405); //Method Not Allowed
            $return->data = 'Request method must be POST!';
            return $return;
        }
        //Make sure that the content type of the POST request has been set to application/json
        $contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
        if (strcasecmp($contentType, 'application/json; charset=utf-8') != 0) {
            http_response_code(415); //Unsupported Media Type
            $return->data = "Content type must be: application/json; charset=utf-8. Request content type was: " . $contentType;
            return $return;
        }
        //Receive the RAW post data.
        $request = trim(file_get_contents("php://input"));
        //Attempt to decode the incoming RAW post data from JSON.
        $contentObjectFromJson = json_decode($request);
        try {
            //Map and validate the Json object to the UnifiedParcelTrackingInfo class.
            //https://github.com/cweiske/jsonmapper
            $mapper = new JsonMapper();
            $mapper->bExceptionOnMissingData = true; //Validate required fields!
            /* @var $validatedContentObject UnifiedParcelTrackingInfo */
            $validatedContentObject = $mapper->map($contentObjectFromJson, new UnifiedParcelTrackingInfo());
            /* @var $TrackingInfoList TrackingInfo[] */
            $TrackingInfoList = $validatedContentObject->TrackingInfoList;
            if (count($TrackingInfoList) == 0) {
                http_response_code(400); //Bad Request
                $return->data = "The request is invalid. " . PHP_EOL . "ErrorMessage: The TrackingInfoList is empty! " . PHP_EOL . "Request was: " . $request;
                return $return;
            }
        } catch (exception $e) {
            http_response_code(400); //Bad Request
            $return->data = "The request is invalid. " . PHP_EOL . "ErrorMessage: " . $e . PHP_EOL . "Request was: " . $request;
            return $return;
        }
        // </editor-fold>
        // <editor-fold defaultstate="collapsed" desc="check">
        $partner_code = get_option('wc_sprinter_partnercode', '0000001000');
        if ($partner_code != $validatedContentObject->PartnerCode) {
            http_response_code(400); //Bad Request
            $return->data = "The request is invalid. " . PHP_EOL . "ErrorMessage: The PartnerCode is invalid! " . PHP_EOL . "Request was: " . $request;
            return $return;
        }
        // </editor-fold>
        // <editor-fold defaultstate="collapsed" desc="processing">
        $dt = new DateTime("now", new DateTimeZone('Europe/Budapest'));
        $dt->setTimestamp(time());
        $_datum = $dt->format('YmdHis');
        $_BR = "\n";
        $set_cdorders_state = function($order, $state) {
            $cdid = get_post_meta($order->get_id(), 'collective_delivery_id', true);
            $cdorderids = false;
            if ($cdid) {
                $cdorderids = get_post_meta($order->get_id(), 'collective_delivery_join_orders', true);
            }
            if ($cdorderids) {
                foreach ($cdorderids as $cdorderid) {
                    $cdorder = wc_get_order($cdorderid);
                    $cdorder->update_status($state);
                }
            }
        };
        foreach ($TrackingInfoList as $trackingItem) {
            $log = 'Sprinter TRACKING szolgáltatás log - ' . $_datum . $_BR;
            $order_id = explode('-', $trackingItem->ParcelBarcode);
            $order_id = $order_id[1];
            $order = wc_get_order($order_id);
            foreach ($trackingItem as $k => $v) {
                $log .= str_replace('List', '', $k) . ': ';
                if (is_array($v)) {
                    foreach ($v as $lv) {
                        if ($lv->LanguageName == 'HU') {
                            $log .= $lv->TranslatedText;
                            break;
                        }
                    }
                } else {
                    $log .= $v;
                }
                $log .= $_BR;
            }
            $order_sprinter_data = get_post_meta($order->get_id(), 'wc_sprinter_data', true);
            if (empty($order_sprinter_data)) {
                $order_sprinter_data = array();
            }
            $order_sprinter_data[$_datum . '-ParcelTracking-' . $trackingItem->PartnerMainStatusName] = $log;
            update_post_meta($order->get_id(), 'wc_sprinter_data', $order_sprinter_data);
            $order->add_order_note(__('A csomagkövetési információk frissültek.', 'wc_sprinter'), 0, true);
            
            
            if ($trackingItem->PartnerMainStatusName == 'WAITING_FOR_PACKAGE' && (!$trackingItem->PartnerSubStatusName || $trackingItem->PartnerSubStatusName == 'NULL')) {
                $order->update_status('order-sent');
                $set_cdorders_state($order, 'order-sent');
            } else if ($trackingItem->PartnerMainStatusName == 'DELIVERED') {
                $order->update_status('completed');
                $set_cdorders_state($order, 'completed');
            } else if ($trackingItem->PartnerMainStatusName == 'DELIVERY_UNSUCCESSFUL' && (!$trackingItem->PartnerSubStatusName || $trackingItem->PartnerSubStatusName == 'NULL')) {
                $order->update_status('failed');
                $set_cdorders_state($order, 'failed');
            } else if ($trackingItem->PartnerMainStatusName == 'RETURN' && $trackingItem->PartnerSubStatusName == 'PACKAGE_HANDED_OVER_TO_CONSIGNER') {
                $order->update_status('cancelled');
                $set_cdorders_state($order, 'cancelled');
            }
        }
        // </editor-fold>
    } catch (Exception $e) {
        // <editor-fold defaultstate="collapsed" desc="Internal Server Error">
        http_response_code(500); //Internal Server Error
        $return->data = "Error occured! " . PHP_EOL . "ErrorMessage: " . $e . PHP_EOL . "Request was: " . $request;
        return $return;
        // </editor-fold>
    }
    return $return;
}
