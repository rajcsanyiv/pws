jQuery(document).ready(function ($) {
    selMethod = $('#shipping_method input[checked="checked"]').val();
    s_shipment_method_change();
    $(document).on('change', "#shipping_method input", function (e) {
        e.preventDefault();
        selMethod = $(this).val();
        s_shipment_method_change();
    });
});

function s_shipment_method_change() {
    $ = jQuery;
    var chdiff = $('#ship-to-different-address-checkbox');
    var fextra = $(".woocommerce-shipping-fields-extra");
    chdiff.attr('checked', false).trigger('change');
    fextra.hide();
    if (selMethod) {
        $('input[name="payment_method"]').prop('disabled', false);
        if (selMethod.match(/pont_sprinter/g)) {
            chdiff.attr('checked', false).trigger('change');
            fextra.hide();
            $(".sprinter_ppp.woocommerce-shipping-fields-extra").show();
            if (typeof initWCSPPP == 'function') {
                initWCSPPP();
            }
        } 
    }
}

