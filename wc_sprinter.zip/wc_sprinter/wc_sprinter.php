<?php
/**
 * Plugin Name: Sprinter API
 * Description: Sprinter futárszolgálat API.
 * Version: 1.0
 * Author: Naszádi László [WBS]
 * Text Domain: wc_sprinter
 * Domain Path: /languages/
 */
if (!defined('ABSPATH')) {
    exit;
}
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    exit;
}

function addsprintermenu(){
	add_menu_page('Sprinter csomagok listája',
                      'Sprinter csomagok',
                      'manage_options',
                      'wc_sprinter',
                      array(&$this, 'topLevelMenu'));
        $subMenus = array();     
        $subMenus['Sprinter csomagok'] = 'wc_sprinter_packages';
        foreach($subMenus as $key => $value) {
            add_submenu_page('wc_sprinter',
                             $key,
                             $key,
                             'manage_options',
                             $value,
                             array(&$this, $value));
        }
}

add_action( 'admin_menu', 'addsprintermenu' );

function wc_sprinter_packages() {
        WC_Sprinter::instance()->render_page();
}


// <editor-fold defaultstate="collapsed" desc="settings page">
function wc_sprinter_add_settings() {

    if (!class_exists('WC_Sprinter_Settings_Page')) {

        class WC_Sprinter_Settings_Page extends WC_Settings_Page {

            public function __construct() {
                parent::__construct();
                $this->id = 'wc_sprinter';
                $this->label = __('Sprinter', 'wc_sprinter');
                add_filter('woocommerce_settings_tabs_array', array($this, 'add_settings_page'), 20);
                add_action('woocommerce_settings_' . $this->id, array($this, 'output'));
                add_action('woocommerce_settings_save_' . $this->id, array($this, 'save'));
            }

            public function get_settings() {
                $settings = apply_filters('wc_sprinter_settings', array(
                    array(
                        'name' => __('Sprinter API plugin beállítások', 'wc_sprinter'),
                        'type' => 'title',
                        'desc' => '',
                        'id' => 'wc_sprinter_main_title',
                    ),
                    array(
                        'name' => __('Partner token', 'wc_sprinter'),
                        'id' => 'wc_sprinter_partnertoken',
                        'type' => 'text',
                        'default' => 'testtoken1',
                        'desc' => __('Partner (feladó) hitelesítő. Ez nem jelenik meg sehol. A Partner csomagfeladását hitelesítő mező. 10 karakter hosszú, kisbetűket és számokat tartalmaz!. Teszteléshez: "testtoken1"', 'wc_sprinter'),
                        'desc_tip' => true,
                    ),
                    array(
                        'name' => __('Partner kód', 'wc_sprinter'),
                        'id' => 'wc_sprinter_partnercode',
                        'type' => 'text',
                        'default' => '0000001000',
                        'desc' => __('Partner (feladó) azonosító. Ez megjelenik a könyvelésben és a címkén is. A Partner csomagfeladását hitelesítő mező. 10 karakter hosszú!. Teszteléshez: "0000001000"', 'wc_sprinter'),
                        'desc_tip' => true,
                    ),
                    array(
                        'name' => __('Partner azonosító', 'wc_sprinter'),
                        'id' => 'wc_sprinter_authcode',
                        'type' => 'text',
                        'default' => 'PROMERA',
                        'desc' => __('A partner azonosító kódja a csomaghoz. Ez megjelenik a könyvelésben és a címkén is. Követés során kereshető.', 'wc_sprinter'),
                        'desc_tip' => true,
                    ),
//                    array(
//                        'name' => __('Címke/fuvarlevél méret', 'wc_sprinter'),
//                        'type' => 'select',
//                        'id' => 'wc_sprinter_label_size',
//                        'options' => array(
//                            'small' => __('KICSI - A4-es lapon 8 db fér el', 'wc_sprinter'),
//                            'normal' => __('NORMÁL - A4-es lapon 4 db fér el', 'wc_sprinter'),
//                        ),
//                    ),
//                    array(
//                        'name' => __('Címke/fuvarlevél lapméret', 'wc_sprinter'),
//                        'type' => 'select',
//                        'id' => 'wc_sprinter_label_pagesize',
//                        'options' => array(
//                            'A7' => __('A7 fekvő - 105x74 mm', 'wc_sprinter'),
//                            'A6' => __('A6 álló - 105x148 mm', 'wc_sprinter'),
//                            'A5' => __('A5 fekvő - 210x148 mm', 'wc_sprinter'),
//                            'A4' => __('A4 álló - 210x297 mm', 'wc_sprinter'),
//                        ),
//                        'desc' => __('"A7"-es lapméret esetén a címke mérete mindenképpen "KICSI" lesz.', 'wc_sprinter'),
//                        'desc_tip' => true,
//                    ),
                    array(
                        'name' => __('Csomag alapértelmezett súlya', 'wc_sprinter'),
                        'id' => 'wc_sprinter_parcelsize_weight',
                        'type' => 'number',
                        'css' => 'max-width:80px;text-align:center;',
                        'custom_attributes' => array(
                            'min' => '1',
                            'max' => '20',
                            'step' => '1',
                        ),
                        'default' => '5',
                        'desc' => __('kg-ban, maximum 20kg', 'wc_sprinter'),
                        'desc_tip' => true,
                    ),
                    array(
                        'name' => __('PPP Csomag alapértelmezett mérete', 'wc_sprinter'),
                        'type' => 'select',
                        'id' => 'wc_sprinter_parcelsize_ppp',
                        'options' => array(
                            'Small' => __('Kicsi - X: 20cm, Y: 30cm, Z: 10cm, Volume: 0.006000m3', 'wc_sprinter'),
                            'Medium' => __('Közepes - X: 30cm, Y: 30cm, Z: 20cm, Volume: 0.018000m3', 'wc_sprinter'),
                            'Large' => __('Nagy - X: 50cm, Y: 50cm, Z: 50cm, Volume: 0.125000m3', 'wc_sprinter'),
                            'Special' => __('Speciális - X: 60cm, Y: 60cm, Z: 60cm, Volume: 0.216000m3', 'wc_sprinter'),
                            'None' => __('Nincs megadva méret', 'wc_sprinter'),
                        ),
                        'desc' => __('PPP csomagok esetén értelmezett csomag méret besorolás.', 'wc_sprinter'),
                        'desc_tip' => true,
                    ),
                    array(
                        'name' => __('Csomag alapértelmezett mérete (X)', 'wc_sprinter'),
                        'id' => 'wc_sprinter_parcelsize_x',
                        'type' => 'number',
                        'css' => 'max-width:100px;text-align:center;',
                        'custom_attributes' => array(
                            'min' => '10',
                            'step' => '1',
                        ),
                        'default' => '20',
                        'desc' => __('cm-ben, legnagyobb csomag X dimenziója ???', 'wc_sprinter'),
                        'desc_tip' => true,
                    ),
                    array(
                        'name' => __('Csomag alapértelmezett mérete (Y)', 'wc_sprinter'),
                        'id' => 'wc_sprinter_parcelsize_y',
                        'type' => 'number',
                        'css' => 'max-width:100px;text-align:center;',
                        'custom_attributes' => array(
                            'min' => '10',
                            'step' => '1',
                        ),
                        'default' => '30',
                        'desc' => __('cm-ben, legnagyobb csomag Y dimenziója ???', 'wc_sprinter'),
                        'desc_tip' => true,
                    ),
                    array(
                        'name' => __('Csomag alapértelmezett mérete (Z)', 'wc_sprinter'),
                        'id' => 'wc_sprinter_parcelsize_z',
                        'type' => 'number',
                        'css' => 'max-width:100px;text-align:center;',
                        'custom_attributes' => array(
                            'min' => '10',
                            'step' => '1',
                        ),
                        'default' => '40',
                        'desc' => __('cm-ben, legnagyobb csomag y dimenziója ???', 'wc_sprinter'),
                        'desc_tip' => true,
                    ),
                    array(
                        'name' => __('Szállítási alapértelmezett idő', 'wc_sprinter'),
                        'type' => 'select',
                        'id' => 'wc_sprinter_transittime',
                        'options' => array(
                            '0' => __('délelött 9 óra előtti', 'wc_sprinter'),
                            '1' => __('délelőtt 9-12 óra között', 'wc_sprinter'),
                            '2' => __('1 munkanapos', 'wc_sprinter'),
                            '3' => __('2 munkanapos', 'wc_sprinter'),
                            '4' => __('3 munkanapos', 'wc_sprinter'),
                            '5' => __('5 munkanapos', 'wc_sprinter'),
                        ),
                        'default' => '2',
                    ),
                    array(
                        'type' => 'sectionend',
                        'id' => 'wc_sprinter_group1_options'
                    ),
                ));
                return apply_filters('woocommerce_get_settings_' . $this->id, $settings);
            }

            public function output() {
                $settings = $this->get_settings();
                WC_Admin_Settings::output_fields($settings);
                ?><script type="text/javascript">
                    (function ($) {
                        $("#wc_sprinter_label_pagesize").unbind("change").change(function () {
                            if ($(this).val() == "A7") {
                                $("#wc_sprinter_label_size").val("small");
                            }
                        });
                    })(jQuery);
                </script><?php
            }

            public function save() {
                $settings = $this->get_settings();
                $data = $_POST;
                if (isset($data['wc_sprinter_label_pagesize']) && $data['wc_sprinter_label_pagesize'] == 'A7') {
                    $data['wc_sprinter_label_size'] = 'small';
                }
                WC_Admin_Settings::save_fields($settings, $data);
            }

            /**
             *
             * @staticvar \WC_Sprinter_Settings_Page $instance
             * @return \WC_Sprinter_Settings_Page
             */
            public static function instance() {
                static $instance = null;
                if (!$instance) {
                    $instance = new WC_Sprinter_Settings_Page();
                }
                return $instance;
            }

        }

    }

    return WC_Sprinter_Settings_Page::instance();
}

add_filter('woocommerce_get_settings_pages', 'wc_sprinter_add_settings', 15);
// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="pont sprinter shipping method">
add_action('woocommerce_shipping_init', 'wc_pont_sprinter_shipping_method_init');

function wc_pont_sprinter_shipping_method_init() {

    if (!class_exists('WC_Pont_Sprinter_Shipping_Method')) {

        class WC_Pont_Sprinter_Shipping_Method extends WC_Shipping_Method {

            var $notify_url;

            public function __construct($instance_id = 0) {
                parent::__construct($instance_id);
                $this->id = 'pont_sprinter';
                $this->instance_id = absint($instance_id);
                $this->method_title = __('Pick Pack Pont (Sprinter)', 'wc_sprinter');
                $this->method_description = __('Pick Pack Pont szállítási mód, Sprinter-es változat.', 'wc_sprinter');
                $this->notify_url = WC()->api_request_url('WC_Pont_Sprinter_Shipping_Method');
                $this->supports = array(
                    'shipping-zones',
                    'instance-settings',
                    'instance-settings-modal',
                );
                $this->instance_form_fields = array(
                    'title' => array(
                        'title' => __('Method title', 'woocommerce'),
                        'type' => 'text',
                        'description' => __('This controls the title which the user sees during checkout.', 'woocommerce'),
                        'default' => __('PickPackPont', 'wc_sprinter'),
                        'desc_tip' => true,
                    ),
                    'tax_status' => array(
                        'title' => __('Tax status', 'woocommerce'),
                        'type' => 'select',
                        'class' => 'wc-enhanced-select',
                        'default' => 'taxable',
                        'options' => array(
                            'taxable' => __('Taxable', 'woocommerce'),
                            'none' => _x('None', 'Tax status', 'woocommerce'),
                        ),
                    ),
                    'cost' => array(
                        'title' => __('Cost', 'woocommerce'),
                        'type' => 'text',
                        'placeholder' => '',
                        'description' => __('Enter a cost (excl. tax) or sum, e.g. <code>10.00 * [qty]</code>.', 'woocommerce') . '<br/><br/>' . __('Use <code>[qty]</code> for the number of items, <br/><code>[cost]</code> for the total cost of items, and <code>[fee percent="10" min_fee="20" max_fee=""]</code> for percentage based fees.', 'woocommerce'),
                        'default' => '0',
                        'desc_tip' => true,
                    )
                );
                $this->title = $this->get_option('title');
                $this->tax_status = $this->get_option('tax_status');
                $this->cost = $this->get_option('cost');
                //$this->type = $this->get_option('type', 'class');
                add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
            }

            public function calculate_shipping($package = array()) {
                global $woocommerce;
                $rate = array(
                    'id' => $this->id . ':' . $this->instance_id,
                    'label' => $this->title,
                    'cost' => $this->cost,
                    'package' => $package,
                );
                $this->add_rate($rate);
            }

        }

    }
}

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="tracking rest api">

require_once 'api/Tracking/TrackingController.php';
add_action('rest_api_init', function () {
    register_rest_route('sprinter', 'tracking', array(
        'methods' => WP_REST_Server::CREATABLE,
        'callback' => 'wc_sprinter_tracking_rest'
    ));
});
add_filter('rest_pre_serve_request', function ($served, $result, $request, $server) {
    if (isset($result->data->format)) {
        switch ($result->data->format) {
            case 'text':
                header('Content-Type: text/plain; charset=' . get_option('blog_charset'));
                echo $result->data->data;
                $served = true;
                break;
        }
    }
    return $served;
}, 10, 4);

// </editor-fold>

class WC_Sprinter {

    protected static $plugin_basename;
    protected static $plugin_path;
    protected static $plugin_url;
    protected static $plugin_upload_subdir;
    protected static $plugin_upload_path;
    protected static $plugin_upload_url;

    protected function __construct() {

        self::$plugin_basename = plugin_basename(__FILE__);
        self::$plugin_path = plugin_dir_path(self::$plugin_basename);
        self::$plugin_url = plugin_dir_url(self::$plugin_basename);
        self::$plugin_upload_subdir = '/uploads/sprinter';
        self::$plugin_upload_path = WP_CONTENT_DIR . self::$plugin_upload_subdir;
        self::$plugin_upload_url = get_site_url() . '/wp-content' . self::$plugin_upload_subdir;

        add_action('init', array($this, 'init_actions'));
        add_action('add_meta_boxes', array($this, 'add_meta_box_sprinter'), 9, 2);
        add_action('woocommerce_checkout_before_order_review', array($this, 'wc_sprinter_html_before'), 1);
        add_action('woocommerce_checkout_process', array($this, 'wc_sprinter_checkout_process'));
        add_action('woocommerce_checkout_update_order_meta', array($this, 'wc_sprinter_checkout_update_order_meta'));
        add_action('woocommerce_thankyou', array($this, 'wc_sprinter_meta_h2'), 20);
        add_action('woocommerce_admin_order_data_after_shipping_address', array($this, 'wc_sprinter_meta_h4'));
        add_action('woocommerce_email_after_order_table', array($this, 'wc_sprinter_meta_h2_x'), 20);
        add_action('woocommerce_view_order', array($this, 'wc_sprinter_meta_h2'), 20);

        add_filter('woocommerce_shipping_methods', array($this, 'add_shipping_method'));
        add_filter('woocommerce_order_hide_shipping_address', array($this, 'ppp_order_hide_shipping_address'), 10, 2);

        wp_enqueue_script('wc-sprinter', self::$plugin_url . 'assets/wc_sprinter.js', array('jquery'), '3.2');
    }

    // <editor-fold defaultstate="collapsed" desc="plugin functions">

    public static function plugin_basename() {
        return self::$plugin_basename;
    }

    public static function plugin_path() {
        return self::$plugin_path;
    }

    public static function plugin_url() {
        return self::$plugin_url;
    }

    public static function plugin_upload_subdir() {
        return self::$plugin_upload_subdir;
    }

    public static function plugin_upload_path() {
        return self::$plugin_upload_path;
    }

    public static function plugin_upload_url() {
        return self::$plugin_upload_url;
    }

    // </editor-fold>
    // <editor-fold defaultstate="collapsed" desc="actions">

    public function init_actions() {
        if (!session_id()) {
            session_start();
        }
        load_plugin_textdomain('wc_sprinter', false, self::$plugin_path . 'languages');
        if (!is_dir(self::$plugin_upload_path)) {
            mkdir(self::$plugin_upload_path, 0777, true);
        }
    }

    /**
     *
     * @param string $post_type
     * @param WP_Post $post
     */
    public function add_meta_box_sprinter($post_type, $post) {
        if ('shop_order' == $post_type) {
            $order = wc_get_order($post->ID);
            /* @var $order_shipping_method WC_Order_Item_Shipping */
            $order_shipping_method = array_pop(array_reverse($order->get_shipping_methods()));
            if ($order_shipping_method && preg_match('/(pont_sprinter|flat_rate|collective_delivery)(:[0-9]+)$/', $order_shipping_method->get_method_id())) {
                add_meta_box('sprinter_shop_order_meta_box', esc_html__(' - Sprinter - ', 'wc_sprinter'), array($this, 'render_meta_box_sprinter'), $post_type, 'side');
            }
        }
    }

    public function wc_sprinter_html_before($checkout) {
        $chosen_methods = WC()->session->get('shipping_for_package_0');
        if (!is_array($chosen_methods)) {
            return false;
        }
        echo '<div id="sprinter_ppp_block" class="sprinter_ppp woocommerce-shipping-fields woocommerce-shipping-fields-extra" style="display: none;">';
        echo '<input type="hidden" id="sprinter_ppp_code" name="sprinter_ppp[code]" value="">';
        echo '<input type="hidden" id="sprinter_ppp_name" name="sprinter_ppp[name]" value="">';
        echo '<input type="hidden" id="sprinter_ppp_address" name="sprinter_ppp[address]" value="">';
        echo '<h3 class="cheading">' . __('Válasszon Pick Pack Pont átvevőhelyet', 'wc_sprinter') . '</h3>';
        echo '<iframe width="100%" height="520px" src="https://online.sprinter.hu/terkep/#/"></iframe>';
        echo '<script type="text/javascript">';
        echo '(function ($) {';
        echo 'window.addEventListener("message", receiveMessage, false);';
        //echo 'initWCSPPP();';
        // TODO nem szép megoldás, csak ideiglenes
        //echo 's_shipment_method_change();';
        echo '})(jQuery);';
        echo '</script>';
        echo '</div>';
    }

    public function wc_sprinter_checkout_process() {
        $chosen_methods = WC()->session->get('chosen_shipping_methods');
        if (strstr($chosen_methods[0], 'pont_sprinter') || (strstr($chosen_methods[0], 'collective_delivery') && isset($_POST['cd_type']) && $_POST['cd_type'] == 'owner' && isset($_POST['cd_owner']) && $_POST['cd_owner'] == 'pont_sprinter')) {
            if (empty($_POST['sprinter_ppp']) || empty($_POST['sprinter_ppp']['code'])) {
                wc_add_notice(__('Kérjük válasszon PPP átvevőhelyet', 'wc_sprinter'), 'error', 'error__validation__sprinter_ppp_block__r' . rand(1000, 9999));
            } else {
                unset($_POST['ship_to_different_address']);
                //$shippingFields = array_keys(WC_Checkout::instance()->get_checkout_fields('shipping'));
//                foreach ($shippingFields as $k) {
//                    if (isset($_POST['shipping_' . $k])) {
//                        $_POST['shipping_' . $k] = '';
//                    }
//                }
            }
        }
    }

    public function wc_sprinter_checkout_update_order_meta($order_id) {
        // $chosen_methods = WC()->session->get('chosen_shipping_methods');
        if (!empty($_POST['sprinter_ppp']) && !empty($_POST['sprinter_ppp']['code'])) {
            update_post_meta($order_id, 'sprinter_ppp', $_POST['sprinter_ppp']);
        }
    }

    protected function wc_sprinter_meta_get($order_) {
        $meta = false;
        if (is_array($order_)) {
            $meta = $order_;
        } else {
            $order_id = isset($order_->id) ? $order_->id : $order_;
            $meta = get_post_meta($order_id, 'sprinter_ppp', true);
            if (!$meta) {
                $order_id = isset($order_->id) ? $order_->id : $order_;
                $cdid = get_post_meta($order_id, 'collective_delivery_joined_id', true);
                if ($cdid) {
                    $cdoid = get_post_meta($order_id, 'collective_delivery_joined_order', true);
                    $meta = get_post_meta($cdoid, 'sprinter_ppp', true);
                }
            }
        }
        return $meta;
    }

    protected function wc_sprinter_meta($order_, $title, $w, $x = '') {
        $meta = $this->wc_sprinter_meta_get($order_);
        if (is_array($meta)) {
            echo '<' . $title . '>';
            _e('A kiválasztott PickPackPont átvevőhely', 'wc_sprinter');
            echo '</' . $title . '>';
            echo '<' . $w . $x . '>';
            echo __('azonosító: ', 'wc_sprinter') . $meta['code'] . '<br>';
            echo __('név: ', 'wc_sprinter') . $meta['name'] . '<br>';
            echo __('cím: ', 'wc_sprinter') . $meta['address'] . '<br>';
            echo '</' . $w . '>';
        }
    }

    public function wc_sprinter_meta_h4($order_) {
        $this->wc_sprinter_meta($order_, 'h4', 'p');
    }

    public function wc_sprinter_meta_h2($order_) {
        $this->wc_sprinter_meta($order_, 'h2', 'address');
    }

    public function wc_sprinter_meta_h2_x($order_) {
        $this->wc_sprinter_meta($order_, 'h2', 'address', ' class="address" style="padding-bottom: 12px; margin-bottom: 20px;"');
    }

    /**
     *
     * @param WP_Post $post
     */
    public function render_meta_box_sprinter($post) {
        $order = wc_get_order($post->ID);
        /* @var $order_shipping_method WC_Order_Item_Shipping */
        $order_shipping_method = array_pop(array_reverse($order->get_shipping_methods()));
        esc_html_e('Szállítási mód: ', 'wc_sprinter');
        echo '<em>' . $order->get_shipping_method() . '</em><br>';
        $cdshipping = get_post_meta($order->get_id(), 'collective_delivery_shipping', true);
        if (strstr($order_shipping_method->get_method_id(), 'collective_delivery') && !$cdshipping) {
            echo '<hr>';
            esc_html_e('Kezelése az indító rendelésnél: ', 'wc_sprinter');
            $cdoid = get_post_meta($order->get_id(), 'collective_delivery_joined_order', true);
            echo '<a href="?post=' . $cdoid . '&action=edit">#' . $cdoid . '</a>';
        } else if (strstr($order_shipping_method->get_method_id(), 'flat_rate') || strstr($order_shipping_method->get_method_id(), 'pont_sprinter') || (strstr($order_shipping_method->get_method_id(), 'collective_delivery') && $cdshipping)) {
            $order_sprinter_data = get_post_meta($order->get_id(), 'wc_sprinter_data', true);
            $this->render_page_sprinter_data_files($order, true);
            $this->render_page_sprinter_data_logs($order_sprinter_data, true);
            echo '<hr>';
            echo '<a href="admin.php?page=wc_sprinter_packages&orderid=' . $order->get_id() . '" class="button buton-primary">' . esc_html__('Csomagregisztrálás / Részletek', 'wc_sprinter') . '</a>';
        }
    }

    // </editor-fold>
    // <editor-fold defaultstate="collapsed" desc="filters">

    public function add_shipping_method($methods) {
        $methods['pont_sprinter'] = new WC_Pont_Sprinter_Shipping_Method();
        return $methods;
    }

    public function ppp_order_hide_shipping_address($shipping_methods, $order) {
        $shipping_methods[] = 'pont_sprinter';
        $cdid = get_post_meta($order->get_id(), 'collective_delivery_joined_id', true);
        if ($cdid) {
            $cdoid = get_post_meta($order->get_id(), 'collective_delivery_joined_order', true);
            $ppp = get_post_meta($cdoid, 'sprinter_ppp', true);
            if (is_array($ppp)) {
                $shipping_methods[] = 'collective_delivery';
            }
        }
        return $shipping_methods;
    }

    // </editor-fold>
    // <editor-fold defaultstate="collapsed" desc="render functions">

    public function render_page() {
        $orderid = isset($_GET['orderid']) ? $_GET['orderid'] : '';
        ?><div class="wrap">
            <h2><?php esc_html_e('Sprinter csomagok', 'wc_sprinter'); ?></h2>
            <div class="wrap">
                <hr>
                <form method="GET">
                    <input type="hidden" name="page" value="wc_sprinter_packages">
                    <label for="orderid"><font size="3"><?php esc_html_e('Rendelés azonosító', 'wc_sprinter'); ?></font></label>
                    <input type="text" name="orderid" id="orderid" value="<?php echo $orderid; ?>">
                    <input type="submit" class="button action" value="<?php esc_html_e('LEKÉRDEZ', 'wc_sprinter'); ?>">
                </form>
            </div>
            <script>$('#orderid').on('change', function () {
            var val=document.getElementById('orderid').value;
            if(isNaN(val)===true) {
            }      
            else{ regexp=/^[0|\D]*/g;
                document.getElementById('orderid').value=val.replace(/^[0|\D]*/,'');          
            } 
            });
            </script>
            <?php if ($orderid) { ?>
                <?php
                /* @var $order WC_Order */
                $order = wc_get_order($orderid);
                ?>
                <?php if (!$order) { ?>
                    <div class="notice notice-warning"><p><?php esc_html_e('Nem létező rendelés!', 'wc_sprinter'); ?></p></div>
                <?php } else { ?>
                    <?php
                    /* @var $order_shipping_method WC_Order_Item_Shipping */
                    $order_shipping_method = array_pop(array_reverse($order->get_shipping_methods()));
                    ?>
                    <?php if (!$order_shipping_method || !preg_match('/(pont_sprinter|flat_rate|collective_delivery)(:[0-9]+)$/', $order_shipping_method->get_method_id())) { ?>
                        <div class="notice notice-warning"><p><?php esc_html_e('Csomagfeladáshoz nem értelmezett szállítási metódus!', 'wc_sprinter'); ?></p></div>
                    <?php } else { ?>
                        <?php
                        $order_statuses = wc_get_order_statuses();
                        $order_status_title = esc_html__('ismeretlen', 'wc_sprinter');
                        if (isset($order_statuses['wc-' . $order->get_status()])) {
                            $order_status_title = $order_statuses['wc-' . $order->get_status()];
                        } else if (isset($order_statuses[$order->get_status()])) {
                            $order_status_title = $order_statuses[$order->get_status()];
                        }
                        $cdshipping = get_post_meta($order->get_id(), 'collective_delivery_shipping', true);
                        ?>
                        <div class="wrap">
                            <hr>
                            <h3><u>#<?php echo($orderid . ' ' . esc_html__('rendelés adatai', 'wc_sprinter') . ':'); ?></u></h3>
                            <?php
                            esc_html_e('Szállítási mód: ', 'wc_sprinter');
                            echo '<em>' . $order->get_shipping_method() . '</em><br>';
                            esc_html_e('Fizetési mód: ', 'wc_sprinter');
                            echo '<em>' . $order->get_payment_method_title() . '</em><br>';
                            echo esc_html__('Order status:', 'woocommerce') . ' <em>' . $order_status_title . '</em><br>';
                            if (strstr($order_shipping_method->get_method_id(), 'collective_delivery') && !$cdshipping) {
                                esc_html_e('Kezelése az indító rendelésnél: ', 'wc_sprinter');
                                $cdoid = get_post_meta($order->get_id(), 'collective_delivery_joined_order', true);
                                echo '<a href="?page=wc_sprinter_packages&orderid=' . $cdoid . '">#' . $cdoid . '</a>';
                            } else if (strstr($order_shipping_method->get_method_id(), 'flat_rate') || strstr($order_shipping_method->get_method_id(), 'pont_sprinter') || (strstr($order_shipping_method->get_method_id(), 'collective_delivery') && $cdshipping)) {
                                $total = 0.0;
                                $dlvry = 0.0;
                                $cdid = get_post_meta($order->get_id(), 'collective_delivery_id', true);
                                $this->render_page_shipping_address($order, strstr($order_shipping_method->get_method_id(), 'pont_sprinter') || $cdshipping == 'pont_sprinter');
                                $ok = true;
                                $cdorderids = false;
                                $parcel_count = 1;
                                if ($cdid) {
                                    $cdorderids = get_post_meta($order->id, 'collective_delivery_join_orders', true);
                                    $cdstate = get_post_meta($order->id, 'collective_delivery_state', true);
                                    if ($cdstate != 'close') {
                                        $ok = false;
                                    }
                                    esc_html_e('Gyűjő szállítást kért, melynek azonosítója: ', 'wc_collective_delivery');
                                    echo '<em>' . $cdid . ', ' . esc_html__('állapota: ', 'wc_sprinter') . WC_Collective_Delivery::state_titles()[$cdstate] . '</em><br>';
                                    esc_html_e('Csatlakozott rendelések: ', 'wc_collective_delivery');
                                    if (!empty($cdorderids)) {
                                        $parcel_count += count($cdorderids);
                                        echo '<br>';
                                        foreach ($cdorderids as $cdorderid) {
                                            /* @var $cdorder WC_Order */
                                            $cdorder = wc_get_order($cdorderid);
                                            if ($ok && ($cdorder->get_status() != 'order-packed' && $cdorder->get_status() != 'processing')) {
                                                $ok = false;
                                            }
                                            $cdorder_status_title = esc_html__('ismeretlen', 'wc_sprinter');
                                            if (isset($order_statuses['wc-' . $cdorder->get_status()])) {
                                                $cdorder_status_title = $order_statuses['wc-' . $cdorder->get_status()];
                                            } else if (isset($order_statuses[$cdorder->get_status()])) {
                                                $cdorder_status_title = $order_statuses[$cdorder->get_status()];
                                            }
                                            echo '&nbsp;&nbsp;&nbsp;&bull;&nbsp;&nbsp;#' . $cdorder->get_id() . ', ' . esc_html__('állapota: ', 'wc_sprinter') . '<em>' . $cdorder_status_title . '</em><br>';
                                        }
                                        echo '<br>';
                                    } else {
                                        echo '<em>-</em><br>';
                                    }
                                    $this->render_page_items($order, $total, $dlvry);
                                    if (!empty($cdorderids)) {
                                        foreach ($cdorderids as $cdorderid) {
                                            $this->render_page_items(wc_get_order($cdorderid), $total, $dlvry);
                                        }
                                    }
                                } else {
                                    $this->render_page_items($order, $total, $dlvry);
                                }
                                echo '<h3 style="text-align:right">' . esc_html__('Összesen: ', 'wc_sprinter') . number_format($total) . '</h3>';
                                $this->render_page_sprinter_data($order, $total, $dlvry, $parcel_count, $ok, $cdorderids);
                            }
                        }
                    }
                    ?>
                </div>
            <?php } ?>
        </div><?php
    }

    /**
     *
     * @param WC_Order $order
     * @param boolean $pont
     */
    private function render_page_shipping_address($order, $pont = false) {
        $address = '';
        if ($pont) {
            $meta = $this->wc_sprinter_meta_get($order);
            if (is_array($meta)) {
                $address .= $meta['code'] . ' <b>' . $meta['name'] .'</b>, ' . $meta['address'];
            }
        } else {
            $order_shipping = $order->get_address('shipping');
            $address .= '<b>' . $order_shipping['last_name'] . ' ';
            $address .= $order_shipping['first_name'] . '</b> ';
            if ($order_shipping['company']) {
                $address .= '<b>(' . $order_shipping['company'] . ')</b> ';
            }
            $address .= $order_shipping['postcode'] . ' ';
            $address .= $order_shipping['city'] . ', ';
            $address .= $order_shipping['address_1'] . ' ';
            $address .= $order_shipping['address_2'] . ' ';
            $address .= $order_shipping['address_3'] . ' ';
            $address .= $order_shipping['address_4'] . ' ';
        }
        esc_html_e('Szállítási adatok: ', 'wc_sprinter');
        echo '<em>' . $address . '</em><br>';
    }

    /**
     *
     * @param WC_Order $order
     * @return float
     */
    private function render_page_items($order, &$total, &$dlvry) {
        echo '<h4 style="margin: 5px;">#' . $order->get_id() . ' ' . esc_html__('rendelés tételei', 'wc_sprinter') . '</h4>';
        echo '<table class="widefat fixed" cellspacing="0">';
        echo '<thead>';
        echo '</thead>';
        echo '<tbody>';
        $items = $order->get_items();
        $items_total = 0.0;
        /* @var $item WC_Order_Item_Product */
        foreach ($items as $item_id => $item) {
            /* @var $prod WC_Product_Simple */
            $prod = $item->get_product();
            $ptotal = $item->get_total() + $item->get_total_tax();
            $price = $ptotal / (float)$item->get_quantity();
            $items_total += $ptotal;
            $total += $ptotal;
            echo '<tr>';
            echo '<td>' . $prod->get_sku() . '</td>';
            echo '<td>' . $item->get_name() . '</td>';
            echo '<td style="text-align:right">' . $item->get_quantity() . '</td>';
            echo '<td style="text-align:right">' . number_format($price) . '</td>';
            echo '<td style="text-align:right">' . number_format($ptotal) . '</td>';
            echo '</tr>';
        }
        echo '</tbody>';
        $_dlvry += $order->get_shipping_total() + $order->get_shipping_tax();
        $dlvry += $_dlvry;
        $items_total += $_dlvry;
        $total += $_dlvry;
        echo '<tfoot>';
        echo '<tr>';
        echo '<td colspan="4" style="font-style:italic;">' . $order->get_shipping_method() . '</td>';
        echo '<td style="text-align:right;">' . esc_html__('szállítási díj: ', 'wc_sprinter') . number_format($_dlvry) . '</td>';
        echo '</tr>';
        echo '<tr><td colspan="5" style="text-align:right;font-weight:bold">' . esc_html__('összesen: ', 'wc_sprinter') . number_format($items_total) . '</td></tr>';
        echo '</tfoot>';
        echo '</table>';
    }

    /**
     *
     * @param WC_Order $order
     * @param float $items_total
     * @param int $parcel_count
     * @param boolean $ook
     */
    private function render_page_sprinter_data($order, $total, $dlvry, $parcel_count = 1, $ook = true, $cdorderids = false) {
        ini_set('error_reporting', E_ALL ^ E_NOTICE);
        ini_set('display_errors', '1');
        // <editor-fold defaultstate="collapsed" desc="package pack">
        if (isset($_POST['package_pack'])) {
            $order->update_status('order-packed');
            if ($cdorderids) {
                foreach ($cdorderids as $cdorderid) {
                    $cdorder = wc_get_order($cdorderid);
                    $cdorder->update_status('order-packed');
                }
            }
            echo "<script type='text/javascript'> window.location=document.location.href; </script>";
        }
        // </editor-fold>
        $PackagePrice = (int) round($total - $dlvry);
        $PriceAtDelivery = $order->get_payment_method() == 'cod' ? (int) round($total) : 0;
        /* @var $order_shipping_method WC_Order_Item_Shipping */
        $order_shipping_method = array_reverse($order->get_shipping_methods());
        $order_shipping_method = array_pop($order_shipping_method);
        $cdshipping = get_post_meta($order->get_id(), 'collective_delivery_shipping', true);
        $order_shipping_method_type = '';
        if (strstr($order_shipping_method->get_method_id(), 'flat_rate') || $cdshipping == 'flat_rate') {
            $order_shipping_method_type = 'homedelivery';
        } else if (strstr($order_shipping_method->get_method_id(), 'pont_sprinter') || $cdshipping == 'pont_sprinter') {
            $order_shipping_method_type = 'pickpackpoint';
        }
        $order_ppp_meta = '';
        if ($order_shipping_method_type == 'pickpackpoint') {
            $order_ppp_meta = get_post_meta($order->get_id(), 'sprinter_ppp', true);
        }
        $order_sprinter_data = get_post_meta($order->get_id(), 'wc_sprinter_data', true);
        if (empty($order_sprinter_data)) {
            $order_sprinter_data = array();
        }
        $order_billing = $order->get_address();
        $order_shipping = $order->get_address('shipping');
        $CustomerName = ($order_shipping['last_name'] ? $order_shipping['last_name'] : $order_billing['last_name']) . ' ';
        $CustomerName .= ($order_shipping['first_name'] ? $order_shipping['first_name'] : $order_billing['first_name']);
        if ($order_shipping['company']) {
            $CustomerName .= ' (' . ($order_shipping['company'] ? $order_shipping['company'] : $order_billing['company']) . ')';
        }
        $CustomerPhone = $order_billing['phone'];
        $CustomerEmail = $order_billing['email'];
        $CustomerPostalCode = ($order_shipping['postcode'] ? $order_shipping['postcode'] : $order_billing['postcode']);
        $CustomerCity = ($order_shipping['city'] ? $order_shipping['city'] : $order_billing['city']);
        $CustomerAddress = ($order_shipping['address_1'] ? $order_shipping['address_1'] : $order_billing['address_1']);
        $CustomerStreetNumber = ($order_shipping['address_2'] ? $order_shipping['address_2'] : $order_billing['address_2']);
        $CustomerStreetNumber .= ' ' . (isset($order_shipping['address_3']) && $order_shipping['address_3'] ? $order_shipping['address_3'] : (isset($order_billing['address_3']) ? $order_billing['address_3'] : ''));
        $CustomerStreetNumber .= '/' . (isset($order_shipping['address_4']) && $order_shipping['address_4'] ? $order_shipping['address_4'] : (isset($order_billing['address_4']) ? $order_billing['address_4'] : ''));
        $CustomerStreetNumber = trim($CustomerStreetNumber, " \t\n\r\0\x0B/");
        $CustomerNote = mb_substr($order->get_customer_note(), 0, 100);
        //$op_label_size = get_option('wc_sprinter_label_size', 'small');
        //$op_label_pagesize = get_option('wc_sprinter_label_pagesize', 'A4');
        $op_parcelsize_weight = (int) get_option('wc_sprinter_parcelsize_weight', 5);
        $op_parcelsize_ppp = get_option('wc_sprinter_parcelsize_ppp', 'Small');
        $op_parcelsize_x = (int) get_option('wc_sprinter_parcelsize_x', 20);
        $op_parcelsize_y = (int) get_option('wc_sprinter_parcelsize_y', 30);
        $op_parcelsize_z = (int) get_option('wc_sprinter_parcelsize_z', 40);
        $op_transittime = (int) get_option('wc_sprinter_transittime', 2);
        // <editor-fold defaultstate="collapsed" desc="post parcel">
        if (isset($_POST['parcel_type']) && $_POST['parcel_type']) {
            $felt = $_POST['PriceAtDelivery'] >= 0 && $_POST['PackagePrice'] >= 0;
            $felt = $felt && $_POST['CustomerName'] && $_POST['CustomerPhone'] && $_POST['CustomerEmail'] && $_POST['CustomerPostalCode'] && $_POST['CustomerCity'] && $_POST['CustomerAddress'] && $_POST['CustomerStreetNumber'];
            $felt = $felt && $_POST['PackageWeight'] >= 1 && $_POST['PackageWeight'] <= 20;
            if ($_POST['parcel_type'] == 'pickpackpoint') {
                $felt = $felt && in_array($_POST['PackageSizePPP'], array('Small', 'Medium', 'Large', 'Special', 'None'));
            } else if ($_POST['parcel_type'] == 'homedelivery') {
                $felt = $felt && $_POST['PackageSizeX'] >= 10 && $_POST['PackageSizeY'] >= 10 && $_POST['PackageSizeZ'] >= 10;
                $felt = $felt && $_POST['TransitTime'] >= 0 && $_POST['TransitTime'] <= 5;
            }
            $felt = $felt && $_POST['ParcelCount'] >= 1 && $_POST['ParcelCount'] <= 100;
            if ($felt) {
                $partner_code = get_option('wc_sprinter_partnercode', '0000001000');
                $partner_token = get_option('wc_sprinter_partnertoken', 'testtoken1');
                $auth_code = get_option('wc_sprinter_authcode', 'PROMERA') . '-' . $order->get_id();
                try {
                    require_once 'api/ParcelRegistration/PudoDocumentService.php';
                    require_once 'api/ParcelRegistration/PartnerPudoService.php';
                    // SOAP client options
                    $soap_options = array(
                        'features' => SOAP_SINGLE_ELEMENT_ARRAYS,
                        'cache_wsdl' => WSDL_CACHE_NONE
                    );
                    // WCF wsdl server url
                    $PartnerPudoServiceWSDL = "https://tsx.lapker.hu/PudoTest/PartnerPudoService?wsdl";
                    $PudoDocumentServiceWSDL = "https://tsx.lapker.hu/PudoTest/PudoDocumentService?wsdl";

                    $dt = new DateTime("now", new DateTimeZone('Europe/Budapest'));
                    $dt->setTimestamp(time());
                    $_datum = $dt->format('YmdHis');
                    $_prefix = $auth_code . '-' . count($order_sprinter_data); // unique barcode prefix, the customer service gives it to the partners
                    $_sufix = 'XXX';
                    $ParcelContainer = array(); //List of Parcels

                    if (in_array($_POST['parcel_type'], array('homedelivery', 'pickpackpoint'))) {
                        // <editor-fold defaultstate="collapsed" desc="parcel">
                        //#region Home delivery (HomeDelivery)
                        $Parcel = new Parcel();
                        // required field, it decides the service type
                        if ($_POST['parcel_type'] == 'pickpackpoint') {
                            $_sufix = 'PPP';
                            $Parcel->ServiceType = ParcelServiceType::$Normal; // Partner hands over the parcel at depot
                            //Destination PPP shop code (where the customer takes over the parcel)
                            $Parcel->DestinationLocationId = $order_ppp_meta['code']; //Set Package Destination location
                            //Size category (default small)
                            $Parcel->PackageType = $_POST['PackageSizePPP']; // PackageType::$Small;
                            switch ($Parcel->PackageType) {
                                case PackageType::$Small:
                                    $Parcel->PackageSizeX = 20;
                                    $Parcel->PackageSizeY = 30;
                                    $Parcel->PackageSizeZ = 10;
                                    break;
                                case PackageType::$Medium:
                                    $Parcel->PackageSizeX = 30;
                                    $Parcel->PackageSizeY = 30;
                                    $Parcel->PackageSizeZ = 20;
                                    break;
                                case PackageType::$Large:
                                    $Parcel->PackageSizeX = 50;
                                    $Parcel->PackageSizeY = 50;
                                    $Parcel->PackageSizeZ = 50;
                                    break;
                                case PackageType::$Special:
                                    $Parcel->PackageSizeX = 60;
                                    $Parcel->PackageSizeY = 60;
                                    $Parcel->PackageSizeZ = 60;
                                    break;
                            }
                        } else {
                            $_sufix = 'HD';
                            $Parcel->ServiceType = ParcelServiceType::$HomeDeliver; //Home delivery to the customer
                            // Parcel Size X dimension (in centimeters) (Optional)
                            $Parcel->PackageSizeX = (int) $_POST['PackageSizeX'];
                            // Parcel Size Y dimension (in centimeters) (Optional)
                            $Parcel->PackageSizeY = (int) $_POST['PackageSizeY'];
                            // Parcel Size Z dimension (in centimeters) (Optional)
                            $Parcel->PackageSizeZ = (int) $_POST['PackageSizeZ'];
                            //Transit time type
                            $Parcel->TransitTime = (int) $_POST['TransitTime'];
                            //     0 - Before 9 A.M
                            //     1 - Between 9 and 12 A.M
                            //     2 - 1 working day
                            //     3 - 2 working days
                            //     4 - 3 working days
                            //     5 - 5 working days
                            //Delivers from Partner to customer
                            $Parcel->DeliveryType = ParcelDeliveryType::$OnlyDelivery;
                        }
                        // Parcel Volume (m3) (Optional)
                        if ($Parcel->PackageSizeX) {
                            $Parcel->PackageVolume = number_format($Parcel->PackageSizeX * $Parcel->PackageSizeY * $Parcel->PackageSizeZ / 1000000, 6);
                        }
                        // Logistics barcode(with the unique prefix). Max 28 chars length
                        // It has to be unique and contains only ean128 format characters
                        $Parcel->BarCode = $_prefix . '-' . $_sufix; //Unique generated barcode
                        // Accounting barcode, the partner's identifier code for the parcel, it will be shown on the accounting and searchable in the tracking
                        // Visible on the label
                        // Required field
                        $Parcel->AutorizationCode = $auth_code;
                        //#region Parcel price data
                        // Collect on delivery price
                        $Parcel->PriceAtDelivery = $_POST['PriceAtDelivery'];
                        // Collect on delivery currency
                        $Parcel->PriceAtDeliveryCurrency = "HUF"; //Have to use this currency code
                        // Parcel value, used for compensation
                        $Parcel->PackagePrice = $_POST['PackagePrice'];
                        // Parcel value currency
                        $Parcel->PackagePriceCurrency = "HUF"; //Have to use this currency code
                        //#region Customer data
                        // Customer name
                        $Parcel->CustomerName = $_POST['CustomerName'];
                        // Customer phone number for SMS notification. Have to use this format (Country prefix(+36/0036/06) and only numbers)
                        $Parcel->CustomerPhone = $_POST['CustomerPhone'];
                        // Customer email address
                        $Parcel->CustomerEmail = $_POST['CustomerEmail'];
                        #region Customer address data
                        // Customer country code. Optional default HU
                        $Parcel->CustomerCountryCode = "HU";
                        // Customer postal code
                        $Parcel->CustomerPostalCode = $_POST['CustomerPostalCode'];
                        // Customer city or settlement
                        $Parcel->CustomerCity = $_POST['CustomerCity'];
                        // Customer street
                        $Parcel->CustomerAddress = $_POST['CustomerAddress'];
                        // Customer streetnumber and other (floor and door number)
                        $Parcel->CustomerStreetNumber = $_POST['CustomerStreetNumber'];
                        // Parcel weight (in kilograms) (Optional)
                        $Parcel->PackageWeight = (int) $_POST['PackageWeight'];
                        // Package count delivered together to the same customer
                        // CAUTION! The system will generate the given number of package barcode and labels (in format: Barcode, Barcode-2, Barcode-3)
                        // The generated barcodes will be in the respone
                        $Parcel->ParcelCount = (int) $_POST['ParcelCount'];
                        // notes
                        $Parcel->Description = $_POST['CustomerNote'];
                        $Parcel->ParcelContentDescription1 = $_POST['ParcelNote'];
                        //Add to ParcelContainer list this initialized parcel
                        $ParcelContainer[] = $Parcel; // add parcels list of
                        // </editor-fold>
                    } else {
                        throw new Exception('Nem támogatott szállítási mód!');
                    }
                    //Set up the request head
                    $RegisterParcelContainerRequest = new RegisterParcelContainerRequest();
                    //Test partner code, customer service gives it to partners
                    $RegisterParcelContainerRequest->PartnerCode = $partner_code;    //Partner code
                    //$RegisterParcelContainerRequest->Token = 'tesztt0k3n'; //required token field
                    $RegisterParcelContainerRequest->Token = $partner_token; //required token field
                    $RegisterParcelContainerRequest->ParcelContainer = $ParcelContainer; //parcel list
                    //$RegisterParcelContainerRequest->ArrivedDate = date("Y.m.d H:i:s");   //Estimated time of handover, informational, optional
                    // <editor-fold defaultstate="collapsed" desc="register parcels and create documents">
                    try {
                        //#region Send the request to the webservice
                        //Connecting to the parcel registration service
                        $PartnerPudoServiceClient = new PartnerPudoService($PartnerPudoServiceWSDL, $soap_options);

                        // Sending the request to the logistic system
                        $RegisterParcelContainerResponse = $PartnerPudoServiceClient->RegisterParcelContainer($RegisterParcelContainerRequest);

                        if ($PartnerPudoServiceClient == null || $RegisterParcelContainerResponse->RegisterParcelContainerResult->ParcelResults == null) {
                            ?><div class="notice notice-error"><p><?php esc_html_e('Sprinter PUDO szolgáltatás nem válaszol!', 'wc_sprinter'); ?></p></div><?php
                        } else {
                            $_BR = "\n";
                            $ok = true;
                            $msg_log = 'Sprinter PUDO szolgáltatás log - ' . $_datum . $_BR;
                            $msg_log .= "Head result code: " . $RegisterParcelContainerResponse->RegisterParcelContainerResult->ErrorCode . $_BR;
                            $msg_log .= "Head result: " . $this->getShipmentErrorCodeMessage($RegisterParcelContainerResponse->RegisterParcelContainerResult->ErrorCode) . $_BR;

                            #region Handle parcel registration response
                            //Barcode list for successfully registrated parcels
                            $Barcodes = array();

                            $ParcelResults = $RegisterParcelContainerResponse->RegisterParcelContainerResult->ParcelResults;
                            foreach ($ParcelResults->ParcelResult as $Parcel) {

                                //Show the results
                                $msg_log .= "Parcel Original Barcode: $Parcel->OriginalBarCode" . $_BR;
                                $msg_log .= "Parcel New Barcode: $Parcel->NewBarCode" . $_BR;
                                $msg_log .= "Parcel Result Code: $Parcel->ErrorCode" . $_BR;
                                $msg_log .= "Parcel Result: " . $this->getShipmentErrorCodeMessage($Parcel->ErrorCode) . $_BR;
                                $msg_log .= "Parcel ShipmentID: $Parcel->ShipmentID" . $_BR;
                                if (!is_null($Parcel->ErrorMessageInternational) || $Parcel->ErrorMessageInternational != "") {
                                    $msg_log .= "Parcel ErrorMessageInternational: $Parcel->ErrorMessageInternational" . $_BR;
                                }

                                //If the parcel has been registrated susccessfully, adding to the list
                                if ($Parcel->ErrorCode == 'PSR_OK') {
                                    //We collect the new barcodes from the logistic system (it can be differenet from the original Barcode)
                                    $Barcodes[] = new BarcodeData($Parcel->NewBarCode);
                                }
                            }

                            #region Label and other document generation
                            //Specify the document settings
                            if (count($Barcodes) > 0) {
                                //Specify the document settings
                                $documentSetting = new DocumentSetting();
                                $documentSetting->IsPositioned = true;        //Prepared for printing on normal paper, if true then prepares for Etikett labels
                                $documentSetting->Position = LabelDocumentPosition::$P_0;  //Starting position of labels on page
                                $documentSetting->Size = LabelDocumentSize::$DS_2x2;  //A4 page dividing for labels
                                $documentSetting->Type = DocumentType::$DT_All;    //Getting all document types: Labels, recipient report and delivery notes
                                //add documentSetting on $DocumentSettings[] array
                                $DocumentSettings[] = $documentSetting;

                                // Setting the request
                                $MassDocumentRequest = new MassDocumentRequest();
                                $MassDocumentRequest->Barcodes = $Barcodes;      //list of barcodes
                                $MassDocumentRequest->DocumentSettings = $DocumentSettings;  //list of documentSettings
                                //Create de DocumentServiceClient and Connecting to the document generation service
                                $DocumentClient = new DocumentService($PudoDocumentServiceWSDL, $soap_options);
                                //Getting back the documents
                                $MassDocumentResponse = $DocumentClient->GetDocument($MassDocumentRequest);

                                $msg_log .= "MassDocument Result Code: " . $MassDocumentResponse->GetDocumentResult->Result . $_BR;
                                $msg_log .= "MassDocument Result: ";
                                #region Document response handling
                                switch ($MassDocumentResponse->GetDocumentResult->Result) {
                                    //If the Result is RES_OK, then the document generation was successfully and we have got back printable documents
                                    case "RES_OK": {
                                            $msg_log .= "OK, generating..." . $_BR;
                                            //Write out the results
                                            $DocumentResults = $MassDocumentResponse->GetDocumentResult->DocumentGenerationResults->DocumentGenerationResult;
                                            $_index = 0;
                                            foreach ($DocumentResults as $DocumentGenerationResult) {
                                                $_index++;
                                                $msg_log .= "#" . $_index . " Document Name: " . $DocumentGenerationResult->DocumentName . $_BR;
                                                $msg_log .= "#" . $_index . " Result Code: " . $DocumentGenerationResult->Result . $_BR;
                                                if (!is_null($DocumentGenerationResult->ResultMessage) || $DocumentGenerationResult->ResultMessage != "") {
                                                    $msg_log .= "#" . $_index . " Result Message: " . $DocumentGenerationResult->ResultMessage . $_BR;
                                                }
                                            }


                                            //There could be more documents with the same name, save them with different filenames to avoid override
                                            $_index = 0;
                                            //Save the results to files
                                            foreach ($MassDocumentResponse->GetDocumentResult->Documents->DocumentData as $docResponse) {
                                                $_index++;
                                                $doc_name = $order->get_id() . '_' . $docResponse->DocumentName . '_' . $_datum . '_' . $_index . ".pdf";
                                                if (strstr($docResponse->DocumentName, 'PackageLabel')) {
                                                    $img = new Imagick();
                                                    $img->setresolution(300, 300);
                                                    $img->setcompressionquality(100);
                                                    $img->readimageblob($docResponse->Document);
                                                    $img->mergeimagelayers(Imagick::LAYERMETHOD_FLATTEN);
                                                    $img->setformat('png');
                                                    $combined = new Imagick();
                                                    for ($i = 0; $i < count($Barcodes); $i++) {
                                                        $image = new Imagick();
                                                        $image->setresolution(300, 300);
                                                        $image->readimageblob($img->getimageblob());
                                                        $image->cropimage(1677, 1146, 53 + (($i >> 1 & 1) * 1718), 76 + (($i % 2) * 1182));
                                                        $image->setimagepage(1677, 1146, 0, 0);
                                                        $image->mergeimagelayers(Imagick::LAYERMETHOD_FLATTEN);
                                                        $combined->addImage($image);
                                                        $image->clear();
                                                        $image->destroy();
                                                        if ($i % 4 == 3 && $img->hasnextimage()) {
                                                            $img->nextimage();
                                                        }
                                                    }
                                                    $combined->setformat('pdf');
                                                    $combined->writeimages($this->plugin_upload_path() . '/' . $doc_name, true);
                                                } else {
                                                    $PrintDoc = fopen($this->plugin_upload_path() . '/' . $doc_name, "w");
                                                    fwrite($PrintDoc, $docResponse->Document);
                                                    fclose($PrintDoc);
                                                }
                                                $msg_log .= "#" . $_index . " File created: " . $doc_name . $_BR;
                                            }
                                            break;
                                        }
                                    case "RES_DATA_MISSING": {
                                            $ok = false;
                                            $msg_log .= "Data is missing" . $_BR;
                                            break;
                                        }
                                    case "RES_GENERATE_ERROR": {
                                            $ok = false;
                                            $msg_log .= "Error occured during generation" . $_BR;
                                            break;
                                        }
                                    default : {
                                            $ok = false;
                                            $msg_log .= "Undefined error" . $_BR;
                                            break;
                                        }
                                }
                            } else {
                                $ok = false;
                            }
                            if ($ok) {
                                $order->add_order_note(__('Sikeres csomag regisztráció.', 'wc_sprinter'), 0, true);
                                // <editor-fold defaultstate="collapsed" desc="package sent">
//                                $order->update_status('order-sent');
//                                if ($cdorderids) {
//                                    foreach ($cdorderids as $cdorderid) {
//                                        $cdorder = wc_get_order($cdorderid);
//                                        $cdorder->update_status('order-sent');
//                                    }
//                                }
                                // </editor-fold>
                            } else {
                                $order->add_order_note(__('Sikertelen csomag regisztráció!', 'wc_sprinter'), 0, true);
                            }
                            $order_sprinter_data['ok'] = $ok;
                            $order_sprinter_data[$_datum . '-ParcelRegistration-' . ($ok ? 'OK' : 'FAIL')] = $msg_log;
                            update_post_meta($order->get_id(), 'wc_sprinter_data', $order_sprinter_data);
                            if ($ok) {
                                echo "<script type='text/javascript'> window.location=document.location.href; </script>";
                            }
                        }
                    } catch (Exception $ex) {
                        trigger_error($ex->getMessage() . ' Line: ' . $ex->getLine(), E_USER_ERROR);
                        ?><div class="notice notice-error"><p><?php echo($ex->getMessage() . ' Line: ' . $ex->getLine()); ?></p></div><?php
                            }
                            // </editor-fold>
                        } catch (Exception $e) {
                            ?><i class="fa fa-"></i><div class="notice notice-error"><p><?php echo($e->getMessage()); ?></p></div><?php
                            }
                        } else {
                            ?><div class="notice notice-warning"><p><?php esc_html_e('Minden adat kitöltése kötelező.', 'wc_sprinter'); ?></p></div><?php
                        }
                    }
                    // </editor-fold>
                    $order_sprinter_data = get_post_meta($order->get_id(), 'wc_sprinter_data', true);
                    $this->render_page_sprinter_data_files($order);
                    $this->render_page_sprinter_data_logs($order_sprinter_data);
                    $order_statuses = wc_get_order_statuses();
                    echo '<hr>';
                    if (!($order_sprinter_data && isset($order_sprinter_data['ok']) && $order_sprinter_data['ok'])) {
                        // <editor-fold defaultstate="collapsed" desc="forms">
                        if ($ook) {
                            if ($order->get_status() == 'processing') {
                                echo '<h2>' . esc_html__('Csomag összekészítés', 'wc_sprinter') . '</h2>';
                                ?><form method="POST">
                        <input type="hidden" name="package_pack" value="1" />
                        <input class="button button-primary" type="submit" value="<?php esc_html_e('ELKÜLD', 'wc_sprinter') ?>" autofocus/>
                    </form><?php
                } else if ($order->get_status() == 'order-packed') {
                    echo '<h2>' . esc_html__('Csomag regisztrálás', 'wc_sprinter') . '</h2>';
                    ?><form method="POST">
                        <input type="hidden" name="parcel_type" value="<?php echo $order_shipping_method_type; ?>" />
                        <div style="width: 50%; float: left;">
                            <table class="form-table">
                                <tbody>
                                    <tr valign="top"><th colspan="2" style="padding: 0; text-decoration: underline;"><?php esc_attr_e('Ügyfél adatok', 'wc_sprinter'); ?></th></tr>
                                    <tr valign="top">
                                        <th scope="row" class="titledesc">
                                            <label for="CustomerName"><?php esc_attr_e('Ügyfél neve', 'wc_sprinter'); ?></label>
                                        </th>
                                        <td class="forminp forminp-text">
                                            <input name="CustomerName" id="CustomerName" type="text" value="<?php echo(isset($_POST['CustomerName']) ? $_POST['CustomerName'] : $CustomerName); ?>" />
                                        </td>
                                    </tr>
                                    <tr valign="top">
                                        <th scope="row" class="titledesc">
                                            <label for="CustomerPhone"><?php esc_attr_e('Ügyfél telefonszáma', 'wc_sprinter'); ?></label>
                                        </th>
                                        <td class="forminp forminp-text">
                                            <input name="CustomerPhone" id="CustomerPhone" type="text" value="<?php echo(isset($_POST['CustomerPhone']) ? $_POST['CustomerPhone'] : $CustomerPhone); ?>" style="width: 150px;" />
                                        </td>
                                    </tr>
                                    <tr valign="top">
                                        <th scope="row" class="titledesc">
                                            <label for="CustomerEmail"><?php esc_attr_e('Ügyfél email címe', 'wc_sprinter'); ?></label>
                                        </th>
                                        <td class="forminp forminp-text">
                                            <input name="CustomerEmail" id="CustomerEmail" type="text" value="<?php echo(isset($_POST['CustomerEmail']) ? $_POST['CustomerEmail'] : $CustomerEmail); ?>" style="width: 300px;" />
                                        </td>
                                    </tr>
                                    <tr valign="top">
                                        <th scope="row" class="titledesc">
                                            <label for="CustomerPostalCode"><?php esc_attr_e('Címzett címe (irányítószám)', 'wc_sprinter'); ?></label>
                                        </th>
                                        <td class="forminp forminp-text">
                                            <input name="CustomerPostalCode" id="CustomerPostalCode" type="text" value="<?php echo(isset($_POST['CustomerPostalCode']) ? $_POST['CustomerPostalCode'] : $CustomerPostalCode); ?>" style="width: 80px;" />
                                        </td>
                                    </tr>
                                    <tr valign="top">
                                        <th scope="row" class="titledesc">
                                            <label for="CustomerCity"><?php esc_attr_e('Címzett címe (város)', 'wc_sprinter'); ?></label>
                                        </th>
                                        <td class="forminp forminp-text">
                                            <input name="CustomerCity" id="CustomerCity" type="text" value="<?php echo(isset($_POST['CustomerCity']) ? $_POST['CustomerCity'] : $CustomerCity); ?>" />
                                        </td>
                                    </tr>
                                    <tr valign="top">
                                        <th scope="row" class="titledesc">
                                            <label for="CustomerAddress"><?php esc_attr_e('Címzett címe (utca)', 'wc_sprinter'); ?></label>
                                        </th>
                                        <td class="forminp forminp-text">
                                            <input name="CustomerAddress" id="CustomerAddress" type="text" value="<?php echo(isset($_POST['CustomerAddress']) ? $_POST['CustomerAddress'] : $CustomerAddress); ?>" />
                                        </td>
                                    </tr>
                                    <tr valign="top">
                                        <th scope="row" class="titledesc">
                                            <label for="CustomerStreetNumber"><?php esc_attr_e('Címzett címe (házszám)', 'wc_sprinter'); ?></label>
                                        </th>
                                        <td class="forminp forminp-text">
                                            <input name="CustomerStreetNumber" id="CustomerStreetNumber" type="text" value="<?php echo(isset($_POST['CustomerStreetNumber']) ? $_POST['CustomerStreetNumber'] : $CustomerStreetNumber); ?>" style="width: 150px;" />
                                        </td>
                                    </tr>
                                    <tr valign="top">
                                        <th scope="row" class="titledesc">
                                            <label for="CustomerNote"><?php esc_attr_e('Megjegyzés', 'wc_sprinter'); ?></label>
                                            <span class="woocommerce-help-tip" title="<?php esc_attr_e('Maximum 100 karakter.', 'wc_sprinter'); ?>"></span>
                                        </th>
                                        <td class="forminp forminp-text">
                                            <input name="CustomerNote" id="CustomerNote" type="text" maxlength="100" value="<?php echo(isset($_POST['CustomerNote']) ? $_POST['CustomerNote'] : $CustomerNote); ?>" />
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div style="width: 50%; float: left;">
                            <table class="form-table">
                                <tbody>
                                    <tr valign="top"><th colspan="2" style="padding: 0; text-decoration: underline;"><?php esc_attr_e('Csomag adatok', 'wc_sprinter'); ?></th></tr>
                                    <tr valign="top">
                                        <th scope="row" class="titledesc">
                                            <label for="PriceAtDelivery"><?php esc_attr_e('Fizetendő díj', 'wc_sprinter'); ?></label>
                                            <span class="woocommerce-help-tip" title="<?php esc_attr_e('Átvételkor fizetendő díj, amikor a vásárló átveszi. Nem utánvétes fizetésnél ez az összeg 0 Ft.', 'wc_sprinter'); ?>"></span>
                                        </th>
                                        <td class="forminp forminp-text">
                                            <input name="PriceAtDelivery" id="PriceAtDelivery" type="number" value="<?php echo(isset($_POST['PriceAtDelivery']) ? $_POST['PriceAtDelivery'] : $PriceAtDelivery); ?>" style="width: 150px; text-align: center;" />
                                        </td>
                                    </tr>
                                    <tr valign="top">
                                        <th scope="row" class="titledesc">
                                            <label for="PackagePrice"><?php esc_attr_e('Csomag értéke', 'wc_sprinter'); ?></label>
                                            <span class="woocommerce-help-tip" title="<?php esc_attr_e('Kártérítés esetében a terhelés alapja. A szállítási díj nincs benne.', 'wc_sprinter'); ?>"></span>
                                        </th>
                                        <td class="forminp forminp-text">
                                            <input name="PackagePrice" id="PackagePrice" type="number" value="<?php echo(isset($_POST['PackagePrice']) ? $_POST['PackagePrice'] : $PackagePrice); ?>" style="width: 150px; text-align: center;" />
                                        </td>
                                    </tr>
                                    <tr valign="top">
                                        <th scope="row" class="titledesc">
                                            <label for="PackageWeight"><?php esc_attr_e('Csomag súlya', 'wc_sprinter'); ?></label>
                                            <span class="woocommerce-help-tip" title="<?php esc_attr_e('kg-ban, maximum 20kg', 'wc_sprinter'); ?>"></span>
                                        </th>
                                        <td class="forminp forminp-text">
                                            <input name="PackageWeight" id="PackageWeight" min="1" max="20" type="number" value="<?php echo(isset($_POST['PackageWeight']) ? $_POST['PackageWeight'] : $op_parcelsize_weight); ?>" style="width: 80px; text-align: center;" />
                                        </td>
                                    </tr>
                    <?php if ($order_shipping_method_type == 'pickpackpoint') { ?>
                                        <tr valign="top">
                                            <th scope="row" class="titledesc">
                                                <label for="PackageSizePPP"><?php esc_attr_e('Csomag mérete', 'wc_sprinter'); ?></label>
                                                <span class="woocommerce-help-tip" title="<?php esc_attr_e('PPP-s legnagyobb csomag mérete', 'wc_sprinter'); ?>"></span>
                                            </th>
                                            <td class="forminp forminp-text">
                                                <select name="PackageSizePPP" id="PackageSizePPP">
                                                    <option<?php echo((isset($_POST['PackageSizePPP']) && $_POST['PackageSizePPP'] == 'Small') || $op_parcelsize_ppp == 'Small' ? ' selected="selected"' : ''); ?> value="Small"><?php _e('Kicsi - X: 20cm, Y: 30cm, Z: 10cm, Volume: 0.006000m3', 'wc_sprinter'); ?></option>
                                                    <option<?php echo((isset($_POST['PackageSizePPP']) && $_POST['PackageSizePPP'] == 'Medium') || $op_parcelsize_ppp == 'Medium' ? ' selected="selected"' : ''); ?> value="Medium"><?php _e('Közepes - X: 30cm, Y: 30cm, Z: 20cm, Volume: 0.018000m3', 'wc_sprinter'); ?></option>
                                                    <option<?php echo((isset($_POST['PackageSizePPP']) && $_POST['PackageSizePPP'] == 'Large') || $op_parcelsize_ppp == 'Large' ? ' selected="selected"' : ''); ?> value="Large"><?php _e('Nagy - X: 50cm, Y: 50cm, Z: 50cm, Volume: 0.125000m3', 'wc_sprinter'); ?></option>
                                                    <option<?php echo((isset($_POST['PackageSizePPP']) && $_POST['PackageSizePPP'] == 'Special') || $op_parcelsize_ppp == 'Special' ? ' selected="selected"' : ''); ?> value="Special"><?php _e('Speciális - X: 60cm, Y: 60cm, Z: 60cm, Volume: 0.216000m3', 'wc_sprinter'); ?></option>
                                                    <option<?php echo((isset($_POST['PackageSizePPP']) && $_POST['PackageSizePPP'] == 'None') || $op_parcelsize_ppp == 'None' ? ' selected="selected"' : ''); ?> value="None"><?php _e('Nincs megadva méret', 'wc_sprinter'); ?></option>
                                                </select>
                                            </td>
                                        </tr>
                    <?php } else if ($order_shipping_method_type == 'homedelivery') { ?>
                                        <tr valign="top">
                                            <th scope="row" class="titledesc">
                                                <label for="PackageSizeX"><?php esc_attr_e('Csomag mérete (X)', 'wc_sprinter'); ?></label>
                                                <span class="woocommerce-help-tip" title="<?php esc_attr_e('cm-ben, legnagyobb csomag X dimenziója', 'wc_sprinter'); ?>"></span>
                                            </th>
                                            <td class="forminp forminp-text">
                                                <input name="PackageSizeX" id="PackageSizeX" min="10" type="number" value="<?php echo(isset($_POST['PackageSizeX']) ? $_POST['PackageSizeX'] : $op_parcelsize_x); ?>" style="width: 100px; text-align: center;" />
                                            </td>
                                        </tr>
                                        <tr valign="top">
                                            <th scope="row" class="titledesc">
                                                <label for="PackageSizeY"><?php esc_attr_e('Csomag mérete (Y)', 'wc_sprinter'); ?></label>
                                                <span class="woocommerce-help-tip" title="<?php esc_attr_e('cm-ben, legnagyobb csomag Y dimenziója', 'wc_sprinter'); ?>"></span>
                                            </th>
                                            <td class="forminp forminp-text">
                                                <input name="PackageSizeY" id="PackageSizeY" min="10" type="number" value="<?php echo(isset($_POST['PackageSizeY']) ? $_POST['PackageSizeY'] : $op_parcelsize_y); ?>" style="width: 100px; text-align: center;" />
                                            </td>
                                        </tr>
                                        <tr valign="top">
                                            <th scope="row" class="titledesc">
                                                <label for="PackageSizeZ"><?php esc_attr_e('Csomag mérete (Z)', 'wc_sprinter'); ?></label>
                                                <span class="woocommerce-help-tip" title="<?php esc_attr_e('cm-ben, legnagyobb csomag Z dimenziója', 'wc_sprinter'); ?>"></span>
                                            </th>
                                            <td class="forminp forminp-text">
                                                <input name="PackageSizeZ" id="PackageSizeZ" min="10" type="number" value="<?php echo(isset($_POST['PackageSizeZ']) ? $_POST['PackageSizeZ'] : $op_parcelsize_z); ?>" style="width: 100px; text-align: center;" />
                                            </td>
                                        </tr>
                    <?php } ?>
                                    <tr valign="top">
                                        <th scope="row" class="titledesc">
                                            <label for="ParcelCount"><?php esc_attr_e('Csomagok darabszáma', 'wc_sprinter'); ?></label>
                                            <span class="woocommerce-help-tip" title="<?php esc_attr_e('Az együtt kézbesítendő csomagok darabszáma. Ebben a mezőben kell megadni, az egy címen belüli csomagok darabszámát.', 'wc_sprinter'); ?>"></span>
                                        </th>
                                        <td class="forminp forminp-text">
                                            <input name="ParcelCount" id="ParcelCount" min="1" max="100" type="number" value="<?php echo(isset($_POST['ParcelCount']) ? $_POST['ParcelCount'] : $parcel_count); ?>" style="width: 80px; text-align: center;" />
                                        </td>
                                    </tr>
                    <?php if ($order_shipping_method_type == 'homedelivery') { ?>
                                        <tr valign="top">
                                            <th scope="row" class="titledesc">
                                                <label for="TransitTime"><?php esc_attr_e('Szállítási idő', 'wc_sprinter'); ?></label>
                                            </th>
                                            <td class="forminp forminp-text">
                                                <select name="TransitTime" id="TransitTime" style="width: 200px;">
                                                    <option value="0"<?php echo((isset($_POST['TransitTime']) && $_POST['TransitTime'] == 0) || $op_transittime == 0 ? 'selected="selected"' : ''); ?>><?php esc_attr_e('délelött 9 óra előtti', 'wc_sprinter'); ?></option>
                                                    <option value="1"<?php echo((isset($_POST['TransitTime']) && $_POST['TransitTime'] == 1) || $op_transittime == 1 ? 'selected="selected"' : ''); ?>><?php esc_attr_e('délelőtt 9-12 óra között', 'wc_sprinter'); ?></option>
                                                    <option value="2"<?php echo((isset($_POST['TransitTime']) && $_POST['TransitTime'] == 2) || $op_transittime == 2 ? 'selected="selected"' : ''); ?>><?php esc_attr_e('1 munkanapos', 'wc_sprinter'); ?></option>
                                                    <option value="3"<?php echo((isset($_POST['TransitTime']) && $_POST['TransitTime'] == 3) || $op_transittime == 3 ? 'selected="selected"' : ''); ?>><?php esc_attr_e('2 munkanapos', 'wc_sprinter'); ?></option>
                                                    <option value="4"<?php echo((isset($_POST['TransitTime']) && $_POST['TransitTime'] == 4) || $op_transittime == 4 ? 'selected="selected"' : ''); ?>><?php esc_attr_e('3 munkanapos', 'wc_sprinter'); ?></option>
                                                    <option value="5"<?php echo((isset($_POST['TransitTime']) && $_POST['TransitTime'] == 5) || $op_transittime == 5 ? 'selected="selected"' : ''); ?>><?php esc_attr_e('5 munkanapos', 'wc_sprinter'); ?></option>
                                                </select>
                                            </td>
                                        </tr>
                    <?php } ?>
                                    <tr valign="top">
                                        <th scope="row" class="titledesc">
                                            <label for="ParcelNote"><?php esc_attr_e('Csomag megjegyzés', 'wc_sprinter'); ?></label>
                                            <span class="woocommerce-help-tip" title="<?php esc_attr_e('Pl. törékeny, stb. Maximum 64 karakter.', 'wc_sprinter'); ?>"></span>
                                        </th>
                                        <td class="forminp forminp-text">
                                            <input name="ParcelNote" id="ParcelNote" type="text" maxlength="64" value="<?php echo(isset($_POST['ParcelNote']) ? $_POST['ParcelNote'] : ''); ?>" />
                                        </td>
                                    </tr>

                                            <?php if ($order_shipping_method_type == 'pickpackpoint') { ?>
                                        <tr valign="top">
                                            <td class="forminp forminp-text" colspan="2">
                                        <?php $this->wc_sprinter_meta($order_ppp_meta, 'strong', 'p'); ?>
                                            </td>
                                        </tr>
                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="clear"></div>
                        <input class="button button-primary" type="submit" value="<?php esc_html_e('ELKÜLD', 'wc_sprinter') ?>" autofocus/>
                    </form><?php } else {
                    ?>
                    <div class="notice notice-warning"><p><?php printf(esc_html__('Csomag összekészítéshez a rendelés állapotának %s-nek kell lennie! %s Csomag regisztráláshoz a rendelés állapotának %s-nek kell lennie! %s Gyüjtő szállítás esetén, minden egyes csatlakozott rendelésnek is, valamint %s-nak kell lennie.', 'wc_sprinter'), '<b>"' . $order_statuses['wc-processing'] . '"</b>', '<br>', '<b>"' . $order_statuses['wc-order-packed'] . '"</b>', '<br>', '<b>"' . __('lezárt', 'wc_collective_delivery') . '"</b>'); ?></p></div><?php
                        }
                    }
                    // </editor-fold>
                }
            }

            /**
             *
             * @param WC_Order $order
             * @param boolean $box
             */
            private function render_page_sprinter_data_files($order, $box = false) {
                $files = glob($this->plugin_upload_path() . '/' . $order->get_id() . '_*.pdf');
                if ($files) {
                    echo '<hr>';
                    echo '<h2' . ($box ? ' style="padding:0;"' : '') . '>' . esc_html__('Generált fájlok', 'wc_sprinter') . '</h2>';
                    echo '<ul' . ($box ? ' style="margin-top:5px;width:254px;max-width:254px;overflow-x:scroll;"' : '') . '>';
                    $lastPL = '';
                    foreach ($files as $i => $file) {
                        $file_name = basename($file);
                        if (strstr($file_name, '_PackageLabel_') !== false) {
                            $lastPL = $i;
                        }
                    }
                    ?><a class="button-small"></a><?php
                    foreach ($files as $i => $file) {
                        $file_name = basename($file);
                        echo '<li>';
                        if (!$box) {
                            echo '<button id="' . ($lastPL === $i ? 's-print-lpl' : '') . '" class="button button-small' . ($lastPL === $i ? ' button-primary' : '') . ' s-print" data="' . $this->plugin_upload_url() . '/' . $file_name . '">nyomtatás</button>&nbsp;&nbsp;';
                        }
                        echo '<a target="_blank" href="' . $this->plugin_upload_url() . '/' . $file_name . '">' . $file_name . '</a>';
                        echo '</li>';
                    }
                    echo '</ul>';
                    if (!$box) {
                        echo '<script type="text/javascript" src="' . self::$plugin_url . 'assets/wc_sprinter_print.js' . '"></script>';
                    }
                }
            }

            /**
             *
             * @param array $order_sprinter_data
             * @param boolean $box
             */
            private function render_page_sprinter_data_logs($order_sprinter_data, $box = false) {
                if ($order_sprinter_data) {
                    echo '<hr>';
                    echo '<h2>' . esc_html__('Napló bejegyzések', 'wc_sprinter') . '</h2>';
                    echo '<div>';
                    foreach ($order_sprinter_data as $key => $log) {
                        if ($key != 'ok') {
                            $idx = explode('-', $key);
                            /* @var $dt DateTime */
                            $dt = DateTime::createFromFormat('YmdHis', $idx[0]);
                            unset($idx[0]);
                            echo '<div style="border: 1px solid #dddddd; margin: 5px; padding: 5px;">';
                            echo '<h4 class="sprinter_log" style="margin: 0; cursor: pointer;">';
                            echo '<i class="fa fa-caret-right"></i>&nbsp;';
                            echo $dt->format('Y-m-d H:i:s') . ' #' . implode(' #', $idx) . '</h4>';
                            echo '<p style="display: none;' . ($box ? ' width:230px;max-width:230px;overflow-x:scroll;white-space:nowrap;' : '') . '">' . nl2br($log) . '</p>';
                            echo '</div>';
                        }
                    }
                    ?><script type="text/javascript">
                        (function ($) {
                            $("h4.sprinter_log").unbind("click").click(function () {
                                var childi = $(this).children('i');
                                var nextp = $(this).parent().find('p');
                                if (childi.hasClass('fa-caret-right')) {
                                    childi.addClass('fa-caret-down');
                                    childi.removeClass('fa-caret-right');
                                    nextp.show('slow');
                                } else {
                                    childi.addClass('fa-caret-right');
                                    childi.removeClass('fa-caret-down');
                                    nextp.hide('fast');
                                }
                            });
                        })(jQuery);
            </script><?php
            echo '</div>';
        }
    }

    // </editor-fold>
    // <editor-fold defaultstate="collapsed" desc="protected functions">

    protected function getTrackingErrorCodeMessage($errorcode) {
        if ($errorcode == 'NOT_SPECIFIED') {
            return 'nincs megadva';
        } else if ($errorcode == 'LEAVE_NOTIFICATION') {
            return 'Értesítőt hagyok';
        } else if ($errorcode == 'CLOSED_LEAVE_NOTIFICATION') {
            return 'Zárva, értesítőt hagyok';
        } else if ($errorcode == 'ADDRESSEE_MOVED') {
            return 'Címzett elköltözött';
        } else if ($errorcode == 'ADDRESSEE_DIED') {
            return 'Címzett meghalt';
        } else if ($errorcode == 'ADDRESSE_AT_ADDRESS_IS_UNKNOWN') {
            return 'Címzett címhelyen ismeretlen';
        } else if ($errorcode == 'NOT_WANTED') {
            return 'Nem kéri';
        } else if ($errorcode == 'WANTS_IT_IN_A_DIFFERENT_TIME') {
            return 'Új időpontban kéri';
        } else if ($errorcode == 'BAD_ADDRESS') {
            return 'Rossz cím';
        } else if ($errorcode == 'ADDRESSEE_AT_ADDRESS_IS_UNKNOWN_ADDRESS_IS_WRONG') {
            return 'címzett címhelyen ismeretlen, cím elégtelen';
        } else if ($errorcode == 'MOVED') {
            return 'elköltözött';
        } else if ($errorcode == 'NOT_RESPONDED_TO_THE_NOTIFICATION') {
            return 'értesítésre nem reagált';
        } else if ($errorcode == 'NOT_ACCEPTED_THE_PACKAGE') {
            return 'nem fogadta a küldeményt';
        } else if ($errorcode == 'OTHER') {
            return 'egyéb (meghalt, megszűnt, feladó)';
        } else if ($errorcode == 'WRONG_PIN_NUMBER') {
            return 'Hibás PIN kód!';
        } else if ($errorcode == 'CANCELED_BY_PHONE') {
            return 'Telefonon lemondta';
        } else if ($errorcode == 'FAILED_ATTEMPT_TO_CONTACT') {
            return 'Sikertelen kapcsolatfelvétel';
        } else if ($errorcode == 'COURIER_IS_NOT_GET_THERE_IN_TIME') {
            return 'Futár nem ért ki';
        } else if ($errorcode == 'TECHNICAL_FAILURE') {
            return 'Műszaki meghibásodás';
        } else if ($errorcode == 'WEATHER_PROBLEM') {
            return 'Időjárási probléma';
        } else if ($errorcode == 'CONTRACT_LEFT_THERE') {
            return 'Szerződés otthagyva';
        } else if ($errorcode == 'TAKEN_TO_HOSPITAL') {
            return 'Kórházba került';
        } else if ($errorcode == 'INSUFFICIENT_FUNDS') {
            return 'Fedezethiány, nem elfogadott UV összeg';
        } else if ($errorcode == 'NO_PARTIAL_DELIVERY') {
            return 'Részlegesen nem kézbesíthető, csomag nem bontható';
        } else if ($errorcode == 'PACKAGE_DAMAGED') {
            return 'Sérült csomag';
        } else if ($errorcode == 'UNIDENTIFIABLE') {
            return 'Okmányhiány';
        } else if ($errorcode == 'OTHER_CANNOT_CONTACT') {
            return 'Egyéb (sikertelen kapcsfelv, nem megköz, nem bizt)';
        } else if ($errorcode == 'PACKAGE_REDIRECTED') {
            return 'Átirányítás, más címre kéri';
        }
        return 'Ismeretlen hibakód';
    }

    protected function getShipmentErrorCodeMessage($errorcode) {
        if ($errorcode == 'PSR_OK') {
            return 'Beszállítói csomag, vagy száregisztrációja sikeres volt';
        } else if ($errorcode == 'PSR_FAILED') {
            return 'Beszállítói csomag, vagy szállítmány regisztráció nem sikerült ismeretlen hiba miatt';
        }
        //
        if ($errorcode == 'PSR_PARTNERCODE_MISSING') {
            return 'Beszállítói azonosító nincs megadva';
        } else if ($errorcode == 'PSR_INVALID_PARTNER') {
            return 'Beszállítói azonosító nem található, vagy hibásan van beállítva';
        } else if ($errorcode == 'PSR_PARTNER_MISSING_COURIER_PREMISE') {
            return 'A megadott partnerhez nincsen futáros telephely beállítva, keresse az ügyfélszolgálatot';
        } else if ($errorcode == 'PSR_PARTNER_NOT_FOUND') {
            return 'Nem található a megadott partner kód';
        } else if ($errorcode == 'PSR_EMPTY_SHIPMENT') {
            return 'Üres csomaglista';
        } else if ($errorcode == 'PSR_SHIPMENT_NOTENUMBER_ALREADY_USED') {
            return 'Szállítmányazonosító ütközés';
        } else if ($errorcode == 'PSR_SHIPMENT_NOTENUMBER_MISSING') {
            return 'Szállítmányazonosító nincs megadva';
        } else if ($errorcode == 'PSR_SHIPMENT_NOTENUMBER_NOT_FOUND') {
            return 'Szállítmányazonosító nem létezik';
        }
        //
        if ($errorcode == 'PSR_INVALID_PACKAGE') {
            return 'A módosítandó csomag nincs meg';
        } else if ($errorcode == 'PSR_INVALID_SHOPID') {
            return 'Az árushely kód hibás';
        } else if ($errorcode == 'PSR_INVALID_PARTNER_SHOP_COUNTRY') {
            return 'A megadott partner nem adhat fel csomagot a kiválasztott boltba, mert nem szerepel a célországai között';
        } else if ($errorcode == 'PSR_PACKAGE_BARCODE_MISSING') {
            return 'Csomag vonalkód nincs megadva';
        } else if ($errorcode == 'PSR_PACKAGE_BARCODE_INVALID') {
            return 'Csomag vonalkód érvénytelen';
        } else if ($errorcode == 'PSR_SHIPMENTITEM_CANNOTMODIFY_ALREADY_PICKED') {
            return 'A szállítmány nem módosítható, már beérkezett';
        } else if ($errorcode == 'PSR_PACKAGE_INVALID_CURRENCY') {
            return 'Csomag pénzneme nem megfelelő';
        } else if ($errorcode == 'PSR_INVALID_TRANSIT_TIME') {
            return 'Szállítási idő érvénytelen';
        } else if ($errorcode == 'PSR_INVALID_PAYMENT_METHOD') {
            return 'Fizetési mód érvénytelen';
        } else if ($errorcode == 'PSR_INVALID_SUPPLIMENT_DATA') {
            return 'Érvénytelenül kitöltött suppliment adat';
        } else if ($errorcode == 'PSR_INVALID_SUPPLIMENT_DATA_DELIVERY_PRICE') {
            return 'Érvénytelenül kitöltött suppliment adat, delivery price';
        } else if ($errorcode == 'PSR_SHIPMENT_CUSTOMERNAME_MISSING') {
            return 'Vevő neve nincs megadva';
        } else if ($errorcode == 'PSR_SHIPMENT_CUSTOMERPHONE_MISSING') {
            return 'Vevő telefonszáma nincs megadva';
        } else if ($errorcode == 'PSR_SHIPMENT_CUSTOMERPHONE_INVALID') {
            return 'Vevő telefonszáma helytelen, nem helyes az előhívószám vagy a formátum';
        } else if ($errorcode == 'PSR_SHIPMENT_CUSTOMERADDRESS_MISSING') {
            return 'Vevő címe nincs megadva';
        } else if ($errorcode == 'PSR_INVALID_POSTALCODE') {
            return 'Megadott irányítószámhoz nem tartozik irány';
        } else if ($errorcode == 'PSR_FAILED_POSTALCODE_MISMATCH') {
            return 'Hiba, amennyiben az irányítószám vagy város nem létezik, vagy nem egymáshoz tartoznak';
        } else if ($errorcode == 'PSR_FAILED_THIRD_PERSON_DENIED') {
            return 'Hiba, partner számára nem engedélyezett a háromszereplős csomagregisztráció';
        } else if ($errorcode == 'PSR_FAILED_THIRD_PERSON_MISSING_DATA') {
            return 'Hiba, háromszereplős feladásnál, minden adat megadása kötelező';
        } else if ($errorcode == 'PSR_FAILED_THIRD_PERSON_INVALID_POSTALCODE') {
            return 'Hiba, háromszereplős feladásnál, a felvétel címében nem megfelelő irányítószám';
        } else if ($errorcode == 'PSR_FAILED_THIRD_PERSON_POSTALCODE_MISMATCH') {
            return 'Hiba, háromszereplős feladásnál, a felvétel címében nem megfelelő irányítószám és helység páros';
        } else if ($errorcode == 'PSR_INVALID_DELIVERY_PARTNER') {
            return 'Nincs megadva vagy nem értelmezhető szállító partner';
        } else if ($errorcode == 'PSR_EXTERNAL_SYSTEM_NOT_AVAILABLE') {
            return 'Csomag regisztrációhoz szükséges külső rendszer nem elérhető, később próbálja újra';
        } else if ($errorcode == 'PSR_EXTERNAL_SYSTEM_UNKNOW_ERROR') {
            return 'Külső rendszer hívása során ismeretlen hiba történt, tovább részletek az InternationalErrorMessage mezőben';
        } else if ($errorcode == 'PSR_EXTERNAL_SYSTEM_NOT_EXCEPTED_RESULT') {
            return 'Külső rendszer hívás során nem várt eredményt kaptunk, vegye fel a kapcsolatot az ügyfélszolgálatunkkal';
        } else if ($errorcode == 'PSR_SHIPMENT_CUSTOMERCOUNTRY_MISSING') {
            return 'Vevő ország nincs megadva';
        } else if ($errorcode == 'PSR_SHIPMENT_CUSTOMERPOSTALCODE_OR_CUSTOMERREGION_REQUIRED') {
            return 'Vevő irányítószám vagy megye kötelező';
        } else if ($errorcode == 'PSR_INVALID_SERVICETYPE_DIRECT_NOT_POS2POS') {
            return 'Pos2Pos ServiceType-al adott fel olyan csomagot, melynek a cél és a feladási helye azonos. Az ilyen csomagot Direct-el kell feladni';
        } else if ($errorcode == 'PSR_INVALID_PARTNER_TOKEN') {
            return 'Nem megfelelő a TOKEN, nincs kitöltve, vagy hibásan lett megadva';
        }
        return 'Ismeretlen hibakód';
    }

    // </editor-fold>

    /**
     *
     * @staticvar \WC_Sprinter $instance
     * @return \WC_Sprinter
     */
    public static function instance() {
        static $instance = null;
        if (!$instance) {
            $instance = new WC_Sprinter();
        }
        return $instance;
    }

}

WC_Sprinter::instance();
