<?php
class Newstock_Table extends WP_List_Table {

    public static function get_newstocks( $per_page = 50, $page_number = 1 ) {
        global $wpdb;
	$sql="SELECT * from
        {$wpdb->prefix}posts
        WHERE {$wpdb->prefix}posts.post_type=\"newstock\"
        ORDER BY ID DESC";
        $result = $wpdb->get_results( $sql, 'ARRAY_A' );
	return $result;
    }
     
    public static function get_newstock_items( $per_page = 50, $page_number = 1 ) {
	global $wpdb;
	$sql2 = "SELECT wp_posts.ID, items.post_title as nev, wp_postmeta.meta_value as darab, wp_postmeta.meta_id, wp_postmeta.meta_key from
        {$wpdb->prefix}posts
	JOIN {$wpdb->prefix}postmeta
        ON {$wpdb->prefix}postmeta.post_id={$wpdb->prefix}posts.ID
	join {$wpdb->prefix}posts as items
	ON {$wpdb->prefix}postmeta.meta_key=items.ID
	WHERE {$wpdb->prefix}posts.id=".$_REQUEST['newstock']."
        ORDER BY meta_id DESC";
        $result = $wpdb->get_results( $sql2, 'ARRAY_A' );
	return $result;
    }   

    public function __construct() {
	parent::__construct( array(
		'singular' => 'bevételezés',     
		'plural'   => 'bevételezések',    
		'ajax'     => false,       
		) );
    }

	
    public function get_columns() {
	if ( 'edit' === $this->current_action() || 'view' === $this->current_action()) {
            $columns = ['nev' => __( 'Cikk', 'changestock' ),
                        'darab' => __( 'Mennyiség', 'changestock' ),
			'meta_id' => __( 'Lehetőségek', 'changestock' )];
        }
        else {
            $columns = [
            'post_date'    => __( 'Bevételezés dátuma', 'changestock' ),
            'post_status' => __( 'Bevételezés állapota', 'changestock' ),
            'post_author' => __( 'Lehetőségek', 'changestock' )];
        }
        return $columns;
    }
	
    protected function get_sortable_columns() {
	$sortable_columns = array(
	);
        return $sortable_columns;
    }

    function column_nev( $item ) {
        $title = $item['nev'];
        return $title;
    }

    function column_darab( $item ) {
        $title = $item['darab'];
        return $title;
    }

    function column_meta_id( $item ) {
	if(get_current_user_id() == get_post($item['ID'])->post_author)
        	$title="<a href=\"?page=newstock_page&action=edit&newstock=".$item['ID']."&delstock=".$item['meta_key']."\">".__('Törlés','changestock')."</a>";
	else
		$title="";
        return $title;
    }

    function column_post_status( $item ) {
        if($item['post_status']=='open')
        $title = '<font color="green">'.__("Nyitott","changestock").'</font>';
        if($item['post_status']=='closed')
        $title = '<font color="red">'.__("Zárt","changestock").'</font>';
	if($item['post_status']=='accepted')
        $title = '<font color="black">'.__("Elfogadva","changestock").'</font>';
        return $title;
    }

    function column_post_author( $item ) {
	$title="";
	if((get_current_user_id() == $item['post_author']) && ($item['post_status']!='accepted')){
		if($item['post_status']=='open'){
			$title="<a href=\"?page=newstock_page&action=edit&newstock=".$item['ID']."\">".__('Szerkesztés','changestock')."</a>
			<a href=\"?page=newstock_page&action=close&newstock=".$item['ID']."\">".__('Lezárás','changestock')."</a>
			<a href=\"?page=newstock_page&action=delete&newstock=".$item['ID']."\">".__('Törlés','changestock')."</a>";
		}
		if($item['post_status']=='closed'){
			$title = "<a href=\"?page=newstock_page&action=view&newstock=".$item['ID']."\">".__('Megtekintés','changestock')."</a>
			<a href=\"?page=newstock_page&action=delete&newstock=".$item['ID']."\">".__('Törlés','changestock')."</a>";
		}

	}
	else{
		if($item['post_status']=='closed')
			$title = "<a href=\"?page=newstock_page&action=view&newstock=".$item['ID']."\">".__('Megtekintés','changestock')."</a>
			<a href=\"?page=newstock_page&action=accept&newstock=".$item['ID']."\">".__('Elfogadás','changestock')."</a>";
	}

	return $title;
    }

    protected function column_default( $item, $column_name ) {
	switch ( $column_name ) {
		case 'post_date':
		case 'post_status':
	        case 'post_author':
		case 'nev':
		case 'darab':
		case 'meta_id':
                return $item[ $column_name ];
            default:
                return print_r( $item, true );
        }
    }

	

    function prepare_items() {
	global $wpdb; 
	$per_page = 25;
	$columns  = $this->get_columns();
	$hidden   = array();
	$sortable = $this->get_sortable_columns();
	$this->_column_headers = array( $columns, $hidden, $sortable );
        if ( 'edit' === $this->current_action() || 'view' === $this->current_action())
		$data = $this->get_newstock_items();
	else
		$data = $this->get_newstocks();
		usort( $data, array( $this, 'usort_reorder' ) );
		$current_page = $this->get_pagenum();
		$total_items = count( $data );
		$data = array_slice( $data, ( ( $current_page - 1 ) * $per_page ), $per_page );
		$this->items = $data;
		$this->set_pagination_args( array(
			'total_items' => $total_items,                    
			'per_page'    => $per_page,  
			'total_pages' => ceil( $total_items / $per_page ), 
		) );
	}
}
