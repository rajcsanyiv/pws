<?php
class NewstockLog_Table extends WP_List_Table {

    public static function get_stocklogs( $per_page = 5, $page_number = 1 ) {
        global $wpdb;
	$sql="SELECT post_date,post_content from
        {$wpdb->prefix}posts
        WHERE {$wpdb->prefix}posts.post_type=\"newstock_log\"
        ORDER BY ID DESC";
        $result = $wpdb->get_results( $sql, 'ARRAY_A' );
	return $result;
    }

    public function __construct() {
	parent::__construct( array(
		'singular' => 'bevételezés napló',     
		'plural'   => 'bevételezés naplók',    
		'ajax'     => false,       
		) );
    }

	
    public function get_columns() {
	$columns = ['post_date' => __( 'Dátum', 'newstock' ),
                        'post_content' => __( 'Esemény', 'newstock' )];
        return $columns;
    }
	
    protected function get_sortable_columns() {
	$sortable_columns = array(
	);
        return $sortable_columns;
    }

    function column_post_date( $item ) {
        $title = $item['post_date'];
        return $title;
    }


    

    protected function column_default( $item, $column_name ) {
	switch ( $column_name ) {
		case 'post_date':
		case 'post_content':
                return $item[ $column_name ];
            default:
                return print_r( $item, true );
        }
    }

	

    function prepare_items() {
	global $wpdb; 
	$per_page = 5;
	$columns  = $this->get_columns();
	$hidden   = array();
	$sortable = $this->get_sortable_columns();
	$this->_column_headers = array( $columns, $hidden, $sortable );

		$data = $this->get_stocklogs();
		$current_page = $this->get_pagenum();
		$total_items = count( $data );
		$data = array_slice( $data, ( ( $current_page - 1 ) * $per_page ), $per_page );
		$this->items = $data;
		$this->set_pagination_args( array(
			'total_items' => $total_items,                    
			'per_page'    => $per_page,  
			'total_pages' => ceil( $total_items / $per_page ), 
		) );
	}
}
