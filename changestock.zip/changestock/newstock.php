<?php
/*
 * Plugin Name: Change stock
 * Description: A plugin for change product stock. 
 * Version: 1.0
 * Author: Viktor Rajcsanyi
 * Author URI:  http://promera.hu
 * Text Domain: changestock
 * Domain Path: /languages
 */

$plugin = plugin_basename( __FILE__ );

if( !function_exists('is_plugin_active') ) {
    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    if( is_plugin_active($plugin) ) {
        deactivate_plugins( $plugin );
}
$url=strtok($_SERVER["REQUEST_URI"],'?');
    echo"<a href=".$url.">Back</a>";
    wp_die( __( 'Please install and Activate WooCommerce, Change Stock shutting down. ', 'changestock' ), 'Plugin dependency check', array( 'back_link' => false ) );
    exit;
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

if ( ! class_exists( 'Newstock_Table' ) ) {
//	require_once( ABSPATH . 'wp-content/plugins/wc_new_stock/newstock-table.php' );
        require_once( plugin_dir_path( __FILE__ ) . '/newstock-table.php');
}
if ( ! class_exists( 'NewstockLog_Table' ) ) {
//	require_once( ABSPATH . 'wp-content/plugins/wc_new_stock/newstocklog-table.php' );
        require_once( plugin_dir_path( __FILE__ ) . '/newstocklog-table.php');
}

add_action('plugins_loaded', 'plugin_init'); 

function plugin_init() {
	load_plugin_textdomain( 'changestock', false, dirname(plugin_basename(__FILE__)).'/languages/' );
}

function newstock_create_page() {
	add_menu_page( __('Bevételezés','changestock'), __('Bevételezés funkció','changestock'), 'edit_posts', 'bevetelezes', 'menu', 'dashicons-clipboard', 49 );
	add_submenu_page( 'bevetelezes', __('Bevételezés','changestock'), __('Bevételezés','changestock'), 'edit_posts', 'newstock_page', 'newstock_page' );
	add_submenu_page( 'bevetelezes', __('Napló','changestock'), __('Napló','changestock'), 'edit_posts', 'bevetelezes_naplo', 'newstock_log' );
}

add_action( 'admin_menu', 'newstock_create_page' );

function menu(){
?>
<h1 class="wp-heading-inline"><?php _e("Bevételezés menü","changestock"); ?></h1><br/>
<?php _e("Ezzel a funkcióval lehet terméket bevételezni.","changestock"); ?><br/>
<?php _e("A megszakított bevételezés folytatható, egy adott tétel törölhető illetve módosítható.","changestock"); ?><br/>
<?php _e("Egy bevételezéshez felvitt azonos cikkszámú tételek közül az utolsó darabszámát veszi figyelembe.","changestock"); ?><br/>
<?php _e("A bevételezés a zárásig módosítható, zárás után törölhető vagy más felhasználó által elfogadható.","changestock"); ?><br/>
<?php _e("Elfogadott bevételezés már nem módosítható vagy törölhető.","changestock"); ?>

<?php
}

function newstock_log(){
?>
<h1 class="wp-heading-inline"><?php _e("Bevételezés napló","changestock"); ?></h1>
<?php

wp_reset_query();
$newstock_log = new NewstockLog_Table();
$newstock_log->prepare_items();
?>
<form id="newstock-table" method="get">
		<input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
		<?php $newstock_log->display() ?>
</form>
<?php
}
function newstock_page() {
//bevételezés elfogadása
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='accept'){
		if(get_post_status( $_REQUEST['newstock'] )=='closed'){
			$_pf = new WC_Product_Factory();  
			$meta=get_allmeta($_REQUEST['newstock']);
			if (is_array($meta) && !empty($meta) && isset($meta[0])) {
				foreach($meta as $item){
				if(is_numeric(trim($item->meta_key))){	
					$_product=$_pf->get_product(trim($item->meta_key));
					$new_quantity = $_product->increase_stock( trim($item->meta_value) );
				}
				}

			}		
			if (is_object($meta)) {
				if(is_numeric(trim($item->meta_key))){	
					$_product=$_pf->get_product(trim($item->meta_key));
					$new_quantity = $_product->increase_stock( trim($item->meta_value) );
				}
			}

		wp_update_post(array(
	        	'ID'    =>  $_REQUEST['newstock'],
	        	'post_status'   =>  'accepted'
	        ));
		}
		global $current_user;
		wp_get_current_user();
		$display_name=$current_user->display_name;
		$string= __('elfogadott egy bevételezést:', 'changestock');		
		add_stock_log($display_name." ".$string." ".$_REQUEST['newstock']);	   
	}
//bevételezés törlése
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='delete'){
		wp_delete_post( $_REQUEST['newstock'], true );
		global $current_user;
		wp_get_current_user();
		$display_name=$current_user->display_name;		
		$string= __('törölt egy bevételezést:', 'changestock');
		add_stock_log($display_name." ".$string." ".$_REQUEST['newstock']);	  
	}
//termék törlése a bevételezésből
	if(isset($_REQUEST['delstock'])){
		delete_post_meta( $_REQUEST['newstock'], $_REQUEST['delstock']);
		global $current_user;
		wp_get_current_user();
		$display_name=$current_user->display_name;
		$termek=get_post_id_by_meta_key_and_value('_sku',$_REQUEST['delstock']);
		$termek=get_post_meta( $_REQUEST['delstock'], '_sku', true );
		$string1= __('terméket törölt a', 'changestock');
		$string2= __('bevételezésből:', 'changestock');
		add_stock_log($display_name." ".$string1." ".$_REQUEST['newstock']." ".$string2." ".get_the_title($_REQUEST['delstock'])." (".$termek.")");
	}
//bevételezés zárása
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='close'){
		wp_update_post(array(
		        'ID'    =>  $_REQUEST['newstock'],
		        'post_status'   =>  'closed'
	        ));
		global $current_user;
		wp_get_current_user();
		$display_name=$current_user->display_name;
		$string= __('lezárt egy bevételezést:', 'changestock');
		add_stock_log($display_name." ".$string." ".$post_id);
	}
//új bevételezés indítása
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='new'){
		$new_post = array(
			'post_title' => __('Bevételezés','changestock'),
			'post_content' => '',
			'post_status' => 'open',
			'post_date' => date('Y-m-d H:i:s'),
			'post_author' => $user_ID,
			'post_type' => 'newstock',
			'post_category' => array(0)
		);
		$post_id = wp_insert_post($new_post);
		global $current_user;
		wp_get_current_user();
		$display_name=$current_user->display_name;
		$string= __('indított egy új bevételezést:', 'changestock');
		add_stock_log($display_name." ".$string." ".$post_id);	 
	}
//termék hozzáadása a bevételezéshez
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='edit' && isset($_REQUEST['formcikkszam'])){
		$cikkszam=$_REQUEST['formcikkszam'];
		$termek=get_post_id_by_meta_key_and_value('_sku',$cikkszam);
		update_post_meta( $_REQUEST['newstock'], $termek, $_REQUEST['darabszam'] );
		global $current_user;
		wp_get_current_user();
		$display_name=$current_user->display_name;
		$string1= __('rögzített a', 'changestock');
		$string2= __('bevételezéshez:', 'changestock');
		$string3= __('egység', 'changestock');
		add_stock_log($display_name." ".$string1." ".$_REQUEST['newstock']." ".$string2." ".$_REQUEST['darabszam']." ".$string3." ".get_the_title($termek)." (".$_REQUEST['formcikkszam'].")");	
	}
	$newstock_table = new Newstock_Table();
        $newstock_table->prepare_items();      
?>
<h1 class="wp-heading-inline"><?php _e("Bevételezés","changestock");?></h1>
<a href="?page=newstock_page&action=new" class="newstock_create"><?php _e("Új bevételezés","changestock");?></a>
<STYLE>
a.newstock_create {
    -webkit-appearance: button;
    -moz-appearance: button;
    appearance: button;

    text-decoration: none;
    color: initial;
}
</STYLE>
<form id="newstock-table" method="get">
		<input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
		<?php $newstock_table->display() ?>
</form>
<?php
    	if (isset ($_REQUEST['action']) && 'edit' == $_REQUEST['action']){
  		$html = '<div class="wrap">';
		$html .= '<input type="text" size="10" id="cikkszam" />';
		$html .= '<button id="newstock-wp-ajax-button">'.__("Termék keresése","changestock").'</button>';
		$html .= '<table id="newstock-ajax-table">
			<thead>
			<tr>
			<th>Név</th><th>'.__("Cikkszám","changestock").'</th>
      			</tr>
			</thead>
    			<tbody><tr></tr>';
		$html .= '</tbody></table>';
		$html .= '</div>';
  		echo $html;
		$newstock=$_REQUEST['newstock'];
		$form = '<form id="newstock-add" method="get" action="admin.php">';
		$form .= __("Cikkszám","changestock").': <input type="text" size="10" name="formcikkszam" id="formcikkszam" readonly="readonly"/>';
		$form .= __("Darabszám","changestock").': <input type="text" size="10" name="darabszam" id="darabszam" />';
		$form .= '<input type=hidden name="page" value="newstock_page" />';
		$form .= '<input type=hidden name="action" value="edit" />';
		$form .= '<input type=hidden name="newstock" value="'.$newstock.'" />';
		$form .= '<input type="submit" value='.__("Hozzáadás","changestock").'>';
		$form .= '</form>';
		echo $form;
	}
}

function newstock_ajax_script() {
?>
	<script type="text/javascript" >
	jQuery(document).ready(function($) {
		$( '#newstock-wp-ajax-button' ).click( function() {
			var cikkszam = $( '#cikkszam' ).val();
			$.ajax({
        		method: "POST",
		        url: ajaxurl,
		        data: { 'action': 'newstock_approal_action', 'cikkszam': cikkszam }
      		})
	.done(function( data ) {
	        console.log('Successful AJAX Call! /// Return Data: ' + data);
	        data = JSON.parse( data );
		$( '#newstock-ajax-table tr:last' ).remove();
	        $( '#newstock-ajax-table' ).append('<tr><td>' + data.post_title + '</td><td>' + data.meta_value + '</td></tr>');
		document.getElementById("formcikkszam").value="";
		if(data.meta_value!="0"){		
			document.getElementById("formcikkszam").value=data.meta_value;
		}
	})
	.fail(function( data ) {
		console.log('Failed AJAX Call :( /// Return Data: ' + data);
	});
	});
	});
	</script>
  <?php
}
add_action( 'admin_footer', 'newstock_ajax_script' );

function newstock_ajax_handler() {
  global $wpdb;

  $cikkszam = $_POST['cikkszam'];
$sql='SELECT post_title, meta_value FROM `wp_posts` join wp_postmeta on wp_posts.ID=wp_postmeta.post_id where wp_posts.post_type="product" and wp_postmeta.meta_value="'.$cikkszam.'"';
$data = $wpdb->get_row( $sql, ARRAY_A );
if(empty($data)){
$data = array( 
    "post_title" => __("Nincs találat","changestock"), 
    "meta_value" => "0", 
    ); 
}
  echo json_encode($data);
  wp_die(); 
}
add_action( 'wp_ajax_newstock_approal_action', 'newstock_ajax_handler' );

function get_post_id_by_meta_key_and_value($key, $value) {
	global $wpdb;
	$meta = $wpdb->get_results("SELECT * FROM `".$wpdb->postmeta."` WHERE meta_key='".$wpdb->escape($key)."' AND meta_value='".$wpdb->escape($value)."'");
	if (is_array($meta) && !empty($meta) && isset($meta[0])) {
		$meta = $meta[0];
	}		
	if (is_object($meta)) {
		return $meta->post_id;
	}
	else {
		return false;
	}
}

function get_allmeta( $source ) {
        global $wpdb;
	$meta = $wpdb->get_results("SELECT * FROM `".$wpdb->postmeta."` WHERE post_id='".$wpdb->escape($source)."'");
	return $meta;
}

function add_stock_log( $event ){
	$new_post = array(
		'post_title' => __("Bevételezés napló","changestock"),
		'post_content' => $event,
		'post_status' => 'open',
		'post_date' => date('Y-m-d H:i:s'),
		'post_author' => $user_ID,
		'post_type' => 'newstock_log',
		'post_category' => array(0)
	);
	$post_id = wp_insert_post($new_post); 
}
?>
