<?php
/*
 * Plugin Name: Change stock
 * Plugin URI: 
 * Description: A plugin for change product stock. 
 * Version: 1.0
 * Author: Viktor Rajcsanyi
 * Author URI: 
 *
 */
$plugin = plugin_basename( __FILE__ );

if( !function_exists('is_plugin_active') ) {
    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    if( is_plugin_active($plugin) ) {
        deactivate_plugins( $plugin );
}
$url=strtok($_SERVER["REQUEST_URI"],'?');
    echo"<a href=".$url.">Back</a>";
    wp_die( __( 'Please install and Activate WooCommerce, Change Stock shutting down. ', 'woocommerce-addon-slug' ), 'Plugin dependency check', array( 'back_link' => false ) );
    exit;
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

if ( ! class_exists( 'Newstock_Table' ) ) {
//	require_once( ABSPATH . 'wp-content/plugins/wc_new_stock/newstock-table.php' );
        require_once( plugin_dir_path( __FILE__ ) . '/newstock-table.php');
}
if ( ! class_exists( 'NewstockLog_Table' ) ) {
//	require_once( ABSPATH . 'wp-content/plugins/wc_new_stock/newstocklog-table.php' );
        require_once( plugin_dir_path( __FILE__ ) . '/newstocklog-table.php');
}

function newstock_create_page() {
	add_menu_page( 'Bevételezés', 'Bevételezés funkció', 'edit_posts', 'bevetelezes', 'menu', 'dashicons-clipboard', 49 );
	add_submenu_page( 'bevetelezes', 'Bevételezés', 'Bevételezés', 'edit_posts', 'newstock_page', 'newstock_page' );
	add_submenu_page( 'bevetelezes', 'Napló', 'Napló', 'edit_posts', 'bevetelezes_naplo', 'newstock_log' );
}

add_action( 'admin_menu', 'newstock_create_page' );

function menu(){
?>
<h1 class="wp-heading-inline">Bevételezés menü</h1><br/>
Ezzel a funkcióval lehet terméket bevételezni.<br/>
A megszakított bevételezés folytatható, egy adott tétel törölhető illetve módosítható.<br/>
Egy bevételezéshez felvitt azonos cikkszámú tételek közül az utolsó darabszámát veszi figyelembe.<br/>
A bevételezés a zárásig módosítható, zárás után törölhető vagy más felhasználó által elfogadható.<br/>
Elfogadott bevételezés már nem módosítható vagy törölhető.

<?php
}

function newstock_log(){
?>
<h1 class="wp-heading-inline">Bevételezés napló</h1>
<?php

wp_reset_query();
$newstock_log = new NewstockLog_Table();
$newstock_log->prepare_items();
?>
<form id="newstock-table" method="get">
		<input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
		<?php $newstock_log->display() ?>
</form>
<?php
}
function newstock_page() {
//bevételezés elfogadása
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='accept'){
		if(get_post_status( $_REQUEST['newstock'] )=='closed'){
			$_pf = new WC_Product_Factory();  
			$meta=get_allmeta($_REQUEST['newstock']);
			if (is_array($meta) && !empty($meta) && isset($meta[0])) {
				foreach($meta as $item){
				if(is_numeric(trim($item->meta_key))){	
					$_product=$_pf->get_product(trim($item->meta_key));
					$new_quantity = $_product->increase_stock( trim($item->meta_value) );
				}
				}

			}		
			if (is_object($meta)) {
				if(is_numeric(trim($item->meta_key))){	
					$_product=$_pf->get_product(trim($item->meta_key));
					$new_quantity = $_product->increase_stock( trim($item->meta_value) );
				}
			}

		wp_update_post(array(
	        	'ID'    =>  $_REQUEST['newstock'],
	        	'post_status'   =>  'accepted'
	        ));
		}
		global $current_user;
		wp_get_current_user();
		$display_name=$current_user->display_name;		
		add_stock_log($display_name." elfogadott egy bevételezést: ".$_REQUEST['newstock']);	   
	}
//bevételezés törlése
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='delete'){
		wp_delete_post( $_REQUEST['newstock'], true );
		global $current_user;
		wp_get_current_user();
		$display_name=$current_user->display_name;		
		add_stock_log($display_name." törölt egy bevételezést: ".$_REQUEST['newstock']);	  
	}
//termék törlése a bevételezésből
	if(isset($_REQUEST['delstock'])){
		delete_post_meta( $_REQUEST['newstock'], $_REQUEST['delstock']);
		global $current_user;
		wp_get_current_user();
		$display_name=$current_user->display_name;
		$termek=get_post_id_by_meta_key_and_value('_sku',$_REQUEST['delstock']);
		$termek=get_post_meta( $_REQUEST['delstock'], '_sku', true );
		add_stock_log($display_name." terméket törölt a ".$_REQUEST['newstock']." bevételezésből: ".get_the_title($_REQUEST['delstock'])." (".$termek.")");
	}
//bevételezés zárása
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='close'){
		wp_update_post(array(
		        'ID'    =>  $_REQUEST['newstock'],
		        'post_status'   =>  'closed'
	        ));
		global $current_user;
		wp_get_current_user();
		$display_name=$current_user->display_name;
		add_stock_log($display_name." lezárt egy bevételezést: ".$post_id);
	}
//új bevételezés indítása
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='new'){
		$new_post = array(
			'post_title' => 'Bevételezés',
			'post_content' => '',
			'post_status' => 'open',
			'post_date' => date('Y-m-d H:i:s'),
			'post_author' => $user_ID,
			'post_type' => 'newstock',
			'post_category' => array(0)
		);
		$post_id = wp_insert_post($new_post);
		global $current_user;
		wp_get_current_user();
		$display_name=$current_user->display_name;
		add_stock_log($display_name." indított egy új bevételezést: ".$post_id);	 
	}
//termék hozzáadása a bevételezéshez
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='edit' && isset($_REQUEST['formcikkszam'])){
		$cikkszam=$_REQUEST['formcikkszam'];
		$termek=get_post_id_by_meta_key_and_value('_sku',$cikkszam);
		update_post_meta( $_REQUEST['newstock'], $termek, $_REQUEST['darabszam'] );
		global $current_user;
		wp_get_current_user();
		$display_name=$current_user->display_name;
		add_stock_log($display_name." rögzített a ".$_REQUEST['newstock']." bevételezéshez: ".$_REQUEST['darabszam']." egység ".get_the_title($termek)." (".$_REQUEST['formcikkszam'].")");	
	}
	$newstock_table = new Newstock_Table();
        $newstock_table->prepare_items();      
?>
<h1 class="wp-heading-inline">Bevételezés</h1>
<a href="?page=newstock_page&action=new" class="newstock_create">Új bevételezés</a>
<STYLE>
a.newstock_create {
    -webkit-appearance: button;
    -moz-appearance: button;
    appearance: button;

    text-decoration: none;
    color: initial;
}
</STYLE>
<form id="newstock-table" method="get">
		<input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
		<?php $newstock_table->display() ?>
</form>
<?php
    	if (isset ($_REQUEST['action']) && 'edit' == $_REQUEST['action']){
  		$html = '<div class="wrap">';
		$html .= '<input type="text" size="10" id="cikkszam" />';
		$html .= '<button id="newstock-wp-ajax-button">Termék keresése</button>';
		$html .= '<table id="newstock-ajax-table">
			<thead>
			<tr>
			<th>Név</th><th>Cikkszám</th>
      			</tr>
			</thead>
    			<tbody><tr></tr>';
		$html .= '</tbody></table>';
		$html .= '</div>';
  		echo $html;
		$newstock=$_REQUEST['newstock'];
		$form = '<form id="newstock-add" method="get" action="admin.php">';
		$form .= 'Cikkszám: <input type="text" size="10" name="formcikkszam" id="formcikkszam" readonly="readonly"/>';
		$form .= 'Darabszám: <input type="text" size="10" name="darabszam" id="darabszam" />';
		$form .= '<input type=hidden name="page" value="newstock_page" />';
		$form .= '<input type=hidden name="action" value="edit" />';
		$form .= '<input type=hidden name="newstock" value="'.$newstock.'" />';
		$form .= '<input type="submit" value="Hozzáadás">';
		$form .= '</form>';
		echo $form;
	}
}

function newstock_ajax_script() {
?>
	<script type="text/javascript" >
	jQuery(document).ready(function($) {
		$( '#newstock-wp-ajax-button' ).click( function() {
			var cikkszam = $( '#cikkszam' ).val();
			$.ajax({
        		method: "POST",
		        url: ajaxurl,
		        data: { 'action': 'newstock_approal_action', 'cikkszam': cikkszam }
      		})
	.done(function( data ) {
	        console.log('Successful AJAX Call! /// Return Data: ' + data);
	        data = JSON.parse( data );
		$( '#newstock-ajax-table tr:last' ).remove();
	        $( '#newstock-ajax-table' ).append('<tr><td>' + data.post_title + '</td><td>' + data.meta_value + '</td></tr>');
		document.getElementById("formcikkszam").value="";
		if(data.meta_value!="találat"){		
			document.getElementById("formcikkszam").value=data.meta_value;
		}
	})
	.fail(function( data ) {
		console.log('Failed AJAX Call :( /// Return Data: ' + data);
	});
	});
	});
	</script>
  <?php
}
add_action( 'admin_footer', 'newstock_ajax_script' );

function newstock_ajax_handler() {
  global $wpdb;

  $cikkszam = $_POST['cikkszam'];
$sql='SELECT post_title, meta_value FROM `wp_posts` join wp_postmeta on wp_posts.ID=wp_postmeta.post_id where wp_posts.post_type="product" and wp_postmeta.meta_value='.$cikkszam;
$data = $wpdb->get_row( $sql, ARRAY_A );
if(empty($data)){
$data = array( 
    "post_title" => "Nincs", 
    "meta_value" => "találat", 
    ); 
}
  echo json_encode($data);
  wp_die(); 
}
add_action( 'wp_ajax_newstock_approal_action', 'newstock_ajax_handler' );

function get_post_id_by_meta_key_and_value($key, $value) {
	global $wpdb;
	$meta = $wpdb->get_results("SELECT * FROM `".$wpdb->postmeta."` WHERE meta_key='".$wpdb->escape($key)."' AND meta_value='".$wpdb->escape($value)."'");
	if (is_array($meta) && !empty($meta) && isset($meta[0])) {
		$meta = $meta[0];
	}		
	if (is_object($meta)) {
		return $meta->post_id;
	}
	else {
		return false;
	}
}

function get_allmeta( $source ) {
        global $wpdb;
	$meta = $wpdb->get_results("SELECT * FROM `".$wpdb->postmeta."` WHERE post_id='".$wpdb->escape($source)."'");
	return $meta;
}

function add_stock_log( $event ){
	$new_post = array(
		'post_title' => 'Bevételezés napló',
		'post_content' => $event,
		'post_status' => 'open',
		'post_date' => date('Y-m-d H:i:s'),
		'post_author' => $user_ID,
		'post_type' => 'newstock_log',
		'post_category' => array(0)
	);
	$post_id = wp_insert_post($new_post); 
}
?>
