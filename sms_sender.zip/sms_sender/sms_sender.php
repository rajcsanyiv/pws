<?php
/**
 * Plugin Name: SMS Sender
 * Description: SMS-ek kezelése, sablonok, küldés, telefonszám validáció.
 * Version: 1.0
 * Author: Naszádi László [WBS]
 * Text Domain: sms_sender
 * Domain Path: /languages/
 */
$demo=false;

if (!defined('ABSPATH')) {
    exit;
}
$abspath=ABSPATH;
$abspath=substr($abspath, 0, -3)."app/";

if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    exit;
}

define('_SMS_SENDER_TOKEN', 'YmSHqEWG4JLL6dnDJh9qsmutGdr6gFbKk9CWH3pYZgqwEHt7Wq99NDNMHW9dHThJYVZtcKFhgrvvH9jFfkmSFgDHP46yz9uLvHGjabVUkyGMx3RUc5uQqyMycCMDfLTC');
require_once('http_request_parser.php');
add_action('rest_api_init', function () {
    // <editor-fold defaultstate="collapsed" desc="pre functions">
    $request_parse = function() {
        $request = array();
        parse_raw_http_request($request);
        return $request;
    };
    $token_ok = function($token) {
        return $token === _SMS_SENDER_TOKEN;
    };
    $exec = function($func) use ($request_parse, $token_ok) {
        $response = new stdClass();
        $response->ok = false;
        $response->msg = '';
        if (strcasecmp($_SERVER['REQUEST_METHOD'], 'POST') != 0) {
            http_response_code(405); //Method Not Allowed
            $response->msg = "A kérésnek mindenképpen POST-nak kell lennie!";
        } else {
            $contentType = isset($_SERVER["CONTENT_TYPE"]) ? trim($_SERVER["CONTENT_TYPE"]) : '';
            if (strcasecmp($contentType, 'application/x-www-form-urlencoded') != 0) {
                http_response_code(415); //Unsupported Media Type
		$msg = __( 'A kérés tartalmának mindenképpen "application/x-www-form-urlencoded"-nek kell lennie. Ehelyett volt: ', 'sms_sender' );
                $response->msg = $msg . $contentType;
            } else {
                $request = $request_parse();
                if (!is_array($request)) {
                    http_response_code(400); //Bad Request
                    $response->msg = __("Hiba a kérés feldolgozása során!","sms_sender");
                } else if (!isset($request['token'])) {
                    http_response_code(400); //Bad Request
                    $response->msg = __("Hiányzik a 'token' paraméter!","sms_sender");
                } else if (!$token_ok($request['token'])) {
                    http_response_code(400); //Bad Request
                    $response->msg = __("Hibás a 'token' paraméter!","sms_sender");
                } else {
                    unset($request['token']);
                    $func($request, $response);
                }
            }
        }
        return $response;
    };
    // </editor-fold>
    // <editor-fold defaultstate="collapsed" desc="send-sms">
    register_rest_route('private', 'send-sms', array(
        'methods' => WP_REST_Server::CREATABLE,
        'callback' => function ($params) use ($exec) {
            return $exec(function($request, &$response) {
                        if (!isset($request['phones'])) {
                            http_response_code(400); //Bad Request
                            $response->msg = __("Hiányzik a 'phones' paraméter!","sms_sender");
                            return;
                        }
                        if (is_string($request['phones'])) {
                            $request['phones'] = explode(',', $request['phones']);
                        }
                        $phones = array_unique(array_map('trim', $request['phones']));
                        if (empty($phones) || !$phones[0]) {
                            http_response_code(400); //Bad Request
                            $response->msg = __("Üres a 'phones' paraméter!","sms_sender");
                            return;
                        }
                        if (!isset($request['text'])) {
                            http_response_code(400); //Bad Request
                            $response->msg = __("Hiányzik a 'text' paraméter!","sms_sender");
                            return;
                        }
                        $text = trim($request['text']);
                        if (!$text) {
                            http_response_code(400); //Bad Request
                            $response->msg = __("Üres a 'text' paraméter!","sms_sender");
                            return;
                        }
                        $response->ok = true;
                        $response->msg = "OK";
                        $msgs = array();
                        foreach ($phones as $phone) {
                            if ($phone) {
				if(get_option('sms_gateway')=="Bitnet"){
                                	$ch = curl_init(SMS_Sender::get_sms_url($phone, $text));
                                	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                	$res = curl_exec($ch);
                                	curl_close($ch);
                                	if ($res != 'OK') {
                                	    $response->ok = false;
                                	    $msgs[] = $phone;
                                	}
                            	}
				if(get_option('sms_gateway')=="Textbelt"){
                                	$ch = curl_init('https://textbelt.com/text');
                                	$data = array(
                                	'phone' => $phone,
	                                'message' => $text,
	                                'key' => get_option('textbeltkey'),	
        	                        );
	                                curl_setopt($ch, CURLOPT_POST, 1);
	                                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
	                                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	                                $res = curl_exec($ch);
                                	curl_close($ch);
					$obj = json_decode($res);	                             
	                        	if ($obj->{'success'} != 'true') {
        	                            $response->ok = false;
                                	    $msgs[] = $phone;
        	                	}
				}
                            }
                            if (!empty($msgs)) {
				$msg = __("A következő számokra nem mentek ki az üzenetek: " ,"sms_sender");
                                $response->msg = $msg . implode(", ", $msgs);
                            }
                        }
            });
        }
    ));
    // </editor-fold>
});

class SMS_Sender {

    // <editor-fold defaultstate="collapsed" desc="vars, constructor">

    protected static $plugin_basename;
    protected static $plugin_path;
    protected static $plugin_url;
    protected static $table_sms;

function myplugin_ajaxurl() {

   echo '<script type="text/javascript">
           var ajaxurl = "' . admin_url('admin-ajax.php') . '";
         </script>';
}


function addsmsmenu(){
	add_menu_page(__('SMS küldés' ,'sms_sender'),
                      __('SMS','sms_sender'),
                      'manage_options',
                      'sms_sender',
                      array(&$this, 'topLevelMenu'));
        $subMenus = array();     
        $subMenus[__('SMS küldés' ,"sms_sender")] = 'render_admin_page';
        foreach($subMenus as $key => $value) {
            add_submenu_page('sms_sender',
                             $key,
                             $key,
                             'manage_options',
                             $value,
                             array(&$this, $value));
        }
}
    protected function __construct() {
        global $wpdb;
        // init vars
        self::$plugin_basename = plugin_basename(__FILE__);
        self::$plugin_path = plugin_dir_path(self::$plugin_basename);
        self::$plugin_url = plugin_dir_url(self::$plugin_basename);
        self::$table_sms = $wpdb->prefix . 'sms';
        // add actions
        add_action('plugins_loaded', array($this, 'action_plugins_loaded'));
        add_action('init', array($this, 'action_init'));
        add_action('woocommerce_checkout_order_review', array($this, 'action_woocommerce_checkout_order_review'));
        add_action('wp_ajax_validate_sms', array($this, 'action_ajax_validate_sms'));
        add_action('wp_ajax_nopriv_validate_sms', array($this, 'action_ajax_validate_sms'));
	add_action( 'admin_menu', array($this,'addsmsmenu'));
	add_action('wp_head', array($this,'myplugin_ajaxurl'));
        // add filters
        add_filter('woocommerce_after_checkout_form', array($this, 'filter_woocommerce_after_checkout_form'));
        add_filter('woocommerce_after_checkout_validation', array($this, 'filter_woocommerce_after_checkout_validation'));
        // scripts
        //wp_enqueue_script('bootstrap-confirmation', self::$plugin_url . 'assets/bootstrap-confirmation.min.js', array('jquery'), false, true);
        wp_enqueue_script('sms-sender', self::$plugin_url . 'assets/sms-sender.js', array('jquery'), false, true);
        // <editor-fold defaultstate="collapsed" desc="js localize">
        wp_localize_script('sms-sender', 'sms_sender', array(
            'no_more_times' => esc_attr__('Nincs többszöri újrapróbálkozásra lehetőség! Kérjük vegye fel a kapcsolatot velünk.', 'sms_sender')
        ));
        // </editor-fold>
    }

    // </editor-fold>
    // <editor-fold defaultstate="collapsed" desc="plugin functions">

    /**
     * 
     * @staticvar SMS_Sender $instance
     * @return SMS_Sender
     */
    public static function instance() {
        static $instance = null;
        if (!$instance) {
            $instance = new self();
        }
        return $instance;
    }

    public static function plugin_basename() {
        return self::$plugin_basename;
    }

    public static function plugin_path() {
        return self::$plugin_path;
    }

    public static function plugin_url() {
        return self::$plugin_url;
    }

    public static function table_sms() {
        return self::$table_sms;
    }

    // </editor-fold>
    // <editor-fold defaultstate="collapsed" desc="actions">

    public function action_plugins_loaded() {
        global $wpdb;
        // install database tables
        $collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE IF NOT EXISTS `" . self::$table_sms . "` (
                `phone` VARCHAR(20) NOT NULL,
                `code` CHAR(6) NOT NULL,
                `entered` BOOLEAN NOT NULL,
                PRIMARY KEY (phone)
            ) $collate;";
        $abspath=ABSPATH;
	//$abspath=substr($abspath, 0, -3)."app/";
	require_once($abspath . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        $sql = "REPLACE INTO `" . self::$table_sms . "` (`phone`, `code`, `entered`) VALUES (%s, %s, %s)";
        $ok = $wpdb->query($wpdb->prepare($sql, $this->get_debug_phone(), 'xxxxxx', TRUE));
    }

    public function action_init() {
        if (!session_id()) {
            session_start();
        }
        load_plugin_textdomain('sms_sender', false, self::$plugin_path . 'languages');
    }

    public function action_woocommerce_checkout_order_review() {
        $val = false;
        $uid = get_current_user_id();
        if ($uid) {
            $phone = '+36' . get_user_meta($uid, 'billing_phone', true);
            $sms = $this->select_sms($phone);
            if (!empty($sms) && $sms['entered'] == '1') {
                $val = true;
            }
        } else {
            // TODO ezt ellenőrizni kell
            $sms = $this->select_sms('+36' . $_POST['billing_phone']);
            if (!empty($sms) && $sms['entered'] == '1') {
                $val = true;
            }
        }
        ?><input type="hidden" id="phone_validated" value="<?php echo($val ? '1' : '0'); ?>" /><?php
        //WC()->session->set('sms_sender_validate_times', 1);
        $times = (int) WC()->session->get('sms_sender_validate_times');
        if (!$times) {
            $times = 1;
            WC()->session->set('sms_sender_validate_times', $times);
        }
        ?><input type="hidden" id="phone_validated_times" value="<?php echo($times); ?>" /><?php
        if(!$val)
	    include 'tpls/sms_validate_modal.php';
    }

    public function action_ajax_validate_sms() {
        $res = new stdClass();
        $res->ok = false;
	if($demo)
	        $res->ok = true;
        $times = (int) WC()->session->get('sms_sender_validate_times');
        if (!empty($_POST['action']) && $_POST['action'] == 'validate_sms' && !empty($_POST['subaction']) && trim($_POST['phone']) != '+36') {
            if ($_POST['subaction'] == 'send') {
                if ($_POST['phone'] == $this->get_debug_phone()) {
                    $res->ok = true;
                } else if ($times <= 10) {
                    $sms = $this->select_sms($_POST['phone']);
                    if (empty($sms) || !$sms['entered']) {
                        $code = $this->replace_sms($_POST["phone"]);
                        if ($code) {
                            WC()->session->set('sms_sender_validate_times', ++$times);
                            if(get_option('sms_gateway')=="Bitnet"){
                                $ch = curl_init(self::get_sms_url($_POST["phone"], 'S-' . $code));
                                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                $response = curl_exec($ch);
                                curl_close($ch);
				if ($response == 'OK') {
                                	$res->ok = true;
                            	}
                            }
                            if(get_option('sms_gateway')=="Textbelt"){
                                $ch = curl_init('https://textbelt.com/text');
                                $data = array(
                                'phone' => $_POST["phone"],
                                'message' => 'S-' . $code,
                                'key' => get_option('textbeltkey'),	
                                );

                                curl_setopt($ch, CURLOPT_POST, 1);
                                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                $response = curl_exec($ch);
                                curl_close($ch);
				$obj = json_decode($response);	                             
	                        if ($obj->{'success'} == 'true') {
        	                        $res->ok = true;
        	                }
                            }
			    error_log($response, 0);                           
                        }
                    } else {
                        //$res->ok = true;
                        //$res->msg = esc_html__('Ez a telefonszám már ellenörzött.', 'sms_sender');
                    }
                }
            } else if ($_POST['subaction'] == 'check' && !empty($_POST['code'])) {
                if ($_POST['phone'] == $this->get_debug_phone()) {
                    $res->ok = true;
                } else {
                    $sms = $this->select_sms($_POST['phone']);
                    if (!empty($sms) && $sms['code'] === $_POST['code']) {
                        if ($this->update_sms($_POST['phone'])) {
                            $res->ok = true;
                        }
                    }
                }
            }
        }
        $res->times = $times;
        wp_send_json($res);
        wp_die();
    }

    // </editor-fold>
    // <editor-fold defaultstate="collapsed" desc="filters">

    public function filter_woocommerce_after_checkout_form() {
        // TODO
    }

    public function filter_woocommerce_after_checkout_validation() {
        $sms = $this->select_sms('+36' . $_POST['billing_phone']);
        if (empty($sms) || $sms['entered'] != '1') {
		if(!demo){
			wc_add_notice('<span id="sms_validate_error_msg_012">' . esc_html__('A telefonszám még nem lett ellenörizve!', 'sms_sender') . '</span>', 'error', 'error__validation__billing_phone__r' . rand(1000, 9999));
		}
        }
    }

    // </editor-fold>
    // <editor-fold defaultstate="collapsed" desc="render admin page">

    public function render_admin_page() {
        // inaktiv vasarlok listaja, akik meg nem rendeltek semmit
        $this->check_user_permission();
        if (!empty($_POST["phone"])) {
            if(get_option('sms_gateway')=="Bitnet"){
                $response = curl_exec(curl_init(self::get_sms_url($_POST["phone"], $_POST["message"])));
            }
            if(get_option('sms_gateway')=="Textbelt"){
                $ch = curl_init('https://textbelt.com/text');
                $data = array(
                'phone' => $_POST["phone"],
                'message' => $_POST['message'],
                'key' => get_option('textbeltkey'),
                );

                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $response = curl_exec($ch);
                curl_close($ch);
            }                          
            echo "<br><br><br>";
            echo $response . "<br />";
            echo $_POST["phone"] . "<br />";
            echo $_POST["message"] . "<br />";
        }
        ?><div class="wrap">
            <h1><?= esc_html(get_admin_page_title()); ?></h1>
            <form name="new user" method="post">
                <input type="text" name="phone" placeholder="+36..." /> <br />
                <input type="text" name="message" placeholder=<?php _e("Your message","sms_sender");?> /><br />
                <input type="submit"  value="<?php _e("Send","sms_sender");?>"/>
            </form>
        </div><?php
    }

    // </editor-fold>
    // <editor-fold defaultstate="collapsed" desc="protected functions">

    protected function get_debug_phone() {
        return '+36+99951357456852';
    }

    public static function get_sms_url($phone, $msg) {
        $url = 'https://sms.bitnet.hu/api/v1/send/';
        $user = get_option('bitnetuser');
        $pwd = get_option('bitnetpwd');
        $return = $url . '?';
        $return .= 'charset=7bit';
        $return .= '&username=' . urlencode($user);
        $return .= '&password=' . urlencode($pwd);
        $return .= '&receiver=' . urlencode($phone);
        $return .= '&text=' . urlencode($msg);
        return $return;
    }

    /**
     * van-e a felhasznalonak legalabb szerkeszto jogosultsaga
     */
    protected function check_user_permission() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'sms_sender'));
        }
    }

    // </editor-fold>
    // <editor-fold defaultstate="collapsed" desc="sms table functions">

    protected function replace_sms($phone) {
        /* @var $wpdb wpdb */
        global $wpdb;
        $code = false;
        $phone = trim($phone);
        if ($phone) {
            $code = rand(100000, 999999);
            if (false === $wpdb->replace(self::$table_sms, array('phone' => $phone, 'code' => $code, 'entered' => false))) {
                $code = false;
            }
        }
        return $code;
    }

    protected function update_sms($phone) {
        /* @var $wpdb wpdb */
        global $wpdb;
        $phone = trim($phone);
        if (!$phone) {
            return false;
        }
        return false !== $wpdb->update(self::$table_sms, array('entered' => true), array('phone' => $phone));
    }

    protected function select_sms($phone) {
        /* @var $wpdb wpdb */
        global $wpdb;
        $phone = trim($phone);
        if (!$phone) {
            return false;
        }
        $sql = "SELECT `code`, `entered` FROM `" . self::$table_sms . "` WHERE `phone` = '$phone'";
        return $wpdb->get_row($sql, ARRAY_A);
    }

    // </editor-fold>
}
SMS_Sender::instance();

if ( ! class_exists( 'WC_Settings_Smssender' ) ) :

if ( ! class_exists( 'WC_Settings_Page' ) ) {
	require_once( $abspath . '/plugins/woocommerce/includes/admin/settings/class-wc-settings-page.php' );
}

function sms_sender_add_settings() {
	class WC_Settings_Smssender extends WC_Settings_Page {
		public function __construct() {
			$this->id    = 'sms_sender';
			$this->label = __( 'SMS sender', 'sms_sender' );
			add_filter( 'woocommerce_settings_tabs_array',        array( $this, 'add_settings_page' ), 20 );
			add_action( 'woocommerce_settings_' . $this->id,      array( $this, 'output' ) );
			add_action( 'woocommerce_settings_save_' . $this->id, array( $this, 'save' ) );
			add_action( 'woocommerce_sections_' . $this->id,      array( $this, 'output_sections' ) );
		}

		public function get_sections() {		
			$sections = array(
				'setup' => __( 'Section 1', 'sms_sender' )
			);
			return apply_filters( 'woocommerce_get_sections_' . $this->id, $sections );
		}

		public function get_settings( $current_section = '' ) {
			$settings = apply_filters( 'sms_sender_section1_settings', array(	
				array(
				'type'     => 'select',
				'id'       => 'sms_gateway',
				'name'     => __( 'SMS küldés', 'sms_sender' ),
				'desc'     => __( '', 'sms_sender' ),
				'default'  => 'no',
				'options' => array(
					'None' => 'None',	
					'Bitnet' => 'Bitnet',
					'Textbelt' => 'Textbelt'
     					)
				),
                                array(
				'type'     => 'text',
				'id'       => 'bitnetuser',
				'name'     => __( 'Bitnet user', 'sms_sender' ),
				'desc'     => __( '', 'sms_sender' ),
				'default'  => 'no',
				),
                                array(
				'type'     => 'text',
				'id'       => 'bitnetpwd',
				'name'     => __( 'Bitnet password', 'sms_sender' ),
				'desc'     => __( '', 'sms_sender' ),
				'default'  => 'no',
				),                                
                                array(
				'type'     => 'text',
				'id'       => 'textbeltkey',
				'name'     => __( 'Textbelt key', 'sms_sender' ),
				'desc'     => __( '', 'sms_sender' ),
				'default'  => 'textbelt',
				),
				) 
			);
			return apply_filters( 'woocommerce_get_settings_' . $this->id, $settings, $current_section );
		}
		
		public function output() {		
			global $current_section;
			$settings = $this->get_settings( $current_section );
			WC_Admin_Settings::output_fields( $settings );
		}

		public function save() {		
			global $current_section;			
			$settings = $this->get_settings( $current_section );
			WC_Admin_Settings::save_fields( $settings );
		}
	}
	return new WC_Settings_Smssender();
}

add_filter( 'woocommerce_get_settings_pages', 'sms_sender_add_settings', 15 );

endif;
