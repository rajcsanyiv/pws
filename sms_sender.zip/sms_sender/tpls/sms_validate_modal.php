<style type="text/css">
    .vertical-alignment-helper {
        display:table;
        height: 100%;
        width: 100%;
    }
    .vertical-align-center {
        display: table-cell;
        vertical-align: middle;
    }
    .modal-content {
        width:inherit;
        height:inherit;
        margin: 0 auto;
    }
    #sms_validate_modal_resend {
        padding: 4px;
        background-color: #38c1ee;
    }
    .sms_validate_inputs {
        width: 25px;
        display: inline-block;
    }
</style>
<div class="modal fade" id="sms_validate_modal" tabindex="-1" role="dialog" aria-labelledby="sms_validate_modal_label" aria-hidden="true">
    <div class="vertical-alignment-helper">
        <div class="modal-dialog vertical-align-center">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="sms_validate_modal_label"><?php esc_html_e('Telefonszám ellenörzés', 'sms_sender') ?></h4>
                    <p><?php esc_html_e('Telefonszám: ', 'sms_sender') ?><b id="sms_validate_modal_label_phone"></b></p>
                    <hr>
                    <p><?php _e('első rendeléskor vagy telefonszám változása esetén, <br>a számot egy sms kóddal ellenőrizni kell', 'sms_sender') ?></p>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <p id="sms_validate_modal_sending_msg" style="display: none;"><?php esc_html_e('SMS küldése folyamatban...', 'sms_sender') ?></p>
                        <p id="sms_validate_modal_sending_msg_done" style="display: none;"><?php esc_html_e('SMS elküldve.', 'sms_sender') ?></p>
                        <p id="sms_validate_modal_sending_msg_fail" style="display: none;"><?php esc_html_e('SMS küldése sikertelen volt! Kérjük próbálkozzon újra.', 'sms_sender') ?></p>
                    </div>
                    <div class="form-group">
                        <label for="sms_validate_modal_code1" class="control-label"><?php esc_html_e('Ellenörző kód:', 'sms_sender') ?></label><br/>
                        <b id="sms_validate_preinput_1" class="sms_validate_preinput">S</b>&nbsp;
                        <b class="sms_validate_preinput">-</b>&nbsp;
                        <input type="text" class="form-control sms_validate_inputs" id="sms_validate_modal_code1" maxlength="1">&nbsp;
                        <input type="text" class="form-control sms_validate_inputs" id="sms_validate_modal_code2" maxlength="1">&nbsp;
                        <input type="text" class="form-control sms_validate_inputs" id="sms_validate_modal_code3" maxlength="1">&nbsp;
                        <input type="text" class="form-control sms_validate_inputs" id="sms_validate_modal_code4" maxlength="1">&nbsp;
                        <input type="text" class="form-control sms_validate_inputs" id="sms_validate_modal_code5" maxlength="1">&nbsp;
                        <input type="text" class="form-control sms_validate_inputs" id="sms_validate_modal_code6" maxlength="1">&nbsp;
                        <button id ="sms_validate_modal_check" type="button" class="btn btn-success"><?php esc_html_e('ELLENÖRZÉS', 'sms_sender') ?></button>
                        <br><br>
                        <p id="sms_validate_modal_check_msg" style="display: none;"><?php esc_html_e('Ellenörzés folyamatban...', 'sms_sender') ?></p>
                        <p id="sms_validate_modal_check_msg_done" style="display: none;"><?php esc_html_e('Az ellenörzés sikeres volt.', 'sms_sender') ?></p>
                        <p id="sms_validate_modal_check_msg_fail" style="display: none;"><?php esc_html_e('Az ellenörzés sikertelen volt! Kérjük próbálkozzon újra.', 'sms_sender') ?></p>
                        <div id="sms_validate_modal_resend_label"><?php esc_html_e('Nem kapott kódot?', 'sms_sender') ?></div>
                        <button id="sms_validate_modal_resend" type="button" class="btn btn-sm btn-info"><?php esc_html_e('ÚJRAKÜLDÉS', 'sms_sender') ?></button>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php esc_html_e('bezár', 'sms_sender') ?></button>
                </div>
            </div>
        </div>
    </div>
</div>