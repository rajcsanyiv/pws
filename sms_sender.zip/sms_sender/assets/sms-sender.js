/* global sms_sender */

var sms_sender_validate_times = 1;

jQuery(document).ready(function ($) {
    var first_open = true;
    sms_sender_validate_times = parseInt($('#phone_validated_times').val());
//    sms_sender_validate_init();
//    var phone = $('#billing_phone').val();
//    var phone_validated = $('#phone_validated').val();
//    $('#billing_phone').unbind('change').change(function () {
//        first_open = true;
//        if (phone_validated === '1') {
//            if (phone !== $(this).val()) {
//                $('#phone_validated').val('0');
//                sms_sender_validate_init();
//            } else {
//                $('#phone_validated').val('1');
//            }
//        }
//    });
    $(".sms_validate_inputs").keyup(function (e) {
        var keyCode = e.keyCode || e.which;
        if (keyCode === 13) {
            $('#sms_validate_modal_check').trigger('click');
        } else if (this.value.length === this.maxLength && $.inArray(keyCode, [9, 16]) === -1) {
            $(this).next().focus().select();
        } else if (this.value.length === 0) {
            if (keyCode === 8 && $(this).attr('id') !== 'sms_validate_modal_code1') {
                $(this).prev().focus().select();
            }
        }
    });
    $('#sms_validate_modal').on('shown.bs.modal', function () {
        $('#sms_validate_modal_code1').focus();
        $('#sms_validate_modal_check').on('keyup keypress', function (e) {
            var keyCode = e.keyCode || e.which;
            e.preventDefault();
            if (keyCode === 13) {
                $(this).trigger('click');
            } else if (keyCode === 8) {
                $(this).prev().focus().select();
            }
        });
        $('#sms_validate_modal_label_phone').text('+36' + $('#billing_phone').val());
        if (first_open) {
            first_open = false;
            if (sms_sender_validate_times === 1) {
                sms_sender_validate_send();
            }
        }
        if (sms_sender_validate_times >= 5) {
            $('#sms_validate_modal_resend').attr('title', sms_sender.no_more_times);
            $('#sms_validate_modal_resend').prop('disabled', true);
            alert(sms_sender.no_more_times);
            $('#sms_validate_modal').modal('hide');
        }
    });
    $('#sms_validate_modal_resend').unbind('click').click(function () {
        sms_sender_validate_send();
    });
    $('#sms_validate_modal_check').unbind('click').click(function () {
        sms_sender_validate_check();
    });
    $(document.body).on('checkout_error', function () {
        if (!sms_sender_validate_init()) {
            $('#sms_validate_modal').modal('show');
        }
    });
//    $('form[name="checkout"]').submit(function (e) {
//        if (sms_sender_validate_init()) {
//            e.preventDefault();
//        } else {
//            $('#sms_validate_modal').modal('show');
//        }
//    });
});

// ez volt a régi
//function sms_sender_validate_init() {
//    $ = jQuery;
//    var pv = $('#phone_validated');
//    var fc = $('form[name="checkout"]');
//    if (!pv || pv.val() !== '1') {
//        if (!fc.hasClass('processing')) {
//            fc.addClass('processing');
//        }
//        return false;
//    } else {
//        fc.removeClass('processing');
//        return true;
//    }
//}

function sms_sender_validate_init() {
    $ = jQuery;
    var pv = $('.woocommerce-NoticeGroup-checkout ul.woocommerce-error li').length === 1;
    pv &= $('#sms_validate_error_msg_012').length === 1;
    return !pv;
}

function sms_sender_validate_send() {
    $ = jQuery;
    if (sms_sender_validate_times > 5) {
        return;
    }
    $('#sms_validate_modal_sending_msg_done').hide('fast');
    $('#sms_validate_modal_sending_msg_fail').hide('fast');
    $('#sms_validate_modal_sending_msg').show('fast');
    $.post(ajaxurl, {'action': 'validate_sms', 'subaction': 'send', 'phone': ('+36' + $('#billing_phone').val())}).done(function (res) {
        sms_sender_validate_times = parseInt(res.times);
        $('#sms_validate_modal_sending_msg').hide('fast');
        if (res.ok) {
            $('#sms_validate_modal_sending_msg_fail').hide('fast');
            $('#sms_validate_modal_sending_msg_done').show('fast');
        } else {
            if (sms_sender_validate_times >= 5) {
                $('#sms_validate_modal_resend').attr('title', sms_sender.no_more_times);
                $('#sms_validate_modal_resend').prop('disabled', true);
                alert(sms_sender.no_more_times);
            }
            $('#sms_validate_modal_sending_msg_done').hide('fast');
            $('#sms_validate_modal_sending_msg_fail').show('fast');
        }
    }).fail(function (xhr, status, error) {
        $('#sms_validate_modal_sending_msg').hide('fast');
        $('#sms_validate_modal_sending_msg_done').hide('fast');
        $('#sms_validate_modal_sending_msg_fail').show('fast');
    });
}

function sms_sender_validate_check() {
    $ = jQuery;
    $('#sms_validate_modal_check_msg_done').hide('fast');
    $('#sms_validate_modal_check_msg_fail').hide('fast');
    $('#sms_validate_modal_check_msg').show('fast');
    var code = '';
    code += $('#sms_validate_modal_code1').val();
    code += $('#sms_validate_modal_code2').val();
    code += $('#sms_validate_modal_code3').val();
    code += $('#sms_validate_modal_code4').val();
    code += $('#sms_validate_modal_code5').val();
    code += $('#sms_validate_modal_code6').val();
    $.post(ajaxurl, {'action': 'validate_sms', 'subaction': 'check', 'phone': '+36' + $('#billing_phone').val(), 'code': code}).done(function (res) {
        $('#sms_validate_modal_check_msg').hide('fast');
        if (res.ok) {
            $('#sms_validate_modal_check_msg_fail').hide('fast');
            $('#sms_validate_modal_check_msg_done').show('fast');
            $('#phone_validated').val('1');
            $('#sms_validate_modal').modal('hide');
            $('form.checkout').trigger('submit');
        } else {
            $('#sms_validate_modal_check_msg_done').hide('fast');
            $('#sms_validate_modal_check_msg_fail').show('fast');
        }
    }).fail(function (xhr, status, error) {
        $('#sms_validate_modal_check_msg').hide('fast');
        $('#sms_validate_modal_check_msg_done').hide('fast');
        $('#sms_validate_modal_check_msg_fail').show('fast');
    });
}
