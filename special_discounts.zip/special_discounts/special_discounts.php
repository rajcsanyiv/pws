<?php

/**
 * Plugin Name: Special Discounts
 * Description: Speciális és egyedi kedvezmények.
 * Version: 1.0
 * Author: Naszádi László [WBS]
 * Text Domain: special_discounts
 * Domain Path: /languages/
 */
if (!defined('ABSPATH')) {
    exit;
}
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    exit;
}

// <editor-fold defaultstate="collapsed" desc="LEÍRÁSOK">

/*
 * 1. eset: vákuum
 * Ha egy felhasználó vesz egy bizonyos (STATUS Edény 0.5 l+ Vákuum pumpa Akció!) akciós terméket (cikkszám: ST-Sale05) [továbbiakban: X],
 * és még minimum [2] darab terméket egy bizonyos (Vákuum tárolók) kategóriából (azonosító: 29) [továbbiakban: Y],
 * akkor kap [20]% kedvezményt minden termékből, kivéve az eleve akciós áron lévő termékek és egy bizonyos (Akciós termékek) kategóriában (azonosító: 47) lévő termékek.
 * Ez érvényes, ha a feltételek teljesülnek: ([X] termék plusz [2] termék [Y] kategóriából egy vagy több kosárra is felbontva akár)
 *  - az aktuális kosárra
 *  - az [X] termék megvásárlásától a rendelés teljesülése plusz [7] napig
 * A kedvezményt egy felhasználó többször is igénybe veheti az érvényességi időn belül.
 * 
 */

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="vákuum">

const SPECIAL_DISCOUNTS_VAKUUM_COUPON_DATA = array(
    'id' => 3299239,
    'code' => 'vákuum',
    'type' => 'special',
    'amount' => 20,
    'date_created' => null,
    'date_modified' => null,
    'date_expires' => null,
    'discount_type' => 'percent',
    'description' => '',
    'usage_count' => 0,
    'individual_use' => false, // XXX true, ha más kuponnal nem használható együtt
    'product_ids' => array(),
    'excluded_product_ids' => array(),
    'usage_limit' => 0,
    'usage_limit_per_user' => 0, // XXX egy felhasználó többször is felhasználhatja
    'limit_usage_to_x_items' => null,
    'free_shipping' => false,
    'product_categories' => array(),
    'excluded_product_categories' => array(47), // XXX kizárt kategóriák (akciós termékek kategória, 47)
    'exclude_sale_items' => true, // XXX kizárt (valóban) akciós termékek
    'minimum_amount' => '',
    'maximum_amount' => '',
    'email_restrictions' => array(),
    'used_by' => array(),
    'virtual' => true,
);
const SPECIAL_DISCOUNTS_VAKUUM_PROD_CID = 'ST-Sale05'; // ST-Sale05, 00405
const SPECIAL_DISCOUNTS_VAKUUM_CAT_ID = 29; // 29, 26
const SPECIAL_DISCOUNTS_VAKUUM_CAT_MIN_PIECE = 2; // 2, 4
const SPECIAL_DISCOUNTS_VAKUUM_DAYS = 7; // 7

add_filter('check_ajax_referer', function($action) {
    if ($action === 'apply-coupon' && !empty($_POST['coupon_code'] && $_POST['coupon_code'] === SPECIAL_DISCOUNTS_VAKUUM_COUPON_DATA['code'])) {
        $_POST['coupon_code'] = '-' . SPECIAL_DISCOUNTS_VAKUUM_COUPON_DATA['code'] . '-';
    }
}, 1, 1);

add_filter('woocommerce_get_shop_coupon_data', function($param, $data) {
    if (!$param && $data === SPECIAL_DISCOUNTS_VAKUUM_COUPON_DATA['code']) {
        $param = SPECIAL_DISCOUNTS_VAKUUM_COUPON_DATA;
    }
    return $param;
}, 10, 2);

function SPECIAL_DISCOUNTS_VAKUUM_CHECK_COUPON() {
    $user_id = get_current_user_id();
    $vakuum_date = get_user_meta($user_id, 'vakuum_date', true);
    if ($vakuum_date === false || $vakuum_date === null || $vakuum_date === '' || $vakuum_date >= date('Y-m-d')) {
        $vakuum_state = get_user_meta($user_id, 'vakuum_state', true);
        $vakuum_prod = $vakuum_state !== false && $vakuum_state !== null && $vakuum_state !== '';
        $vakuum_cat = (int) $vakuum_state;
        foreach (WC()->cart->get_cart() as $item) {
            /* @var $prod WC_Product */
            $prod = $item['data'];
            if ($prod instanceof WC_Product) {
                if (!$vakuum_prod && $prod->get_sku() === SPECIAL_DISCOUNTS_VAKUUM_PROD_CID) {
                    $vakuum_prod = true;
                }
                if (in_array(SPECIAL_DISCOUNTS_VAKUUM_CAT_ID, $prod->get_category_ids())) {
                    $vakuum_cat += $item['quantity'];
                }
            }
        }
        if (($vakuum_prod && $vakuum_cat >= SPECIAL_DISCOUNTS_VAKUUM_CAT_MIN_PIECE)) {
            if (!WC()->cart->has_discount(SPECIAL_DISCOUNTS_VAKUUM_COUPON_DATA['code'])) {
                $the_coupon = new WC_Coupon(SPECIAL_DISCOUNTS_VAKUUM_COUPON_DATA['code']);
                if ($the_coupon->is_valid_for_cart()) {
                    WC()->cart->apply_coupon(sanitize_text_field(SPECIAL_DISCOUNTS_VAKUUM_COUPON_DATA['code']));
                }
            }
        } else {
            if (WC()->cart->has_discount(SPECIAL_DISCOUNTS_VAKUUM_COUPON_DATA['code'])) {
                WC()->cart->remove_coupon(sanitize_text_field(SPECIAL_DISCOUNTS_VAKUUM_COUPON_DATA['code']));
            }
        }
    }
}

add_action('woocommerce_check_cart_items', 'SPECIAL_DISCOUNTS_VAKUUM_CHECK_COUPON');

add_action('woocommerce_checkout_update_order_review', 'SPECIAL_DISCOUNTS_VAKUUM_CHECK_COUPON');

add_action('woocommerce_thankyou', function ($order_id) {
    $order = wc_get_order($order_id);
    $user_id = get_current_user_id();
    $vakuum_state = get_user_meta($user_id, 'vakuum_state', true);
    $vakuum_prod = $vakuum_state !== false && $vakuum_state !== null && $vakuum_state !== '';
    $vakuum_cat = (int) $vakuum_state;
    if ($vakuum_cat < SPECIAL_DISCOUNTS_VAKUUM_CAT_MIN_PIECE) {
        /* @var $item WC_Order_Item_Product */
        foreach ($order->get_items() as $item) {
            if ($item instanceof WC_Order_Item_Product) {
                /* @var $prod WC_Product */
                $prod = $item->get_product();
                if ($prod instanceof WC_Product) {
                    if (!$vakuum_prod && $prod->get_sku() === SPECIAL_DISCOUNTS_VAKUUM_PROD_CID) {
                        $vakuum_prod = true;
                    }
                    if (in_array(SPECIAL_DISCOUNTS_VAKUUM_CAT_ID, $prod->get_category_ids())) {
                        $vakuum_cat += $item['quantity'];
                    }
                }
            }
        }
        if ($vakuum_prod) {
            update_user_meta($user_id, 'vakuum_state', $vakuum_cat);
        }
    }
});

function SPECIAL_DISCOUNTS_VAKUUM_CLOSE_ORDER_DAYS($order_id, $add_days = false) {
    $order = wc_get_order($order_id);
    $user_id = $order->get_customer_id();
    $vakuum_state = get_user_meta($user_id, 'vakuum_state', true);
    $vakuum_prod = $vakuum_state !== false && $vakuum_state !== null && $vakuum_state !== '';
    if ($vakuum_prod) {
        /* @var $item WC_Order_Item_Product */
        foreach ($order->get_items() as $item) {
            if ($item instanceof WC_Order_Item_Product) {
                /* @var $prod WC_Product */
                $prod = $item->get_product();
                if ($prod instanceof WC_Product && $prod->get_sku() === SPECIAL_DISCOUNTS_VAKUUM_PROD_CID) {
                    $date = date('Y-m-d');
                    if ($add_days) {
                        $date = date('Y-m-d', strtotime($date . ' + ' . SPECIAL_DISCOUNTS_VAKUUM_DAYS . ' days'));
                    }
                    update_user_meta($user_id, 'vakuum_date', $date);
                    break;
                }
            }
        }
    }
}

add_action('woocommerce_order_status_completed', function ($order_id) {
    SPECIAL_DISCOUNTS_VAKUUM_CLOSE_ORDER_DAYS($order_id, true);
});

add_action('woocommerce_order_status_failed', function ($order_id) {
    SPECIAL_DISCOUNTS_VAKUUM_CLOSE_ORDER_DAYS($order_id);
});

add_action('woocommerce_order_status_refunded', function ($order_id) {
    SPECIAL_DISCOUNTS_VAKUUM_CLOSE_ORDER_DAYS($order_id);
});

add_action('woocommerce_order_status_cancelled', function ($order_id) {
    SPECIAL_DISCOUNTS_VAKUUM_CLOSE_ORDER_DAYS($order_id);
});

// </editor-fold>
