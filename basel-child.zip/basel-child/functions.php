<?php

function my_theme_enque_styles(){
	wp_enqueue_style( 'basel', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'basel-child', get_stylesheet_uri() . '/style.css', array( 'premium' ) );
}
//admin jogosultság ellenőrzés
$user = wp_get_current_user();
if($user->exists()){
	$user_id=get_current_user_id();
	$feketelista  = get_user_meta($user_id, 'feketelista', true);
	$promeraid  = get_user_meta($user_id, 'promera_id', true);
	$bonus  = get_user_meta($user_id, 'bonus', true);
}
$adminvagyok=false;
if(current_user_can('manage_options')){
    $adminvagyok=true;
}

//nem fizetett rendelések
if(!wp_next_scheduled('woocommerce_cancel_unpaid_orders'))
    wp_schedule_single_event( time() + 300, 'woocommerce_cancel_unpaid_orders' );

remove_action( 'woocommerce_cancel_unpaid_orders', 'wc_cancel_unpaid_orders' );
add_action( 'woocommerce_cancel_unpaid_orders', 'my_custom_wc_cancel_unpaid_orders' );

function my_custom_wc_cancel_unpaid_orders() {
    global $wpdb;
    $held_duration = get_option( 'woocommerce_hold_stock_minutes' );
    if ( $held_duration < 1 || get_option( 'woocommerce_manage_stock' ) != 'yes' )
        return;
    $date = date("Y-m-d H:i:s",strtotime('-'.absint($held_duration).' MINUTES',current_time('timestamp')));
    $unpaid_orders = $wpdb->get_col( $wpdb->prepare( "
        SELECT posts.ID
        FROM {$wpdb->posts} AS posts
        WHERE   posts.post_type   IN ('" . implode( "','", wc_get_order_types() ) . "')
        AND     posts.post_status = 'wc-on-hold'  
        AND     posts.post_modified < %s
    ", $date ) );

    if ( $unpaid_orders ) {
        foreach ( $unpaid_orders as $unpaid_order ) {
            $order = wc_get_order( $unpaid_order );
            if ( apply_filters( 'woocommerce_cancel_unpaid_order', 'checkout' === get_post_meta( $unpaid_order, '_created_via', true ), $order ) || true ) {
                $order->update_status( 'cancelled', __( 'Unpaid order cancelled - time limit reached.', 'woocommerce' ) );
                foreach ( $order->get_items() as $item ) {
                    if ( $item['product_id'] > 0 ) {
                        $_product = $order->get_product_from_item( $item );
                        if ( $_product && $_product->exists() && $_product->managing_stock() ) {
                            $old_stock = $_product->stock;
                            $qty = apply_filters( 'woocommerce_order_item_quantity', $item['qty'], $order, $item );
                                if(empty(get_post_meta($item['product_id'],'foglalt',true)))
                                    update_post_meta($item['product_id'],"foglalt",$qty);
                                else{
                                    $oldqty=get_post_meta($item['product_id'],'foglalt',true);
                                    $newqty=$oldqty+$qty;
                                    update_post_meta($item['product_id'],"foglalt",$newqty);
                                }
                            $new_quantity = $_product->increase_stock( $qty );
                            do_action( 'woocommerce_auto_stock_restored', $_product, $item );
                            $order->add_order_note( sprintf( __( '#%s termék készlete %s egységről %s egységre változott.', 'woocommerce' ), $_product->get_title(), $old_stock, $new_quantity) );
                            $order->send_stock_notifications( $_product, $new_quantity, $item['qty'] );
                        }
                    }
                }
            }    
        }
    }
    wp_clear_scheduled_hook( 'woocommerce_cancel_unpaid_orders' );
    wp_schedule_single_event( time() + ( absint( $held_duration ) * 60 ), 'woocommerce_cancel_unpaid_orders' );    
}

//feketelista és bonus
function my_order_itemmeta($order){
    $vevo=$order->get_customer_id();
    $feketelista2  = get_user_meta($vevo, 'feketelista', true);    
    echo '</br><p ';
    if($feketelista2){
	echo "style=\"color:red\"";
    }
    echo "></br><b>Feketelistás ügyfél!</b>&nbsp;
    <input name=\"fekete\" type=\"checkbox\" id=\"fekete\" value=\"1\" ";
    echo checked($feketelista2,1); 
    echo '/> </p>';
}

add_action('save_post', 'my_save_post',10 ,1);
function my_save_post($post_id){
    if (isset($_POST['fekete'])){
        $post_user_id=get_post_meta($post_id, '_customer_user', true);
        update_user_meta($post_user_id, 'feketelista', $_POST['fekete'] );
    }
    else{
        update_user_meta($post_user_id, 'feketelista', $_POST['fekete'] );
    }
    if(!isset($_POST['pontok'])){
        return $post_id;
    }
    if(defined('DOING_AUTOSAVE') &&DOING_AUTOSAVE){
        return $post_id;
    }
}

function my_woocommerce_update_account($user_id){
    update_user_meta($user_id, 'feketelista', htmlentities( $_POST['fekete'] ) );
    update_user_meta($user_id, 'promera_id', htmlentities( $_POST['promeraid'] ) );
    update_user_meta($user_id, 'bonus', htmlentities( $_POST['bonus'] ) );
}

function my_woocommerce_edit_account_form($user_id){
    $user_id = get_current_user_id();
    $feketelista=0;
    if(!empty($_GET['user_id'])){
        file_put_contents('php://stderr', print_r($_GET['user_id'], TRUE));
        $user_id=$_GET['user_id'];
    }
?>

<table class="form-table">
    <tbody>
        <tr id="promeraid">
            <th>
                <label for="promeraid">Promera kód</label>
            </th>
            <td>
                <input type="text" name="promeraid" 
                value="<?php echo esc_attr( $promeraid ); ?>" class="input-text" 
                <?php if(!$adminvagyok) echo "disabled" ?>/>
            </td>
        </tr>
        <tr id="bonus">
            <th>
                <label for="bonus">Bónusz</label>
            </th>
            <td>
                <input type="text" name="bonus" 
                value="<?php echo esc_attr( $bonus ); ?>" class="input-text" 
                <?php if(!$adminvagyok) echo "disabled" ?>/>
            </td>
        </tr>

<?php if($adminvagyok){?>

        <tr id="fekete">
            <th>
                <label for="fekete">Feketelista</label>
            </th>
            <td>
                <legend class="screen-reader-text">
                    <span>Feketelista</span>
                </legend>
                <input name="fekete" type="checkbox" id="fekete" value="1" 
                <?php checked($feketelista,1); ?> 
                <?php if(!$adminvagyok) echo "disabled" ?>/>
                </input>
                <br>
            </td>
        </tr>

<?php } ?>

    </tbody>
</table>

<?php
}

add_action('wp_enque_scripts','my_theme_enque_styles', PHP_INT_MAX);
add_action('show_user_profile','my_woocommerce_edit_account_form');
add_action('profile_update','my_woocommerce_update_account',10 ,2);
add_action('edit_user_profile','my_woocommerce_edit_account_form');
add_action( 'woocommerce_admin_order_data_after_order_details', 'my_order_itemmeta', 10, 1 );
add_action( 'woocommerce_order_action_wc_custom_order_action', 'my_process_action' );
add_action( 'woocommerce_process_shop_order_meta', 'my_process_action' );


//rendelés módosítás bejegyzése
function my_process_action($order) {
    $order2 = new WC_Order($order);
    $order2->add_order_note( "módosítás történt" , false, wp_get_current_user() );
}

//már regisztrált telefonszám és email cím ellenőrzés a pénztár oldalon
add_action( 'woocommerce_checkout_process', 'my_checkout_process');

function my_checkout_process() {
    if ( isset( $_POST['billing_email'] ) && !is_user_logged_in()){
        $repeatmail=$_POST['billing_email'];
        $users=get_users(array('meta_key' => 'billing_email', 'meta_value' => $repeatmail, meta_compare => '='));
        if(!empty($users)){
            wc_add_notice( __( 'Ezzel az email címmel már történt regisztráció, kérem lépjen be!' ), 'error' );
        }
    }

    if ( isset( $_POST['billing_phone'] ) && !is_user_logged_in()) {
	$b_phone = $_POST['billing_phone'];
	$phonecheck=get_users(array('meta_key' => 'billing_phone', 'meta_value' => $b_phone, meta_compare => '='));
        if(!empty($phonecheck))
    	    wc_add_notice( __( ' Ezzel a telefonszámmal már regisztráltak! ' ), 'error' );
    }
}

//Foglalt, raktáron van, rendelési idő
add_action( 'woocommerce_product_options_stock_status', 'woo_add_custom_general_fields' );
add_action( 'woocommerce_process_product_meta', 'woo_add_custom_general_fields_save' );

function woo_add_custom_general_fields_save( $post_id ){
    $woocommerce_text_field = $_POST['foglalt'];
    if( !empty( $woocommerce_text_field ) )
        update_post_meta( $post_id, 'foglalt', esc_attr( $woocommerce_text_field ) );

    $woocommerce_text_field = $_POST['_custom_field_rendeles_ido'];
    if( !empty( $woocommerce_text_field ) )
        update_post_meta( $post_id, '_custom_field_rendeles_ido', esc_attr( $woocommerce_text_field ) );	
}

function woo_add_custom_general_fields() {
    global $woocommerce, $post;
    echo '<div class="options_group">';
    woocommerce_wp_text_input( 
	array( 
		'id'                => 'foglalt', 
		'label'             => __( 'Foglalt', 'woocommerce' ), 
		'placeholder'       => '', 
		'description'       => __( 'Raktáron van, de foglalt.', 'woocommerce' ),
		'type'              => 'number', 
		'custom_attributes' => array(
				'step' 	=> 'any',
				//'min'	=> '0'
			) 
	)
    );

?>

<?php
  
  echo '</div>';

  echo '<div class="options_group">';
  
woocommerce_wp_text_input( 
    array( 
		'id'                => '_custom_field_rendeles_ido', 
		'label'             => __( 'Rendelés idő', 'woocommerce' ), 
		'placeholder'       => '', 
		'description'       => __( 'Ennyi plusz szállítási nap.', 'woocommerce' ),
		'type'              => 'number', 
		'custom_attributes' => array(
				'step' 	=> 'any',
				'min'	=> '0'
			) 
    )
);

?>

<?php
  echo '</div>';
}
add_action( 'woocommerce_product_quick_edit_save', 'woo_add_custom_general_fields_save' );
add_action( 'woocommerce_product_quick_edit_end', function(){
?>

    <div class="stock_fields">		
        <br class="clear" />
        <label class="stock_qty_field">
        <span class="title">Foglalt</span>
        <span class="input-text-wrap">
            <input type="number" name="foglalt" class="text stock" step="any" value="">
        </span>
        </label>		
    </div>
<?php
} );
add_action( 'woocommerce_product_quick_edit_end', function(){
?>

<script type="text/javascript"> 

jQuery(function(){
jQuery('#the-list').on('click', '.editinline', function(){  
    inlineEditPost.revert();
    var post_id = jQuery(this).closest('tr').attr('id');
    post_id = post_id.replace("post-", "");
    var $cfd_inline_data = jQuery('#foglalt_inline_' + post_id),
        $wc_inline_data = jQuery('#woocommerce_inline_' + post_id );
    jQuery('input[name="foglalt"]', '.inline-edit-row').val($cfd_inline_data.find("#foglalt").text());
    var product_type = $wc_inline_data.find('.product_type').text();
    if (product_type=='simple' || product_type=='external') {
        jQuery('.foglalt', '.inline-edit-row').show();
    } else {
        jQuery('.foglalt', '.inline-edit-row').hide();
    }
});
});
</script>
<?php
} );

add_action('woocommerce_product_quick_edit_save', function($product){
    if ( $product->is_type('simple') || $product->is_type('external') ) {
        $post_id = $product->id;
        if ( isset( $_REQUEST['foglalt'] ) ) {
            $customFieldDemo = trim(esc_attr( $_REQUEST['foglalt'] ));
            update_post_meta( $post_id, 'foglalt', wc_clean( $customFieldDemo ) );
        }
    }
}, 10, 1);

add_action( 'manage_product_posts_custom_column', function($column,$post_id){
    switch ( $column ) {
        case 'name' :
        ?>
        <div class="hidden foglalt_inline" id="foglalt_inline_<?php echo $post_id; ?>">
            <div id="foglalt"><?php echo get_post_meta($post_id,'foglalt',true); ?></div>
        </div>
        <?php
        break;
    default :
        break;
}
}, 99, 2);

add_filter( 'manage_edit-product_columns', 'show_foglalt_oszlop',15 );
function show_foglalt_oszlop($columns){
    unset( $columns['is_in_stock'] );
    $columns['foglalt_oszlop'] = __( 'Foglalt'); 
    $columns['keszlet_oszlop'] = __( 'Szabad');
    $columns['raktar_oszlop'] = __( 'Készlet');
    return $columns;
}

add_action( 'manage_product_posts_custom_column', 'custom_foglalt_oszlop', 10, 2 );

function custom_foglalt_oszlop( $column, $postid ) {
    global $wpdb;
    if ( $column == 'foglalt_oszlop' ) {
	$product = wc_get_product( $postid );
	if ( $product->is_type( 'variable' ) ){
		$query = "SELECT sum(meta_value)
                      FROM $wpdb->posts AS p, $wpdb->postmeta AS s
                      WHERE p.post_parent = $postid
                      AND p.post_type = 'product_variation'
                      AND p.post_status = 'publish'
                      AND p.id = s.post_id
                      AND s.meta_key = 'foglalt'";
	        $product_qty = $wpdb->get_var($wpdb->prepare($query,$post_id));
            	if ($product_qty) 
			echo $product_qty;
		else
			echo "0";		
		echo " db";
	}
	else{
		if(!empty(get_post_meta( $postid, 'foglalt', true )))
		        echo round(get_post_meta( $postid, 'foglalt', true ));
	        else
		        echo "0";
	echo " db";
	}
    }    
    if ( $column == 'keszlet_oszlop' ) {
	$product = wc_get_product( $postid );
	if ( $product->is_type( 'variable' ) ){
		$query = "SELECT sum(meta_value)
                      FROM $wpdb->posts AS p, $wpdb->postmeta AS s
                      WHERE p.post_parent = $postid
                      AND p.post_type = 'product_variation'
                      AND p.post_status = 'publish'
                      AND p.id = s.post_id
                      AND s.meta_key = '_stock'";
	        $product_qty = $wpdb->get_var($wpdb->prepare($query,$post_id));
            	if ($product_qty) 
			echo $product_qty;
		else
			echo "0";		
		echo " db";
	}
	else{
		if(!empty(get_post_meta( $postid, '_stock', true )))
		        echo round(get_post_meta( $postid, '_stock', true ));
	        else
		        echo "0";
	echo " db";
	}
    }
    if ( $column == 'raktar_oszlop' ) {
	$product = wc_get_product( $postid );
	if ( $product->is_type( 'variable' ) ){
		$query = "SELECT sum(meta_value)
                      FROM $wpdb->posts AS p, $wpdb->postmeta AS s
                      WHERE p.post_parent = $postid
                      AND p.post_type = 'product_variation'
                      AND p.post_status = 'publish'
                      AND p.id = s.post_id
                      AND s.meta_key = 'foglalt'";
	        $product_qty_f = $wpdb->get_var($wpdb->prepare($query,$post_id));
            	if ($product_qty_f) 
			$f = $product_qty_f;
		else
			$f = 0;		
		$query = "SELECT sum(meta_value)
                      FROM $wpdb->posts AS p, $wpdb->postmeta AS s
                      WHERE p.post_parent = $postid
                      AND p.post_type = 'product_variation'
                      AND p.post_status = 'publish'
                      AND p.id = s.post_id
                      AND s.meta_key = '_stock'";
	        $product_qty_k = $wpdb->get_var($wpdb->prepare($query,$post_id));
            	if ($product_qty_k) 
			$k = $product_qty_k;
		else
			$k = 0;
		$r=$f+$k;
	        if(!empty($r))
		    echo $r;
	        else
	            echo "0";
		echo " db";	
	}
	else{
		$f=(int)get_post_meta( $postid, 'foglalt', true );
        	$k=(int)get_post_meta( $postid, '_stock', true );       
	        $r=$f+$k;
	        if(!empty($r))
		    echo $r;
	        else
	            echo "0";
		echo " db";
	}
    }	
}

//rendelés állapotok átnevezése
function wc_renaming_order_status( $order_statuses ) {
    foreach ( $order_statuses as $key => $status ) {
        $new_order_statuses[ $key ] = $status;
        if ( 'wc-processing' === $key ) {
            $order_statuses['wc-processing'] = _x( 'Összekészítés folyamatban', 'Order status', 'woocommerce' );
        }
	if ( 'wc-completed' === $key ) {
            $order_statuses['wc-completed'] = _x( 'Teljesített', 'Order status', 'woocommerce' );
        }
	if ( 'wc-cancelled' === $key ) {
            $order_statuses['wc-cancelled'] = _x( 'Visszajött', 'Order status', 'woocommerce' );
        }
	if ( 'wc-refunded' === $key ) {
            $order_statuses['wc-refunded'] = _x( 'Összeg visszatérítve', 'Order status', 'woocommerce' );
        }
    }
    return $order_statuses;
}
add_filter( 'wc_order_statuses', 'wc_renaming_order_status' );

function wc_rename_order_status_type( $order_statuses ) {
    foreach ( $order_statuses as $key => $status ) {
        $new_order_statuses[ $key ] = $status;
        if ( 'wc-refunded' === $key ) {
            $order_statuses['wc-refunded']['label_count'] = _n_noop( 'Összeg visszatérítve <span class="count">(%s)</span>', 'Összeg visszatérítve <span class="count">(%s)</span>', 'woocommerce' );
	}
	if ( 'wc-refunded' === $key ) {
            $order_statuses['wc-cancelled']['label_count'] = _n_noop( 'Visszajött <span class="count">(%s)</span>', 'Visszajött <span class="count">(%s)</span>', 'woocommerce' );
        }
        if ( 'wc-processing' === $key ) {
            $order_statuses['wc-processing']['label_count'] = _n_noop( 'Összekészítés folyamatban <span class="count">(%s)</span>', 'Összekészítés folyamatban <span class="count">(%s)</span>', 'woocommerce' );
        }
        if ( 'wc-completed' === $key ) {
            $order_statuses['wc-completed']['label_count'] = _n_noop( 'Teljesített <span class="count">(%s)</span>', 'Teljesített <span class="count">(%s)</span>', 'woocommerce' );
        }
    }
    return $order_statuses;
}
add_filter( 'woocommerce_register_shop_order_post_statuses', 'wc_rename_order_status_type' );

add_filter('woocommerce_page_title', function ( $page_title ) {
    if ('Cart' == $page_title) {
        return "Kosár";
    }
    if ('Checkout' == $page_title) {
        return "Fizetés";
    }
});

add_filter('woocommerce_show_page_title', function ($page_title) {
    return false;
});

add_filter('woocommerce_get_availability_text', function ($text, $product) {
    if ($product->is_in_stock()) {
        $text = 'Raktáron';
    }
    return $text;
}, 10, 2);

//oldalnév, kosár ár és minicart módosítások
//TODO ellenőrizni kell-e még, a cartdropdown biztosan nem, más sablon függvényére hivatkozik 
add_filter('woocommerce_page_title', 'fwpt', 10,1);
function fwpt($page_title){
//$page_title.= "". include 'prodlink.php';
    return $page_title;
}

function custom_cart_price($price, $cart_item, $cart_item_key){
//$price='1234';
return $price;

}

add_filter('woocommerce_cart_item_price', 'custom_cart_price', 10, 3);

if(!function_exists('wpo_cartdropdown')){
 function wpo_cartdropdown(){
    if(WPO_WOOCOMMERCE_ACTIVED){
        global $woocommerce;
        ?>
            <div id="cart" class="dropdown">
                <div class="cart-icon">
                    <span class="hidden-sm hidden-xs"><?php _e('Cart:', 'premium'); ?></span>
                </div>
                <a class="dropdown-toggle mini-cart" data-toggle="dropdown" data-hover="dropdown" data-delay="0" href="" title="<?php _e('View your shopping cart', 'premium'); ?>">
                    <?php echo sprintf(_n(' <span class="mini-cart-items"> %d item </span> ', ' <span class="mini-cart-items"> %d items </span> ', $woocommerce->cart->cart_contents_count, 'premium'), $woocommerce->cart->cart_contents_count);?> 
<?php 
echo trim(WC()->cart->get_cart_subtotal());
?>
<?php //echo trim( $woocommerce->cart->get_cart_total() ); ?>
                </a>
                <div class="dropdown-menu">
                    <?php woocommerce_mini_cart(); ?>
                </div>
            </div>
        <?php
        }
    }
}

add_filter('woocommerce_get_stock_html', function($html) {
    $script = '<script type="text/javascript">';
    $script .= 'jQuery( function ( $ ) {';
    $script .= 'if(!$("p.stock.in-stock").length) {$("p.stock.isinstock").insertBefore($("form.cart"));}';
//    $script .= '$("p.stock").insertBefore($("form.cart"));';
    $script .= '});';
    $script .= '</script>';
    $html .= $script;
    return $html;
});

//szamlazz rendeles automata állapotváltás ha elkészült a számla
add_action('wc_szamlazz_after_invoice_success', function ($orderId) {
    $order = new WC_Order($orderId);
    $order->update_status('wc-processing');
});

//gyűjtő szállítás 
//Called by Ajax from App - list the contents of the folder so they can be downloaded and stored locally
function collective_delivery_joincode_check() {
$cpayment = WC()->session->get('chosen_payment_method');
    WC()->session->set('collective_delivery_code_checked', '');
    $res = new stdClass();
    $res->errormsg = __('Hiba a feldolgozás során...', 'wc_collective_delivery');
    if (isset($_POST['action']) && $_POST['action'] == 'collective_delivery_joincode_check' && isset($_POST['cdid'])) {
        $cdid = (string) $_POST['cdid'];
        WC()->session->set('collective_delivery_code', $cdid);
        $orders = get_posts(
                array(
                    'numberposts' => -1,
                    'meta_key' => 'collective_delivery_id',
                    'meta_value' => $cdid,
                    'post_type' => wc_get_order_types(),
                    'post_status' => array_keys(wc_get_order_statuses()),
                )
        );
        $count = count($orders);
        if ($count == 0) {
            $res->errormsg = __('Nem létezik ilyen "gyűjtő szállítás azonosító"!', 'wc_collective_delivery');
        } else if ($count != 1) {
            $res->errormsg = __('Hiba a feldolgozás során!', 'wc_collective_delivery');
        } else {
            /* @var $order WC_Order */
            $order = wc_get_order($orders[0]->ID);
            if ('open' == get_post_meta($order->get_id(), 'collective_delivery_state', true)) {
                $res->errormsg = '';
                $ppp = get_post_meta($order->get_id(), 'sprinter_ppp', true);
                if (is_array($ppp)) {
                    $res->info = "Szállítás módja: PickPackPont\n";
                    $res->info .= "Szállítás címe:\n";
                    $res->info .= implode("\n", $ppp);
                } else {
                    $res->info = "Szállítás módja: Házhozszállítás\n";
                    $res->info .= "Szállítás címe:\n";
                    $res->info .= str_replace(["<br/>", "<br>"], "\n", $order->get_formatted_shipping_address());
                }
                $res->info .= "\nFizetés módja: ";
                $payment = $order->get_payment_method();
                $res->payment = $payment;
                WC()->session->set('chosen_payment_method', $payment);
                WC()->session->set('collective_delivery_code_checked', 'ok');
            } else {
                $res->errormsg = __('Ez a "gyűtő szállítás" nem nyitott!', 'wc_collective_delivery');
            }
        }
    }
    if ($res->errormsg) {
        WC()->session->set('chosen_payment_method', $cpayment);
    }
    wp_send_json($res);
    wp_die();
}

add_action('wp_ajax_collective_delivery_joincode_check', 'collective_delivery_joincode_check');
add_action('wp_ajax_nopriv_collective_delivery_joincode_check', 'collective_delivery_joincode_check');

//fogyasztói ár szerkesztés
add_action( 'woocommerce_variation_options_pricing', 'add_fogyasztoi_ar_field_to_variations', 10, 3 ); 
 
function add_fogyasztoi_ar_field_to_variations( $loop, $variation_data, $variation ) {
	woocommerce_wp_text_input( array( 
	'id' => 'fogyasztoi_ar[' . $loop . ']', 
	'class' => 'short', 
	'label' => __( 'Fogyasztói ár', 'woocommerce' ),
	'value' => get_post_meta( $variation->ID, 'fogyasztoi_ar', true )
	) 
	);      
}
 
add_action( 'woocommerce_save_product_variation', 'save_fogyasztoi_ar_field_variations', 10, 2 );
  
function save_fogyasztoi_ar_field_variations( $variation_id, $i ) {
    $fogyasztoi_ar = $_POST['fogyasztoi_ar'][$i];
    if ( ! empty( $fogyasztoi_ar ) ) {
        update_post_meta( $variation_id, 'fogyasztoi_ar', esc_attr( $fogyasztoi_ar ) );
    } else delete_post_meta( $variation_id, 'fogyasztoi_ar' );
}
   
add_filter( 'woocommerce_available_variation', 'add_fogyasztoi_ar_field_variation_data' );
 
function add_fogyasztoi_ar_field_variation_data( $variations ) {
    $variations['fogyasztoi_ar'] = '<div class="woocommerce_custom_field">Fogyasztói ár: <span>' . get_post_meta( $variations[ 'variation_id' ], 'fogyasztoi_ar', true ) . '</span></div>';
    return $variations;
}

//kategóriák hozzáadása a breadcrumb-hoz
add_filter( 'woo_breadcrumbs_trail', 'add_categories_to_breadcrumb', 20 );
 
function add_categories_to_breadcrumb ( $trail ) {
  if ( ( get_post_type() == 'product' ) && is_singular() ) {
		global $post;
		$taxonomy = 'product_cat';
		$terms = get_the_terms( $post->ID, $taxonomy );
		$links = array();
		if ( $terms && ! is_wp_error( $terms ) ) {
			$count = 0;
			foreach ( $terms as $c ) {
				$count++;
				if ( $count > 1 ) { continue; }
				$parents = woo_get_term_parents( $c->term_id, $taxonomy, true, ', ', $c->name, array() );
				if ( $parents != '' && ! is_wp_error( $parents ) ) {
					$parents_arr = explode( ', ', $parents );
					foreach ( $parents_arr as $p ) {
						if ( $p != '' ) { $links[] = $p; }
					}
				}
			}
			$trail_end = get_the_title($post->ID);
			array_splice( $trail, 2, count( $trail ) - 1, $links );
			$trail['trail_end'] = $trail_end;
		}
	}
	return $trail;
}

if ( ! function_exists( 'woo_get_term_parents' ) ) {
function woo_get_term_parents( $id, $taxonomy, $link = false, $separator = '/', $nicename = false, $visited = array() ) {
	$chain = '';
	$parent = &get_term( $id, $taxonomy );
	if ( is_wp_error( $parent ) )
		return $parent;
	if ( $nicename ) {
		$name = $parent->slug;
	} else {
		$name = $parent->name;
	}
	if ( $parent->parent && ( $parent->parent != $parent->term_id ) && !in_array( $parent->parent, $visited ) ) {
		$visited[] = $parent->parent;
		$chain .= woo_get_term_parents( $parent->parent, $taxonomy, $link, $separator, $nicename, $visited );
	}
	if ( $link ) {
		$chain .= '<a href="' . get_term_link( $parent, $taxonomy ) . '" title="' . esc_attr( sprintf( __( "View all posts in %s" ), $parent->name ) ) . '">'.$parent->name.'</a>' . $separator;
	} else {
		$chain .= $name.$separator;
	}
	return $chain;
	}
}

//szállítási módtól függő fizetési módok
//TODO ellenőrizni kell-e még, az új Woocommerce-ben láttam hasonló megoldást
function updatepayments_ajax_handler() {
	if(isset($_POST['shipping'])){
	$shipping=$_POST['shipping'];
	$payment_methods = "<h3 class=\"cheading\">Fizetési mód</h3><ul class=\"wc_payment_methods payment_methods methods\">";
        if ($shipping) {
            if($shipping=="local_pickup"){
            $payment_methods .= "<li class=\"wc_payment_method payment_method_pop\">
                                    <input id=\"payment_method_pop\" type=\"radio\" class=\"input-radio with-font\" name=\"payment_method\" value=\"pop\"  checked='checked' data-order_button_text=\"\" />
                                    <label for=\"payment_method_pop\">Helyben fizetés</label>
                                    <div class=\"payment_box payment_method_pop\">
                                    <p>Átvételkor fizetés</p>
                                    </div>
                            </li>";
            }
            if($shipping=="flat_rate" || $shipping=="pont_sprinter" || $shipping=="collective_delivery"){
            $payment_methods .= "<li class=\"wc_payment_method payment_method_cod\">
                                    <input id=\"payment_method_cod\" type=\"radio\" class=\"input-radio with-font\" name=\"payment_method\" value=\"cod\"  checked='checked' data-order_button_text=\"\" />
                                    <label for=\"payment_method_cod\">Utánvétes fizetés</label>
                                    <div class=\"payment_box payment_method_cod\">
                                    <p>Fizetés készpénzben átvételkor.</p>
                                    </div>
                            </li>";
            }
            if($shipping=="local_pickup" || $shipping=="flat_rate" || $shipping=="pont_sprinter" || $shipping=="collective_delivery"){
            $payment_methods .= "<li class=\"wc_payment_method payment_method_barion\">
                                    <input id=\"payment_method_barion\" type=\"radio\" class=\"input-radio with-font\" name=\"payment_method\" value=\"barion\"  data-order_button_text=\"Megrendelés elküldése\" />
                                    <label for=\"payment_method_barion\">Fizetés Bankkártyával <img src=".get_site_url()."/wp-content/plugins/pay-via-barion-for-woocommerce/assets/barion-card-payment-banner-2016-300x35px.png alt=\"Barion védjegy\" style=\"display: inline\" />	</label>
                                    <div class=\"payment_box payment_method_barion\" style=\"display:none;\">
                                    <p>Fizess bankkártyával, nem kötelező regisztrálni!</p>
                                    </div>
                            </li>";
            }
            if($shipping=="local_pickup" || $shipping=="flat_rate" || $shipping=="pont_sprinter" || $shipping=="collective_delivery"){
            $payment_methods .= "<li class=\"wc_payment_method payment_method_ppec_paypal\">
                                    <input id=\"payment_method_ppec_paypal\" type=\"radio\" class=\"input-radio with-font\" name=\"payment_method\" value=\"ppec_paypal\"  data-order_button_text=\"Megrendelés elküldése\" />
                                    <label for=\"payment_method_ppec_paypal\">
                                    PayPal <img src=\"https://www.paypalobjects.com/webstatic/en_US/i/buttons/pp-acceptance-small.png\" alt=\"PayPal\" />	</label>
                                    <div class=\"payment_box payment_method_ppec_paypal\" style=\"display:none;\">
                                    <p>Fizetés Paypal rendszeren keresztül</p>
                                    </div>
                            </li>";
            }
            $payment_methods .= "</ul>";
        } else {
            $payment_methods .= 'Kérem előbb válasszon szállítási módot.';
        }

echo $payment_methods; 
	}
wp_die(); 
}

add_action( 'wp_ajax_updatepayments_action', 'updatepayments_ajax_handler' );
add_action( 'wp_ajax_nopriv_updatepayments_action', 'updatepayments_ajax_handler' );

?>
