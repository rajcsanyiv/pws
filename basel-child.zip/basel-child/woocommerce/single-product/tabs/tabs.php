<?php
/**
 * Single Product tabs
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/tabs/tabs.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 2.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Filter tabs and allow third parties to add their own.
 *
 * Each tab is an array containing title, callback and priority.
 * @see woocommerce_default_product_tabs()
 */
$tabs = apply_filters( 'woocommerce_product_tabs', array() );

$tabs_layout = (basel_product_design() == 'compact') ? 'accordion' : 'tabs';

if( ! function_exists( 'basel_custom_product_tab2_content' ) ) {
	function basel_custom_product_tab2_content() {
		$tab2_content = get_post_meta( get_the_ID(),  '_basel_product_custom_tab2_content', true );
		echo do_shortcode( $tab2_content );
	}
}
$custom_tab2_title = get_post_meta( get_the_ID(),  '_basel_product_custom_tab2_title', true );
if ( $custom_tab2_title ) {
$tabs['basel_custom_tab2'] = array(
				'title' 	=> $custom_tab2_title,
				'priority' 	=> 60,
				'callback' 	=> 'basel_custom_product_tab2_content'
			);
}

if( ! function_exists( 'basel_custom_product_tab3_content' ) ) {
	function basel_custom_product_tab3_content() {
		$tab3_content = get_post_meta( get_the_ID(),  '_basel_product_custom_tab3_content', true );
		echo do_shortcode( $tab3_content );
	}
}
$custom_tab3_title = get_post_meta( get_the_ID(),  '_basel_product_custom_tab3_title', true );
if ( $custom_tab3_title ) {
$tabs['basel_custom_tab3'] = array(
				'title' 	=> $custom_tab3_title,
				'priority' 	=> 60,
				'callback' 	=> 'basel_custom_product_tab3_content'
			);
}

if( ! function_exists( 'basel_custom_product_tab4_content' ) ) {
	function basel_custom_product_tab4_content() {
		$tab4_content = get_post_meta( get_the_ID(),  '_basel_product_custom_tab4_content', true );
		echo do_shortcode( $tab4_content );
	}
}
$custom_tab4_title = get_post_meta( get_the_ID(),  '_basel_product_custom_tab4_title', true );
if ( $custom_tab4_title ) {
$tabs['basel_custom_tab4'] = array(
				'title' 	=> $custom_tab4_title,
				'priority' 	=> 60,
				'callback' 	=> 'basel_custom_product_tab4_content'
			);
}

if ( ! empty( $tabs ) ) : ?>

	<div class="woocommerce-tabs wc-tabs-wrapper tabs-layout-<?php echo esc_attr( $tabs_layout ); ?>">
		<ul class="tabs wc-tabs">
			<?php foreach ( $tabs as $key => $tab ) : ?>
				<li class="<?php echo esc_attr( $key ); ?>_tab">
					<a href="#tab-<?php echo esc_attr( $key ); ?>"><?php echo apply_filters( 'woocommerce_product_' . $key . '_tab_title', esc_html( $tab['title'] ), $key ); ?></a>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php foreach ( $tabs as $key => $tab ) : ?>
			<div class="basel-tab-wrapper">
				<a href="#tab-<?php echo esc_attr( $key ); ?>" class="basel-accordion-title tab-title-<?php echo esc_attr( $key ); ?>"><?php echo apply_filters( 'woocommerce_product_' . $key . '_tab_title', esc_html( $tab['title'] ), $key ); ?></a>
				<div class="woocommerce-Tabs-panel woocommerce-Tabs-panel--<?php echo esc_attr( $key ); ?> panel entry-content wc-tab" id="tab-<?php echo esc_attr( $key ); ?>">
					<?php call_user_func( $tab['callback'], $key, $tab ); ?>
				</div>
			</div>
		<?php endforeach; ?>
	</div>

<?php endif; ?>
