( function ( $ ) {
 "use strict";
// Define the PHP function to call from here
 var data = {
   'action': 'mode_theme_update_mini_cart'
 };
 $.post(
   ajaxurl, // The AJAX URL
   data, // Send our PHP function
   function(response){
     $('#mode-mini-cart').html(response); // Repopulate the specific element with the new content
   }
 );
// Close anon function.
}( jQuery ) );
