<?php /* Template Name: AkciosTermekek */ ?>
 
<?php 
	get_header(); 
?>
<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">
<?php
	global $woocommerce;
	$params = array(
		'posts_per_page' => 5, 
		'post_type' => 'product',
		'meta_key' => '_sale_price',
		'meta_value' => '0',
		'meta_compare' => '>='
	);
	$loop = new WP_Query($params);
	$style_product = ($style == 'carousel') ? 'product-'.$style : '';
	echo "<div class='widget widget-products products ".esc_attr( $style_product )."'>";
	if($title!=''){ 
?>
		<h3 class="widget-title visual-title <?php echo esc_attr( $title_align ).' '.esc_attr( $size ); ?>">
	        <span><?php echo esc_html( $title ); ?></span>
		</h3>
<?php 
	}
	if ( $loop->have_posts() ) {
?>
		<section class="wpo-mainbody wpo-archive-product">
    		<div class="container">
			<div class="row">
	        	<section class="col-xs-12 no-sidebar">
			<section class="wrapper-breadcrumb"><section id="breadcrumb" class="breadcrumb">
			<nav itemprop="breadcrumb">
				<a href="http://192.168.0.2">Kezdőlap</a>		
				<span class="delimiter"> > </span>		
				Akciós termékek		
			</nav>
			</section>
			</section>
	        		<div id="wpo-main-content" class="wpo-content">
			                <div class="woo-content-inner">
					<header class="header-title">
			        		<h1 class="page-title"></h1>
					</header>
						<div id="wpo-filter" class="clearfix">
						</div>
						<div class="products">
							<div class="products-layout has-col-3">
							<ul class="product-category clearfix"  style="list-style: outside none none; text-align: center; padding: 0px;">
							</ul>
<?php
	while ( $loop->have_posts() ) : $loop->the_post();
				wc_get_template_part( 'content', 'product' );
			endwhile;
}
echo "</div></div>"?>
<?php wp_reset_query(); 

 ?>
    </main><!-- .site-main -->
 
    <?php get_sidebar( 'content-bottom' ); ?>
 
</div><!-- .content-area -->
 
<?php get_sidebar(); ?>
<?php get_footer(); ?>
