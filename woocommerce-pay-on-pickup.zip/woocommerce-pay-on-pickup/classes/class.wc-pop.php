<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if( ! class_exists( 'WC_Gateway_Pay_on_pickup' ) ):

class WC_Gateway_Pay_on_pickup extends WC_Payment_Gateway {
    public function __construct() {
        $this->setup_properties();
	$this->init_form_fields();
	$this->init_settings();
	$this->enabled = $this->get_option( 'enabled' );
	$this->title = $this->get_option( 'title' );
	$this->description = $this->get_option( 'description' );
	$this->instructions = $this->get_option( 'instructions' );
	$this->enable_for_methods = $this->get_option( 'enable_for_methods', array() );
	$this->default_order_status = $this->get_option( 'default_order_status', apply_filters( 'wc_pop_default_order_status', 'on-hold') );
	$this->exclusive_for_local = $this->get_option( 'exclusive_for_local' );
	add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
	add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'thankyou_page' ) );
	add_action( 'woocommerce_email_before_order_table', array( $this, 'email_instructions' ), 10, 3 );
	if ( 'yes' === $this->enabled && 'yes' === $this->exclusive_for_local ) {
            add_filter( 'woocommerce_available_payment_gateways', array( $this, 'pop_only' ) );
	}
    }

    private function get_string_before_colon( $string ) {
	return trim( current( explode( ':', (string) $string ) ) );
    }
    private function only_local_pickups_selected() {
	$chosen_shipping_rates = WC()->session->get( 'chosen_shipping_methods' );
	unset( $chosen_shipping_rates["undefined"] );
        foreach( $chosen_shipping_rates as $chosen_shipping_rate )  {
            if ( strpos( $chosen_shipping_rate, 'local_pickup' ) === false ) {
		return false;
            }
	}
        return true;
    }

    public function pop_only( $gateways ) {
	if ( $this->only_local_pickups_selected() ) {
            if ( isset( $gateways['pop'] ) ) {
		return array( 'pop' => $gateways['pop'] );
            }
            else {
		return array();
            }
	}
        return $gateways;
    }

    protected function setup_properties() {
	$this->id = 'pop';
	$this->icon = apply_filters( 'woocommerce_pop_icon', '' );
	$this->method_title = __( 'Helyben fizetés', 'wc-pay-on-pickup' );
	$this->method_description = __( 'Készpénzzel vagy bankkártyával helyben történő fizetés', 'wc-pay-on-pickup' );
	$this->has_fields = false;
	}

    public function init_form_fields() {
	$shipping_methods = array();
	$order_statuses = array();
        if ( is_admin() ) {
            foreach ( WC()->shipping->load_shipping_methods() as $method ) {
		$shipping_methods[ $method->id ] = $method->get_method_title();
            }
            $statuses = function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : array();
            foreach ( $statuses as $status => $status_name ) {
		$order_statuses[ substr( $status, 3 ) ] = $status_name;
            }
	}
	$this->form_fields = array(
	'enabled' => array(
            'title' => __( 'Engedélyezés/Letiltás', 'woocommerce' ),
            'label' => __( 'Helyben fizetés engedélyezése', 'wc-pay-on-pickup' ),
            'type' => 'checkbox',
            'description' => '',
            'default' => 'no',
            ),
	'title' => array(
            'title' => __( 'Title', 'woocommerce' ),
            'type' => 'text',
            'description' => __( 'Készpénz vagy bankkártya', 'wc-pay-on-pickup' ),
            'default' => __( 'Helyben fizetés', 'wc-pay-on-pickup' ),
            'desc_tip' => true,
            ),
	'description' => array(
            'title' => __( 'Description', 'woocommerce' ),
            'type' => 'textarea',
            'description' => __( 'Üzletben átvételkor fizetés', 'wc-pay-on-pickup' ),
            'default' => __( 'Átvételkor fizetés', 'wc-pay-on-pickup' ),
            'desc_tip' => true,
            ),
	'instructions' => array(
            'title' => __( 'Instructions', 'woocommerce' ),
            'type' => 'textarea',
            'description' => __( 'Üzletben átvételkor fizetés', 'wc-pay-on-pickup' ),
            'default' => __( 'Átvételkor fizetés', 'wc-pay-on-pickup' ),
            'desc_tip' => true,
            ),
	'enable_for_methods' => array(
            'title' => __( 'Enable for shipping methods', 'woocommerce' ),
            'type' => 'multiselect',
            'class' => 'chosen_select',
            'css' => 'width: 450px;',
            'default' => '',
            'description' => __( 'Ha POP csak bizonyos esetekben elérhető, az itt beállítható. Nincsen beállítás esetén mindenhol elérhető.', 'wc-pay-on-pickup' ),
            'options' => $shipping_methods,
            'desc_tip'    => true,
            ),
	'default_order_status' => array(
            'title' => __( 'Default order status', 'wc-pay-on-pickup' ),
            'type' => 'select',
            'default' => apply_filters( 'wc_pop_default_order_status', 'on-hold' ),
            'options' => $order_statuses,
            ),
	'exclusive_for_local' => array(
            'title' => __( 'A többi fizetési mód letilása helyben átvétel esetén', 'wc-pay-on-pickup' ),
            'label' => __( 'Helyben átvétel esetén a többi fizetési mód le lesz tiltva', 'wc-pay-on-pickup' ),
            'type' => 'checkbox',
            'description' => '',
            'default' => 'no',
            ),
	);
    }

    public function is_available() {
	if ( 'yes' !== $this->enabled ) {
            return false;
	}
	if ( ! empty( $this->enable_for_methods ) && WC()->session && ! ( 'yes' === $this->exclusive_for_local && $this->only_local_pickups_selected() ) ) {
            $chosen_shipping_methods = array();
            if ( is_page( wc_get_page_id( 'checkout' ) ) && 0 < get_query_var( 'order-pay' ) ) {
                $order_id = absint( get_query_var( 'order-pay' ) );
		$order = wc_get_order( $order_id );
		$chosen_shipping_methods = array_unique( array_map( array( $this, 'get_string_before_colon' ), $order->get_shipping_methods() ) );
            } 
            elseif ( $chosen_shipping_methods_session = WC()->session->get( 'chosen_shipping_methods' ) ) {
		$chosen_shipping_methods = array_unique( array_map( array( $this, 'get_string_before_colon' ), $chosen_shipping_methods_session ) );
            }
            unset( $chosen_shipping_methods["undefined"] );
            if ( 0 < count( array_diff( $chosen_shipping_methods, $this->enable_for_methods ) ) ) {
                return false;
            }
	}
        return parent::is_available();
    }

    public function process_payment( $order_id ) {
        $order = wc_get_order( $order_id );
        $order->update_status( apply_filters( 'wc_pop_default_order_status', $this->default_order_status ) );
        if ( version_compare( WC_VERSION, '3.0', '<' ) ) {
            $order->reduce_order_stock();
	} 
        else {
            wc_reduce_stock_levels( $order_id );
	}
	WC()->cart->empty_cart();
	return array(
            'result' => 'success',
            'redirect' => $this->get_return_url( $order ),
            );
    }

    public function thankyou_page() {
	if ( $this->instructions ) {
            echo wpautop( wptexturize( $this->instructions ) );
	}
    }

    public function email_instructions( $order, $sent_to_admin, $plain_text = false ) {
	if ( $this->instructions && ! $sent_to_admin && $this->id === $order->get_payment_method() && $order->has_status( $this->default_order_status ) ) {
            echo wpautop( wptexturize( $this->instructions ) ) . PHP_EOL;
	}
    }
}
endif;
