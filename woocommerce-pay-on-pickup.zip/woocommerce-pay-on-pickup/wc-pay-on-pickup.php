<?php
/*
Plugin Name:       WooCommerce Pay On Pickup
Description:       "Pay On Pickup" option
Version:           1.0.0
Author:            Viktor Rajcsanyi
Author URI: http://promera.hu
Text Domain: wc-pay-on-pickup
Domain Path: /languages
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function wc_pop_i18n_init() {
    $pluginDir = dirname(plugin_basename(__FILE__));
    load_plugin_textdomain('wc-pay-on-pickup', false, $pluginDir . '/languages/');
}

add_action('plugins_loaded','wc_pop_i18n_init');

function wc_pop_init() {
	global $woocommerce;

	if ( !isset( $woocommerce ) ) {
		return;
	}

	require_once( 'classes/class.wc-pop.php' );
}
add_action( 'plugins_loaded', 'wc_pop_init' );


function wc_pop_register_gateway( $methods ) {
	$methods[] = 'WC_Gateway_Pay_on_pickup';
	return $methods;
}
add_filter( 'woocommerce_payment_gateways', 'wc_pop_register_gateway' );

function wc_pop_action_links( $links, $file ) {
	if ( $file == plugin_basename( __FILE__ ) ) {		
		array_unshift( $links, '<a href="' . network_admin_url( 'admin.php?page=wc-settings&tab=checkout&section=pop' ) . '" title="' . esc_attr__( 'Settings', 'woocommerce' ) . '">' . esc_html__( 'Settings', 'woocommerce' ) . '</a>' );
	}
	return $links;
}
add_filter( 'plugin_action_links', 'wc_pop_action_links', 10, 4 );
