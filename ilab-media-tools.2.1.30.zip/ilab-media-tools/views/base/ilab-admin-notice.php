<div class="{{$class}}" {{$identifier}} style="margin-top: 10px; margin-bottom: 10px;">
    {{__($message)}}
</div>