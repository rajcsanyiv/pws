<?php
if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class Orderpoints_Table extends WP_List_Table {

    public static function get_allcoupons( $per_page = 50, $page_number = 1 ) {
        global $wpdb;
	$sql="SELECT meta_id, post_title, meta_value FROM {$wpdb->prefix}posts
                LEFT JOIN {$wpdb->prefix}postmeta
		ON {$wpdb->prefix}postmeta.post_id = {$wpdb->prefix}posts.ID
                WHERE {$wpdb->prefix}postmeta.meta_key = 'agentcoupon'
                ORDER BY {$wpdb->prefix}posts.post_title";
        $result = $wpdb->get_results( $sql, 'ARRAY_A' );
	return $result;
    }
     
    public static function get_coupons( $per_page = 50, $page_number = 1 ,$filter) {
	global $wpdb;
	$sql2 ="SELECT meta_key, meta_id, post_title, meta_value FROM {$wpdb->prefix}posts
                LEFT JOIN {$wpdb->prefix}postmeta
		ON {$wpdb->prefix}postmeta.post_id = {$wpdb->prefix}posts.ID
                WHERE {$wpdb->prefix}postmeta.meta_key = 'agentcoupon' 
                AND {$wpdb->prefix}postmeta.post_id = {$wpdb->prefix}posts.ID
		AND {$wpdb->prefix}postmeta.meta_value=\"".$filter."\" 
                ORDER BY {$wpdb->prefix}posts.post_title";
        $result = $wpdb->get_results( $sql2, 'ARRAY_A' );
	return $result;
    }   

    public function __construct() {
	parent::__construct( array(
		'singular' => __( 'pont', 'orderpoints' ),     
		'plural'   => __( 'pontok', 'orderpoints' ),    
		'ajax'     => false,       
		) );
    }

    public function get_columns() {
        $columns = [
        	'post_title' => __( 'Kuponkód', 'orderpoints' ),
        	'meta_value' => __( 'Ügynök', 'orderpoints' ),
		'meta_id' => __( 'Szerkesztés / Törlés', 'orderpoints' )
	];
        return $columns;
    }
	
    protected function get_sortable_columns() {
	$sortable_columns = array(
	);
        return $sortable_columns;
    }

    function column_post_title( $item ) {
        $title = $item['post_title'];
        return $title;
    }

    function column_meta_value( $item ) {
	$user = get_user_by( 'ID', $item['meta_value']);
        $title = $user->display_name;
        return $title;
    }

    function column_meta_id( $item ) {
       	$title="<a href=\"?page=orderpoints&action=delcoupon&coupon=".$item['meta_id']."\">".__( 'Törlés', 'orderpoints' )."</a>";
        return $title;
    }

    protected function column_default( $item, $column_name ) {
	switch ( $column_name ) {
		case 'meta_id':
		case 'meta_value':
	        case 'post_title':
	        return $item[ $column_name ];
            default:
                return print_r( $item, true );
        }
    }

    function prepare_items() {
	global $wpdb; 
	$per_page = 25;
	$columns  = $this->get_columns();
	$hidden   = array();
	$sortable = $this->get_sortable_columns();
	$this->_column_headers = array( $columns, $hidden, $sortable );
        if ( 'edit' === $this->current_action() || 'view' === $this->current_action())
		$data = $this->get_coupons();
	else
		$data = $this->get_allcoupons();
		usort( $data, array( $this, 'usort_reorder' ) );
		$current_page = $this->get_pagenum();
		$total_items = count( $data );
		$data = array_slice( $data, ( ( $current_page - 1 ) * $per_page ), $per_page );
		$this->items = $data;
		$this->set_pagination_args( array(
			'total_items' => $total_items,                    
			'per_page'    => $per_page,  
			'total_pages' => ceil( $total_items / $per_page ), 
		) );
	}

    function prepare_filter($filter) {
	global $wpdb; 
	$per_page = 25;
	$columns  = $this->get_columns();
	$hidden   = array();
	$sortable = $this->get_sortable_columns();
	$this->_column_headers = array( $columns, $hidden, $sortable );
        if ( 'edit' === $this->current_action() || 'view' === $this->current_action())
		$data = $this->get_coupons(50,1,$filter);
	else
		$data = $this->get_coupons(50,1,$filter);
		usort( $data, array( $this, 'usort_reorder' ) );
		$current_page = $this->get_pagenum();
		$total_items = count( $data );
		$data = array_slice( $data, ( ( $current_page - 1 ) * $per_page ), $per_page );
		$this->items = $data;
		$this->set_pagination_args( array(
			'total_items' => $total_items,                    
			'per_page'    => $per_page,  
			'total_pages' => ceil( $total_items / $per_page ), 
		) );
	}
}

class Orderpointsfiltered_Table extends WP_List_Table {

    public static function get_allcoupons( $per_page = 50, $page_number = 1 ) {
        global $wpdb;
	$sql="SELECT meta_id, post_title, meta_value FROM {$wpdb->prefix}posts
                LEFT JOIN {$wpdb->prefix}postmeta
		ON {$wpdb->prefix}postmeta.post_id = {$wpdb->prefix}posts.ID
                WHERE {$wpdb->prefix}postmeta.meta_key = 'agentcoupon'
                ORDER BY {$wpdb->prefix}posts.post_title";
        $result = $wpdb->get_results( $sql, 'ARRAY_A' );
	return $result;
    }
     
    public static function get_coupons( $per_page = 50, $page_number = 1 ,$filter) {
	global $wpdb;
	$sql2 ="SELECT meta_key, meta_id, post_title, post_excerpt, meta_value FROM {$wpdb->prefix}posts
                LEFT JOIN {$wpdb->prefix}postmeta
		ON {$wpdb->prefix}postmeta.post_id = {$wpdb->prefix}posts.ID
                WHERE {$wpdb->prefix}postmeta.meta_key = 'agentcoupon' 
                AND {$wpdb->prefix}postmeta.post_id = {$wpdb->prefix}posts.ID
		AND {$wpdb->prefix}postmeta.meta_value=\"".$filter."\" 
                ORDER BY {$wpdb->prefix}posts.post_title";
        $result = $wpdb->get_results( $sql2, 'ARRAY_A' );
	return $result;
    }   

    public function __construct() {
	parent::__construct( array(
		'singular' => __( 'pont', 'orderpoints' ),     
		'plural'   => __( 'pontok', 'orderpoints' ),    
		'ajax'     => false,       
		) );
    }
	
    public function get_columns() {
        $columns = [
        	'post_title' => __( 'Kuponkód', 'orderpoints'),
        	'post_excerpt' => __( 'Leírás', 'orderpoints' )
	];
        return $columns;
    }
	
    protected function get_sortable_columns() {
	$sortable_columns = array(
	);
        return $sortable_columns;
    }

    function column_post_title( $item ) {
        $title = $item['post_title']."<a href=\"?page=orderpoints&action=showcouponorders&coupon=".$item['post_title']."\">".__( 'Részletek', 'orderpoints' )."</a>";
        return $title;
    }

    function column_meta_value( $item ) {
        $title = $item['post_excerpt'];
        return $title;
    }    

    protected function column_default( $item, $column_name ) {
	switch ( $column_name ) {
		case 'meta_id':
		case 'post_excerpt':
	        case 'post_title':
	        return $item[ $column_name ];
            default:
                return print_r( $item, true );
        }
    }

    function prepare_items() {
	global $wpdb; 
	$per_page = 25;
	$columns  = $this->get_columns();
	$hidden   = array();
	$sortable = $this->get_sortable_columns();
	$this->_column_headers = array( $columns, $hidden, $sortable );
        if ( 'edit' === $this->current_action() || 'view' === $this->current_action())
		$data = $this->get_coupons();
	else
		$data = $this->get_allcoupons();
		usort( $data, array( $this, 'usort_reorder' ) );
		$current_page = $this->get_pagenum();
		$total_items = count( $data );
		$data = array_slice( $data, ( ( $current_page - 1 ) * $per_page ), $per_page );
		$this->items = $data;
		$this->set_pagination_args( array(
			'total_items' => $total_items,                    
			'per_page'    => $per_page,  
			'total_pages' => ceil( $total_items / $per_page ), 
		) );
	}

    function prepare_filter($filter) {
	global $wpdb; 
	$per_page = 25;
	$columns  = $this->get_columns();
	$hidden   = array();
	$sortable = $this->get_sortable_columns();
	$this->_column_headers = array( $columns, $hidden, $sortable );
        if ( 'edit' === $this->current_action() || 'view' === $this->current_action())
		$data = $this->get_coupons(50,1,$filter);
	else
		$data = $this->get_coupons(50,1,$filter);
		usort( $data, array( $this, 'usort_reorder' ) );
		$current_page = $this->get_pagenum();
		$total_items = count( $data );
		$data = array_slice( $data, ( ( $current_page - 1 ) * $per_page ), $per_page );
		$this->items = $data;
		$this->set_pagination_args( array(
			'total_items' => $total_items,                    
			'per_page'    => $per_page,  
			'total_pages' => ceil( $total_items / $per_page ), 
		) );
	}
}


class Orderlist_Table extends WP_List_Table {
   
    public static function get_coupons( $per_page = 50, $page_number = 1 ,$filter) {
	global $wpdb;
	$sql2 ="SELECT * FROM {$wpdb->prefix}posts
		LEFT JOIN {$wpdb->prefix}woocommerce_order_items woi ON {$wpdb->prefix}posts.ID = woi.order_id
		WHERE order_item_type='coupon' AND order_item_name=\"".$filter."\" and post_status='wc-completed'";
        $result = $wpdb->get_results( $sql2, 'ARRAY_A' );
	return $result;
    }   

    public function __construct() {
	parent::__construct( array(
		'singular' => __( 'rendelés', 'orderpoints' ),     
		'plural'   => __( 'rendelések', 'orderpoints' ),    
		'ajax'     => false,       
		) );
    }
	
    public function get_columns() {
        $columns = [
        	'post_date' => __( 'Dátum', 'orderpoints' ),
        	'ID' => __( 'Rendelés Azonosító', 'orderpoints' ),
		'pont' => __('Pont', 'orderpoints')
	];
        return $columns;
    }
	
    protected function get_sortable_columns() {
	$sortable_columns = array(
	);
        return $sortable_columns;
    }

    function column_ID( $item ) {
        $title = $item['ID'];
        return $title;
    }

    function column_post_date( $item ) {
        $title = $item['post_date'];
        return $title;
    }

    function column_pont( $item ) {
        $title = "0";
	$order = wc_get_order( $item['ID'] ); 
	foreach ($order->get_items() as $item_id => $item_data) {
		$product = $item_data->get_product();
		$item_quantity = $item_data->get_quantity();
		$termekpont = get_post_meta( $product->get_id(), 'product_point_value', true );
		if( ! empty( $termekpont ) ) {
			$title=$title+$termekpont;
		}
	}
        return $title;
    }     

    protected function column_default( $item, $column_name ) {
	switch ( $column_name ) {
		case 'ID':
		case 'post_date':
	        return $item[ $column_name ];
            default:
                return print_r( $item, true );
        }
    }

    function prepare_items() {
	global $wpdb; 
	$per_page = 25;
	$columns  = $this->get_columns();
	$hidden   = array();
	$sortable = $this->get_sortable_columns();
	$this->_column_headers = array( $columns, $hidden, $sortable );
        if ( 'edit' === $this->current_action() || 'view' === $this->current_action())
		$data = $this->get_coupons();
	else
		$data = $this->get_allcoupons();
		usort( $data, array( $this, 'usort_reorder' ) );
		$current_page = $this->get_pagenum();
		$total_items = count( $data );
		$data = array_slice( $data, ( ( $current_page - 1 ) * $per_page ), $per_page );
		$this->items = $data;
		$this->set_pagination_args( array(
			'total_items' => $total_items,                    
			'per_page'    => $per_page,  
			'total_pages' => ceil( $total_items / $per_page ), 
		) );
	}

    function prepare_filter($filter) {
	global $wpdb; 
	$per_page = 25;
	$columns  = $this->get_columns();
	$hidden   = array();
	$sortable = $this->get_sortable_columns();
	$this->_column_headers = array( $columns, $hidden, $sortable );
        if ( 'edit' === $this->current_action() || 'view' === $this->current_action())
		$data = $this->get_coupons(50,1,$filter);
	else
		$data = $this->get_coupons(50,1,$filter);
		usort( $data, array( $this, 'usort_reorder' ) );
		$current_page = $this->get_pagenum();
		$total_items = count( $data );
		$data = array_slice( $data, ( ( $current_page - 1 ) * $per_page ), $per_page );
		$this->items = $data;
		$this->set_pagination_args( array(
			'total_items' => $total_items,                    
			'per_page'    => $per_page,  
			'total_pages' => ceil( $total_items / $per_page ), 
		) );
	}

}

