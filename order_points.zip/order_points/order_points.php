<?php
/*
  Plugin Name: WooCommerce Orderpoints
  Description: Plugin for product points, sponsors and agents.
  Version: 1.0
  Author: Viktor Rajcsanyi
 */

if (!defined('ABSPATH'))
    exit;

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

if (!class_exists('Orderpoints_Table')) {
    require_once( plugin_dir_path(__FILE__) . 'orderpoints-table.php' );
}

$orderstatuses = array();

add_action('plugins_loaded', 'orderpoints_init', 10, 1);
add_action('admin_menu', 'orderpoints_create_page');

if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'delcoupon') {
    $sql = "DELETE from {$wpdb->prefix}postmeta
		WHERE {$wpdb->prefix}postmeta.meta_id = " . $_REQUEST['coupon'];
    $result = $wpdb->get_results($sql, 'ARRAY_A');
}

function orderpoints_create_page() {
    add_menu_page('Ügynök kuponok', 'Ügynök kuponok', 'list_users', 'orderpoints', 'orderpoints_menu', 'dashicons-admin-generic', 51);
    add_submenu_page('orderpoints', 'Összes kupon', 'Összes kupon', 'list_users', 'orderpoints', 'orderpoints_menu');
    add_submenu_page('orderpoints', 'Hozzáadás ügynökhöz, felhasználás lista', 'Hozzáadás ügynökhöz, felhasználás lista', 'list_users', 'new_coupon', 'new_coupon');
}

function orderpoints_init() {
    
}

function orderpoints_menu() {

    echo "<h1 class=\"wp-heading-inline\">Ügynök kuponok</h1><br/>Itt lehet az ügynökökhöz kuponokat rendelni,<br/>illetve a hozzárendelt kuponokat ellenőrizni<br/>és a kuponokat felhasznált rendelések pontértékét lekérdezni.";
    wp_reset_query();

    if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'showcouponorders') {
        $orderpoints_table = new Orderlist_Table();
        $orderpoints_table->prepare_filter($_REQUEST['coupon']);
        $orderpoints_table->setSelected($_REQUEST['coupon']);
    } else {
        $orderpoints_table = new Orderpoints_Table();
        $orderpoints_table->prepare_items();
    }

    echo "<form id=\"orderpoints-table\" method=\"get\">";
    if (isset($_REQUEST['action']) && $_REQUEST['action'] == 'showcouponorders') {
        $orderpoints_table->display();
    } else {
        $orderpoints_table->display();
    }

    echo "</form>";
}

function new_coupon() {
    ?>
    <h1 class="wp-heading-inline">Új kupon hozzáadás</h1><br/>
    <div id="smstemplate_metabox" class="postbox " >
        <h2 class='hndle'><span>Kuponok</span></h2>
        <div class="inside">
            <table class="form-table"><tbody>
                    <tr>
                        <td>
                            <select name="orderpoints_select" id="orderpoints_select" title="Ügynök">
                                <optgroup label="">
                                    <option value=""  selected='selected'>-</option>
                                </optgroup>
                                <optgroup label="Ügynökök ">
    <?php
    $args = array(
        'role' => 'agent',
        'orderby' => 'user_nicename',
        'order' => 'ASC'
    );
    $users = get_users($args);
    $orderstatuses = array_keys($users);
    $holtart = 0;
    foreach ($users as $value) {
        echo "<option value=\"" . $value->ID . "\" >" . $value->display_name . "</option>";
        $holtart++;
    }
    ?>
                            </select>
                            <div id="event-desc-area">
                                <h2>Az ügynökhöz kapcsolt kuponok</h2>
                                <div class="coupondiv" id="coupondiv">

                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>            
                            <select name="orderpoints_coupon" id="orderpoints_coupon" title="Kupon">
                                <optgroup label="">
                                    <option value=""  selected='selected'>-</option>
                                </optgroup>
                                <optgroup label="Kuponok">
    <?php
    $args = array(
        'posts_per_page' => -1,
        'orderby' => 'title',
        'order' => 'asc',
        'post_type' => 'shop_coupon',
        'post_status' => 'publish',
    );
    $coupons = get_posts($args);
    $orderstatuses = array_keys($coupons);
    $holtart = 0;
    foreach ($coupons as $value) {
        echo "<option value=\"" . $value->ID . "\" >" . $value->post_name . "</option>";
        $holtart++;
    }
    ?>
                            </select>                   
                            <button class="button button-primary button-large" type="button" name="addnewcouponbutton" id="addnewcouponbutton">
                                <i class="dashicons dashicons-plus">
                                </i>
                                Kupon hozzárendelés
                            </button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    <?php
}

add_action('admin_footer', 'orderpoints_ajax_script');

function orderpoints_ajax_script() {
    ?>
        <script type="text/javascript" >
            //var jQueryObj = $;
            jQuery(document).ready(function ($) {
                jQuery("#orderpoints_select").on('change', function () {
                    var agentname = jQuery('#orderpoints_select').val();
                    jQuery.ajax({
                        method: "POST",
                        url: ajaxurl,
                        data: {'action': 'orderpoints_approal_action', 'agent': agentname}
                    })
                            .done(function (data) {
                                console.log('Successful AJAX Call! /// Return Data: ' + data);
                                document.getElementById("coupondiv").innerHTML = data;
                            })
                            .fail(function (data) {
                                console.log('Failed AJAX Call :( /// Return Data: ' + data);
                            });
                });
                jQuery("#addnewcouponbutton").click(function () {
                    var agentname = jQuery('#orderpoints_select').val();
                    var coupon = jQuery('#orderpoints_coupon').val();
                    jQuery.ajax({
                        method: "POST",
                        url: ajaxurl,
                        data: {'action': 'orderpoints_approal_action', 'agent': agentname, 'coupon': coupon}
                    })
                            .done(function (data) {
                                console.log('Successful AJAX Call! /// Return Data: ' + data);
                                document.getElementById("coupondiv").innerHTML = data;

                            })
                            .fail(function (data) {
                                console.log('Failed AJAX Call :( /// Return Data: ' + data);
                            });
                });

            });



        </script>
    <?php
}

function orderpoints_ajax_handler() {
    global $wpdb;
    if (isset($_POST['agent'])) {
        $agent = $_POST['agent'];
        if (isset($_POST['coupon'])) {
            $stored = get_post_meta($_POST['coupon'], 'agentcoupon');
            if (empty($stored))
                add_post_meta($_POST['coupon'], 'agentcoupon', $_POST['agent']);
            else
                echo "Már hozzá van rendelve egy ügynökhöz!";
        }
        $orderpoints_table = new Orderpointsfiltered_Table();
        $orderpoints_table->prepare_filter($agent);
        $orderpoints_table->setSelected($agent);
        $data = $orderpoints_table->display();
    }
    wp_die();
}

add_action('wp_ajax_orderpoints_approal_action', 'orderpoints_ajax_handler');
if (!class_exists('WC_Settings_Orderpoints')) :
    if (!class_exists('WC_Settings_Page')) {
        require_once( substr(plugin_dir_path(__FILE__), 0, strlen(plugin_dir_path(__FILE__)) - 14) . '/woocommerce/includes/admin/settings/class-wc-settings-page.php' );
    }

    function orderpoints_add_settings() {

        class WC_Settings_Orderpoints extends WC_Settings_Page {

            public function __construct() {
                $this->id = 'orderpoints';
                $this->label = __('Termék Pontok', 'orderpoints');
                add_filter('woocommerce_settings_tabs_array', array($this, 'add_settings_page'), 20);
                add_action('woocommerce_settings_' . $this->id, array($this, 'output'));
                add_action('woocommerce_settings_save_' . $this->id, array($this, 'save'));
                add_action('woocommerce_sections_' . $this->id, array($this, 'output_sections'));
            }

            public function get_sections() {
                $sections = array(
                    'setup' => __('Section 1', 'orderpoints')
                );
                return apply_filters('woocommerce_get_sections_' . $this->id, $sections);
            }

            public function get_settings($current_section = '') {
                $settings = apply_filters('orderpoints_section1_settings', array(
                    array(
                        'type' => 'checkbox',
                        'id' => 'orderpoints_showcustomer',
                        'name' => __('Pont érték látható a vásárló számára is', 'orderpoints'),
                        'desc' => __('Ne csak a munkatársak láthassák a pontokat, hanem a vásárlók is ', 'orderpoints'),
                        'default' => 'no',
                    ), array(
                        'type' => 'checkbox',
                        'id' => 'orderpoints_sponsor',
                        'name' => __('Ajánló személy rögzítése', 'orderpoints'),
                        'desc' => __('Az ajánló megadása regisztráció vagy első rendelés alkalmával', 'orderpoints'),
                        'default' => 'no',
                    ),
                        )
                );
                return apply_filters('woocommerce_get_settings_' . $this->id, $settings, $current_section);
            }

            public function output() {
                global $current_section;
                $settings = $this->get_settings($current_section);
                WC_Admin_Settings::output_fields($settings);
            }

            public function save() {
                global $current_section;
                $settings = $this->get_settings($current_section);
                WC_Admin_Settings::save_fields($settings);
            }

        }

        return new WC_Settings_Orderpoints();
    }

    add_filter('woocommerce_get_settings_pages', 'orderpoints_add_settings', 15);
endif;

function create_point_field() {
    $args = array(
        'id' => 'product_point_value',
        'label' => __('Pont', 'prodpoint'),
        'class' => 'prodpoint',
        'desc_tip' => true,
        'description' => __('A termékért adott pontok', 'prodpoint'),
    );
    woocommerce_wp_text_input($args);
}

add_action('woocommerce_product_options_general_product_data', 'create_point_field');

function save_point_field($post_id) {
    $product = wc_get_product($post_id);
    $title = isset($_POST['product_point_value']) ? $_POST['product_point_value'] : '';
    $product->update_meta_data('product_point_value', sanitize_text_field($title));
    $product->save();
}

add_action('woocommerce_process_product_meta', 'save_point_field');

function display_point_field() {
    global $post;
    $product = wc_get_product($post->ID);
    $title = $product->get_meta('product_point_value');
    if ($title) {
        printf(
                '<div class="point-field-wrapper"><label for="point-field">Pont érték: %s</label></div>', esc_html($title)
        );
    }
}

function send_point_field() {
    global $post;
    $product = wc_get_product($post->ID);
    $title = $product->get_meta('product_point_value');
    if ($title) {
        printf(
                '<div class="point-field-wrapper"><input type="hidden" id="point-field" name="point-field" value="(pont érték: %s)"></div>', esc_html($title)
        );
    }
}

//ha ki kell írni a vásárlónak
if (get_option('orderpoints_showcustomer') == "yes") {
    add_action('woocommerce_before_add_to_cart_form', 'display_point_field');
    add_action('woocommerce_before_add_to_cart_button', 'send_point_field');
//ide kell, hogy a submitba is menjen woocommerce_before_add_to_cart_button 
}

function validate_point_field($passed, $product_id, $quantity) {
    if (empty($_POST['point-field'])) {
        $passed = false;
        wc_add_notice(__('Kérem adja meg a pont értéket!', 'prodpoint'), 'error');
    }
    return $passed;
}

//adott érték, nem kell megadni add_filter( 'woocommerce_add_to_cart_validation', 'validate_point_field', 10, 3 );

function add_point_item_data($cart_item_data, $product_id, $variation_id, $quantity) {
    if (!empty($_POST['point-field'])) {
        $cart_item_data['point_field'] = $_POST['point-field'];
    }
    return $cart_item_data;
}

add_filter('woocommerce_add_cart_item_data', 'add_point_item_data', 10, 4);

add_filter('woocommerce_cart_item_name', 'cart_item_name', 10, 3);

function cart_item_name($name, $cart_item, $cart_item_key) {
    if (isset($cart_item['point_field'])) {
        $name .= sprintf(
                '<p>%s</p>', esc_html($cart_item['point_field'])
        );
    }
    return $name;
}

// ha kell a kosárba 
add_filter('woocommerce_cart_item_name', 'cart_item_name', 10, 3);

function add_custom_data_to_order($item, $cart_item_key, $values, $order) {
    foreach ($item as $cart_item_key => $values) {
        if (isset($values['point_field'])) {
            $item->add_meta_data(__('Pont', 'prodpoint'), $values['point_field'], true);
        }
    }
}

//ha kell a rendelésbe 
add_action('woocommerce_checkout_create_order_line_item', 'add_custom_data_to_order', 10, 4);

add_role('agent', __(
                'Ügynök'), array(
    'read' => true, // Allows a user to read
    'create_posts' => true, // Allows user to create new posts
    'edit_posts' => true, // Allows user to edit their own posts
        )
);

function call_order_status_completed($order_id) {
    error_log("fut", 0);
    $pluszpont = 0;
    $order = wc_get_order($order_id);
    foreach ($order->get_items() as $item_id => $item_data) {
        $product = $item_data->get_product();
        $item_quantity = $item_data->get_quantity();
        $termekpont = get_post_meta($product->get_id(), 'product_point_value', true);
        if (!empty($termekpont)) {
            $pluszpont = $pluszpont + $termekpont;
        }
    }
    error_log($pluszpont, 0);
    //kupon van, a kupont adó ügynök kap pontot	
    foreach ($order->get_used_coupons() as $coupon) {
        error_log("vankupon", 0);
        error_log($coupon, 0);
        $page = get_page_by_title($coupon, OBJECT, 'shop_coupon');
        error_log($page->ID, 0);
        $agentid = get_post_meta($page->ID, 'agentcoupon', true);
        error_log($coupon_ob->ID);
        $order_points = intval(get_user_meta($agentid, 'order_points', true));
        $order_points += $pluszpont;
        update_user_meta($agentid, 'order_points', $order_points);
        error_log($agentid, 0);
    }
    //pontgyűjtögetős rendszer, a vásárló kap pontot
    if (get_option('orderpoints_showcustomer') == "yes") {
        error_log("pontgyujtes", 0);
        $user = $order->get_user_id();
        $order_points = intval(get_user_meta($user, 'order_points', true));

        $order_points += $pluszpont + 1;
        update_user_meta($user, 'order_points', $order_points);
        error_log($order_points, 0);
        error_log($user, 0);
    }
    //ajánló rendszer van, az ajánló kap pontot
    if (get_option('orderpoints_sponsor') == "yes") {
        error_log("ajanlo", 0);
        $user = $order->get_user_id();
        $account_sponsor = get_user_meta($user, 'account_sponsor', true);
        $sponsors = get_users(array('meta_key' => 'account_code', 'meta_value' => $account_sponsor));
        if (!empty($sponsors)) {
            $sponsor = $sponsors[0];
            $order_points = intval(get_user_meta($sponsor->ID, 'order_points', true));
            $order_points += $pluszpont + 2;
            update_user_meta($sponsor->ID, 'order_points', $order_points);
            error_log($sponsor->ID, 0);
        }
    }
};

add_action('woocommerce_order_status_completed', 'call_order_status_completed', 10, 1);
add_action('register_form', 'crf_registration_form');

function crf_registration_form() {

    if (!empty($_POST['account_sponsor']))
        $account_sponsor = $_POST['account_sponsor'];
    else
        $account_sponsor = "";
    if (!empty($_POST['account_code']))
        $account_sponsor = $_POST['account_code'];
    else
        $account_sponsor = "";

    if (get_option('orderpoints_sponsor') == "yes") {
        ?>
            <p>
                <label for="account_sponsor"><?php esc_html_e('Ajánló kód', 'crf') ?><br/>
                    <input type="text"
                           id="account_sponsor"
                           name="account_sponsor"
                           value="<?php echo esc_attr($account_sponsor); ?>"
                           class="input"
                           />
                </label>
            </p>
        <?php
        }
    }

    add_filter('registration_errors', 'crf_registration_errors', 10, 3);

    function crf_registration_errors($errors, $sanitized_user_login, $user_email) {
        if (get_option('orderpoints_sponsor') == "yes") {
            if (empty($_POST['account_sponsor'])) {
                $errors->add('account_sponsor_error', __('<strong>HIBA</strong>: Kérem adja meg az Ajánló kódját.', 'crf'));
            }
        }
        return $errors;
    }

    add_action('user_register', 'crf_user_register');

    function crf_user_register($user_id) {
        if (!empty($_POST['account_sponsor'])) {
            update_user_meta($user_id, 'account_sponsor', $_POST['account_sponsor']);
        }
        if (!empty($_POST['account_code'])) {
            update_user_meta($user_id, 'account_code', $_POST['account_code']);
        }
    }

    /**
     * Backend reg
     */
    add_action('user_new_form', 'crf_admin_registration_form');

    function crf_admin_registration_form($operation) {
        if ('add-new-user' !== $operation) {
            return;
        }
        if (!empty($_POST['account_sponsor']))
            $account_sponsor = $_POST['account_sponsor'];
        else
            $account_sponsor = "";
        if (!empty($_POST['account_code']))
            $account_code = $_POST['account_code'];
        else
            $account_code = "";
        ?>
        <h3><?php esc_html_e('Ajánló és ügynök', 'crf'); ?></h3>

        <table class="form-table">
            <?php if (get_option('orderpoints_sponsor') == "yes") { ?>
                <tr>
                    <th><label for="account_sponsor"><?php esc_html_e('Ajánló kód', 'crf'); ?></label> <span class="description"><?php esc_html_e('(kötelező)', 'crf'); ?></span></th>
                    <td>
                        <input type="text"
                               id="account_sponsor"
                               name="account_sponsor"
                               value="<?php echo esc_attr($account_sponsor); ?>"
                               class="input-text"
                               />
                    </td>
                </tr>
        <?php
        $adminvagyok = false;
        if (current_user_can('manage_options')) {
            $adminvagyok = true;
        }
        $agentvagyok = false;
        $user = wp_get_current_user();
        $roles = (array) $user->roles;
        $role = $roles[0];
        if ($role == "agent") {
            $agentvagyok = true;
        }
        if ($agentvagyok || $adminvagyok) {
            ?>
                    <tr>
                        <th><label for="account_code"><?php esc_html_e('Saját kód', 'crf'); ?></label> <span class="description"></span></th>
                        <td>
                            <input type="text"
                                   id="account_code"
                                   name="account_code"
                                   value="<?php echo esc_attr($account_code); ?>"
                                   class="input-text"
                                   />
                        </td>
                    </tr>

            <?php }
        } ?>
        </table>
        <?php
    }

    add_action('user_profile_update_errors', 'crf_user_profile_update_errors', 10, 3);

    function crf_user_profile_update_errors($errors, $update, $user) {
        if (get_option('orderpoints_sponsor') == "yes") {
            if (empty($_POST['account_sponsor'])) {
                $errors->add('account_sponsor', __('<strong>HIBA</strong>: Kérem adja meg az Ajánló kódját.', 'crf'));
            }
        }
    }

    add_action('edit_user_created_user', 'crf_user_register');


    /**
     * Backend
     */
    add_action('show_user_profile', 'crf_show_extra_profile_fields');
    add_action('edit_user_profile', 'crf_show_extra_profile_fields');

    function crf_show_extra_profile_fields($user) {
        $adminvagyok = false;
        if (current_user_can('manage_options')) {
            $adminvagyok = true;
        }
        $account_sponsor = get_the_author_meta('account_sponsor', $user->ID);
        $account_code = get_the_author_meta('account_code', $user->ID);
        $order_points = get_the_author_meta('order_points', $user->ID);
        ?>
        <h3><?php esc_html_e('Ajánló és ügynök', 'crf'); ?></h3>

        <table class="form-table">
    <?php if (get_option('orderpoints_sponsor') == "yes") { ?>
                <tr>
                    <th><label for="account_sponsor"><?php esc_html_e('Ajánló kód', 'crf'); ?></label></th>
                    <td>
                        <input type="text"
                               id="account_sponsor"
                               name="account_sponsor"
                               value="<?php echo esc_attr($account_sponsor); ?>"
                               class="regular-text"
                               />
                    </td>
                </tr>
                <tr>
                    <th><label for="account_code"><?php esc_html_e('Saját kód', 'crf'); ?></label></th>
                    <td>
                        <input type="text"
                               id="account_code"
                               name="account_code"
                               value="<?php echo esc_attr($account_code); ?>"
                               class="regular-text"
                               />
                    </td>
                </tr>
            <?php } ?>

        <?php if (get_option('orderpoints_showcustomer') == "yes") { ?>
                <tr>
                    <th><label for="order_points"><?php esc_html_e('Pontjaim', 'crf'); ?></label></th>
                    <td>
                        <input type="text"
                               id="order_points"
                               name="order_points"
                               value="<?php echo esc_attr($order_points); ?>"
                               class="regular-text"
            <?php if (!$adminvagyok) echo "disabled" ?>
                               />
                    </td>
                </tr>
        <?php } ?>
        </table>
        <?php
    }

    add_action('personal_options_update', 'crf_update_profile_fields');
    add_action('edit_user_profile_update', 'crf_update_profile_fields');

    function crf_update_profile_fields($user_id) {
        $adminvagyok = false;
        if (current_user_can('manage_options')) {
            $adminvagyok = true;
        }
        if (!current_user_can('edit_user', $user_id)) {
            return false;
        }

        if (!empty($_POST['account_sponsor'])) {
            update_user_meta($user_id, 'account_sponsor', $_POST['account_sponsor']);
        }
        if (!empty($_POST['account_code'])) {
            update_user_meta($user_id, 'account_code', $_POST['account_code']);
        }
        if (!empty($_POST['order_points']) && $adminvagyok) {
            update_user_meta($user_id, 'order_points', intval($_POST['order_points']));
        }
    }

    if (get_option('orderpoints_sponsor') == "yes") {

        function wooc_extra_register_fields() {
            echo "<p class=\"form-row form-row-wide\"><label for=\"account_sponsor\">";
            _e('Ajánló', 'promera');
            echo "</label><input type=\"text\" class=\"input-text\" name=\"account_sponsor\" id=\"account_sponsor\"";
            echo "/></p>";
        }

        add_action('woocommerce_register_form_start', 'wooc_extra_register_fields');

        function wooc_validate_extra_register_fields($username, $email, $validation_errors) {
            if (isset($_POST['account_sponsor']) && empty($_POST['account_sponsor'])) {
                $validation_errors->add('sponsor_error', __('Kérem, adja meg az ajánló kódját!', 'promera'));
            }
            return $validation_errors;
        }

        add_action('woocommerce_register_post', 'wooc_validate_extra_register_fields', 10, 3);

        function wooc_save_extra_register_fields($customer_id) {
            if (isset($_POST['account_sponsor'])) {
                update_user_meta($customer_id, 'account_sponsor', sanitize_text_field($_POST['account_sponsor']));
            }
        }

        add_action('woocommerce_created_customer', 'wooc_save_extra_register_fields');
        add_action('woocommerce_after_order_notes', 'custom_checkout_field');

        function custom_checkout_field($checkout) {
            echo '<div id="sponsor_checkout_field"><h2>' . __('Ajánló') . '</h2>';
            woocommerce_form_field('account_sponsor', array(
                'required' => true,
                'type' => 'text',
                'class' => array(
                    'my-field-class form-row-wide'
                ),
                'label' => __('Ajánló'),
                'placeholder' => __('Az ajánló kódja'),
                    ), $checkout->get_value('account_sponsor')
            );
            echo '</div>';
        }

        add_action('woocommerce_checkout_process', 'sponsor_checkout_field_process');

        function sponsor_checkout_field_process() {
            if (!$_POST['account_sponsor'])
                wc_add_notice(__('Kérem, adja meg az ajánló kódját!'), 'error');
        }

        add_action('woocommerce_checkout_update_order_meta', 'sponsor_checkout_field_update_order_meta');

        function sponsor_checkout_field_update_order_meta($order_id) {
            if (!empty($_POST['account_sponsor'])) {
                update_post_meta($order_id, 'account_sponsor', sanitize_text_field($_POST['account_sponsor']));
                $order = wc_get_order($order_id);
                $user_id = $order->get_user_id();
                update_user_meta($user_id, 'account_sponsor', $_POST['account_sponsor']);
            }
        }
    }
