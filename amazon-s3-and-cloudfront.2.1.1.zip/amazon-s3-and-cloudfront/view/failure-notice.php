<ol class="as3cf-notice-toggle-list">
	<?php foreach ( $errors as $file => $value ) : ?>
		<li><?php echo $file; ?></li>
	<?php endforeach; ?>
</ol>