<?php
/*
Plugin Name: WooCommerce SMS template
Description: Plugin for SMS templates.
Version: 1.0
Author: Viktor Rajcsanyi
Author URI:  http://promera.hu
Text Domain: sms_template
Domain Path: /languages
*/

if ( ! defined( 'ABSPATH' ) ) exit; 

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

if ( ! class_exists( 'Smstemplate_Table' ) ) {
//	require_once( ABSPATH . 'wp-content/plugins/sms_template/sms-template-table.php' );
	require_once( plugin_dir_path(__FILE__) . '/sms-template-table.php' );
}

if ( ! class_exists( 'SmstemplateLog_Table' ) ) {
//	require_once( ABSPATH . 'wp-content/plugins/sms_template/smstemplatelog-table.php' );
	require_once( plugin_dir_path(__FILE__) . '/smstemplatelog-table.php' );
}

$orderstatuses = array();

add_action( 'plugins_loaded', 'smstemplate_init', 10, 1 );
add_action( 'admin_menu', 'smstemplate_create_page' );

if(isset($_REQUEST['action']) && $_REQUEST['action']=='delsmstemplate'){
	$sql="DELETE from {$wpdb->prefix}postmeta
		WHERE {$wpdb->prefix}postmeta.meta_id = ".$_REQUEST['template'] ;
        $result = $wpdb->get_results( $sql, 'ARRAY_A' );
}

function smstemplate_create_page() {
	add_menu_page( __('SMS template', 'sms_template'), __('SMS template', 'sms_template'), 'manage_options', 'smstemplate', 'sms_template_menu', 'dashicons-admin-generic', 51 );
	add_submenu_page( 'smstemplate', __('Összes template', 'sms_template'), __('Összes template', 'sms_template'), 'manage_options', 'smstemplate', 'sms_template_menu' );
	add_submenu_page( 'smstemplate', __('Új hozzáadása', 'sms_template'), __('Új hozzáadása', 'sms_template'), 'manage_options', 'new_template', 'new_template' );
	add_submenu_page( 'smstemplate', __('Napló', 'sms_template'), __('Napló', 'sms_template'), 'manage_options', 'smstemplate_log', 'smstemplate_log' );
}

function smstemplate_init(){
	load_plugin_textdomain( 'sms_template', false, dirname(plugin_basename(__FILE__)).'/languages/' );
	global $wpdb;
	$post_id = -1;
	$author_id = 1;
	$statuses=wc_get_order_statuses();
	$orderstatuses=array_keys($statuses);
	$holtart=0;
	foreach($statuses as $value){
		if( null == get_page_by_title( $value, OBJECT, 'sms_template' ) ) {
			$post_id = wp_insert_post(
			array(
				'comment_status'	=>	'closed',
				'ping_status'		=>	'closed',
				'post_author'		=>	$author_id,
				'post_name'		=>	$orderstatuses[$holtart],
				'post_title'		=>	$value,
				'post_status'		=>	'publish',
				'post_type'		=>	'sms_template'
			)
		);
		} else {
		    $post_id = -2;
		}
		$holtart++;
	}
	$statuses=wc_get_order_statuses();
	$statuses2=wc_get_order_statuses();
	$orderstatuses=array_keys($statuses);
	$holtart=0;
	$holtart2=0;
	foreach($statuses as $value){
		$postid1 = $wpdb->get_var( "SELECT ID FROM $wpdb->posts WHERE post_title = '".$value."'" );
		$name1 = substr($wpdb->get_var( "SELECT post_name FROM $wpdb->posts WHERE ID = '".$postid1."'" ),3);
		foreach($statuses2 as $value2){
			if($value!=$value2){
				$postid2 = $wpdb->get_var( "SELECT ID FROM $wpdb->posts WHERE post_title = '".$value2."'" );
				$name2 = substr($wpdb->get_var( "SELECT post_name FROM $wpdb->posts WHERE ID = '".$postid2."'" ),3);
				$postID2=get_page_by_title( $value2, OBJECT, 'sms_template' );
				$title2=get_the_title($postID2);
				$event="woocommerce_order_status_".$name1."_to_".$name2;
				add_action( $event, 'sms_kuldes', 10, 1 );
				$holtart2++;
			}
		}
		$holtart++;
	}
}

function smstemplate_log(){
?>
	<h1 class="wp-heading-inline"><?php _e('Elküldött SMS-ek napló','sms_tempate');?></h1>
<?php
	wp_reset_query();
	$smstemplate_log = new SmstemplateLog_Table();
	$smstemplate_log->prepare_items();
?>
	<form id="smstemplatelog-table" method="get">
	<input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
<?php 
	$smstemplate_log->display() 
?>
	</form>
<?php
}

function sms_template_menu(){
?>
	<h1 class="wp-heading-inline"><?php _e('SMS template kezelés','sms_template')?></h1><br/>
	<?php _e('Itt lehet az SMS küldésekhez használt sablonokat törölni,<br/>
	illetve SMS küldő eseményekhez felvenni új sablonokat.<br/>','sms_template');?>
<?php
	wp_reset_query();
	$smstemplate_table = new Smstemplate_Table();
	$smstemplate_table->prepare_items();
?>
	<form id="smstemplate-table" method="get">
<?php $smstemplate_table->display() ?>
	</form>
<p id="editsmsarea" name="editsmsarea"></p>
<?php
}

function new_template(){
?>
	<h1 class="wp-heading-inline"><?php _e('Új SMS template hozzáadás','sms_template');?></h1><br/>
	<div id="smstemplate_metabox" class="postbox " >
	<h2 class='hndle'><span><?php _e('Esemény','sms_template');?></span></h2>
	<div class="inside">
        <table class="form-table"><tbody>
            <tr>
                <td>
                    <select name="smstemplate_select" id="smstemplate_select" title="<?php _e('Esemény','sms_template');?>">
                        <optgroup label="">
                            <option value=""  selected='selected'>-</option>

        </optgroup><optgroup label="<?php _e('Rendelések','sms_template');?> ">
<?php
	$statuses=wc_get_order_statuses();
	$orderstatuses=array_keys($statuses);
	$holtart=0;
	foreach($statuses as $value){
		echo "<option value=\"".$orderstatuses[$holtart]."\" >".$value."</option>";
		$holtart++;
	}
?>
                    </select>
                    <div id="event-desc-area">
                        <h2><?php _e('Eseményhez kapcsolódó SMS-ek','sms_template');?></h2>
                        <div class="temp" id="temp">

                        </div>
                    </div>
                </td>
            </tr>
	    <tr><td><label id="smsnettext_label" for="smsnewtext"><?php _e('Az új üzenet szövege','sms_template');?></label>
		<input id="smsnewtext" class="wide-form-control" name="smsnewtext" type="text">
		<button class="button button-primary button-large" type="button" name="addnewsmsbutton" id="addnewsmsbutton">
		<i class="dashicons dashicons-plus">
		</i>
		<?php _e('Új SMS','sms_template');?>
		</button>
		</td>
	    </tr>
	</tbody>
        </table>
	</div>
<?php
}

function sms_kuldes($order_id) {
	$order = new WC_Order( $order_id );
	$phone = '+36' . $order->get_billing_phone();
	$status = $order->get_status();
	$name = $order->billing_first_name.' '.$order->billing_last_name;
	$ordernum = $order_id;
	global $wpdb;
	$sql2 ="SELECT meta_id, post_title, meta_value FROM {$wpdb->prefix}posts
                LEFT JOIN {$wpdb->prefix}postmeta
		ON {$wpdb->prefix}postmeta.post_id = {$wpdb->prefix}posts.ID
                WHERE {$wpdb->prefix}postmeta.meta_key = 'smstext' 
                AND {$wpdb->prefix}postmeta.post_id = {$wpdb->prefix}posts.ID
		AND {$wpdb->prefix}posts.post_name=\"wc-".$status."\" 
                ORDER BY {$wpdb->prefix}posts.post_title";
        $result = $wpdb->get_results( $sql2, 'ARRAY_A' );
	foreach( $wpdb->get_results($sql2) as $key => $row) {
		$message = $row->meta_value;
		$message = str_replace("|nev|", $name , $message);
		$message = str_replace("|megrendeles|", $ordernum , $message);
		$msg = __(' telefonszámra SMS lett küldve: ','sms_template');
		add_sms_log($phone.$msg.$message);
		if(get_option('sms_template_checkbox')=="yes"){                    
                        if(get_option('sms_gateway')=="Bitnet"){
               			$response = curl_exec(curl_init(SMS_Sender::instance()->get_sms_url($phone, $message)));
                        }
                        if(get_option('sms_gateway')=="Textbelt"){
                                $ch = curl_init('https://textbelt.com/text');
                                $data = array(
                                'phone' => $phone,
                                'message' => $message,
                                'key' => 'textbelt',
                                );

                                curl_setopt($ch, CURLOPT_POST, 1);
                                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                $response = curl_exec($ch);
                                curl_close($ch);
                        }          
		}
	}
}

add_action( 'admin_footer', 'smstemplate_ajax_script' );

function smstemplate_ajax_script() {
?>
	<script type="text/javascript" >
        //var jQueryObj = $;
	jQuery(document).ready(function($) {
	jQuery("#smstemplate_select").on('change', function() {
			var templatename = jQuery( '#smstemplate_select' ).val();
			jQuery.ajax({
        		method: "POST",
		        url: ajaxurl,
		        data: { 'action': 'smstemplate_approal_action', 'template': templatename }
      		})
		.done(function( data ) {
		        console.log('Successful AJAX Call! /// Return Data: ' + data);    
			document.getElementById("temp").innerHTML=data;	
		})
		.fail(function( data ) {
			console.log('Failed AJAX Call :( /// Return Data: ' + data);
		});
	});
	jQuery("#addnewsmsbutton").click( function() {
		var templatename = jQuery( '#smstemplate_select' ).val();
		var smstext = jQuery( '#smsnewtext' ).val();
		jQuery.ajax({
        		method: "POST",
			url: ajaxurl,
			data: { 'action': 'smstemplate_approal_action', 'smstext': smstext, 'template': templatename }
      		})
		.done(function( data ) {
		        console.log('Successful AJAX Call! /// Return Data: ' + data);	      
			document.getElementById("temp").innerHTML=data;
		
		})
		.fail(function( data ) {
		console.log('Failed AJAX Call :( /// Return Data: ' + data);
		});
	});

        jQuery("#updatesmsbutton").click( function() {
		var smsupdateId = jQuery( '#smsupdateId' ).val();
		var smsupdate = jQuery( '#smsupdate' ).val();
		jQuery.ajax({
        		method: "POST",
			url: ajaxurl,
			data: { 'action': 'smstemplate_approal_action', 'smsupdateId': smsupdateId, 'smsupdate': smsupdate }
      		})
		.done(function( data ) {
		        console.log('Successful AJAX Call! /// Return Data: ' + data);	      
			document.getElementById("temp").innerHTML=data;
		
		})
		.fail(function( data ) {
		console.log('Failed AJAX Call :( /// Return Data: ' + data);
		});
		jQuery.ajax({
        		method: "POST",
			url: ajaxurl,
			data: { 'action': 'smstemplate_approal_action', 'refreshtable': 'true' }
      		})
		.done(function( data ) {
		        console.log('Successful AJAX Call! /// Return Data: ' + data);	      
			document.getElementById("smstemplate-table").innerHTML=data;
		
		})
		.fail(function( data ) {
		console.log('Failed AJAX Call :( /// Return Data: ' + data);
		});
	});

	});
        
        function editSms(resultt)
        {
		jQuery.ajax({
        		method: "POST",
			url: ajaxurl,
			data: { 'action': 'smstemplate_approal_action', 'selectsms': resultt }
      		})
		.done(function( data ) {
		        console.log('Successful AJAX Call! /// Return Data: ' + data);
			str = data; 
			res = str.replace(/_/g, "spaceplace");	      
			document.getElementById("editsmsarea").innerHTML=res;
			str=document.getElementById("editsmsarea").innerHTML;
    			res = str.replace(/spaceplace/g, " ");	      
			document.getElementById("editsmsarea").innerHTML=res;
		})
		.fail(function( data ) {
		console.log('Failed AJAX Call :( /// Return Data: ' + data);
		});
        }

        function updateSms()
        {
                var smsupdateId = jQuery( '#smsupdateId' ).val();
		var smsupdate = jQuery( '#smsupdate' ).val();
		jQuery.ajax({
        		method: "POST",
			url: ajaxurl,
			data: { 'action': 'smstemplate_approal_action', 'smsupdateId': smsupdateId, 'smsupdate': smsupdate }
      		})
		.done(function( data ) {
		        console.log('Successful AJAX Call! /// Return Data: ' + data);	      
		//	document.getElementById("temp").innerHTML=data;
		
		})
		.fail(function( data ) {
		console.log('Failed AJAX Call :( /// Return Data: ' + data);
		});
		jQuery.ajax({
        		method: "POST",
			url: ajaxurl,
			data: { 'action': 'smstemplate_approal_action', 'refreshtable': 'true' }
      		})
		.done(function( data ) {
		        console.log('Successful AJAX Call! /// Return Data: ' + data);	      
			document.getElementById("smstemplate-table").innerHTML=data;
		
		})
		.fail(function( data ) {
		console.log('Failed AJAX Call :( /// Return Data: ' + data);
		});
	

}


	</script>
<?php
}

function smstemplate_ajax_handler() {
	global $wpdb;
if(isset($_POST['template'])){
	$template = $_POST['template'];
	if(isset($_POST['smstext'])){
		$posts = get_posts(array( 'name' => $_POST['template'] , 'post_type' => 'sms_template' , 'numberposts'=>-1) );
		$postid = 123;
		foreach ($posts as $post) {
			$postid=$post->ID;
		}
		add_post_meta($postid, smstext, $_POST['smstext']);
	}
	$smstemplate_table = new Smstemplatefiltered_Table();
	$smstemplate_table->prepare_filter($template);
	$smstemplate_table->setSelected($template);
	$data=$smstemplate_table->display();
//	echo json_encode($data);
}
if(isset($_POST['selectsms'])){
$metaid=$_POST['selectsms'];
$sql ="SELECT  meta_value FROM {$wpdb->prefix}postmeta
                WHERE {$wpdb->prefix}postmeta.meta_id = '$metaid' ";
        $result = $wpdb->get_results( $sql, 'ARRAY_A' );
$metavalue = $result[0]['meta_value'];
$metavalue = str_replace(" ","_", $metavalue);
echo "<div class=\"insidde\">
        <table class=\"form-table\"><tbody>        
	    <tr><td><label id=\"smsupdate_label\" for=\"smsupdate\">".__('Az üzenet szövege','sms_template')."</label>
		<input id=\"smsupdate\" class=\"wide-form-control\" name=\"smsupdate\" type=\"text\" value=";
echo $metavalue;
echo ">
                <input type=\"hidden\" id=\"smsupdateId\" name=\"smsupdateId\" value=".$_POST['selectsms'].">
		<button class=\"button button-primary button-large\" onclick=\"updateSms()\" type=\"button\" name=\"updatesmsbutton\" id=\"updatesmsbutton\">
		".__('Módosítás','sms_template')."
		</button>
		</td>
	    </tr>
	</tbody>
        </table>
	</div>";
}
if(isset($_POST['smsupdateId'])){
$smsupdateId=$_POST['smsupdateId'];
$smsupdate=$_POST['smsupdate'];
$sql ="UPDATE {$wpdb->prefix}postmeta SET meta_value='$smsupdate'
                WHERE {$wpdb->prefix}postmeta.meta_id = '$smsupdateId' ";
        $result = $wpdb->get_results( $sql, 'ARRAY_A' );
	echo "update";
}
if(isset($_POST['refreshtable'])){
$smstemplate_table = new Smstemplate_Table();
	$smstemplate_table->prepare_items();
$smstemplate_table->display();

}
	wp_die(); 
}
add_action( 'wp_ajax_smstemplate_approal_action', 'smstemplate_ajax_handler' );

function add_sms_log( $smslog ){
	$new_post = array(
		'post_title' => __('Elküldött sms','sms_template'),
		'post_content' => $smslog,
		'post_status' => 'open',
		'post_date' => date('Y-m-d H:i:s'),
		'post_author' => get_current_user_id(),
		'post_type' => 'sms_log',
		'post_category' => array(0)
	);
	$post_id = wp_insert_post($new_post); 
}

if ( ! class_exists( 'WC_Settings_Smstemplate' ) ) :

if ( ! class_exists( 'WC_Settings_Page' ) ) {
//	require_once( ABSPATH . 'wp-content/plugins/woocommerce/includes/admin/settings/class-wc-settings-page.php' );
	require_once( substr(plugin_dir_path(__FILE__),0,strlen(plugin_dir_path(__FILE__))-14) . '/woocommerce/includes/admin/settings/class-wc-settings-page.php' );
}

function sms_template_add_settings() {
	class WC_Settings_Smstemplate extends WC_Settings_Page {
		public function __construct() {
			$this->id    = 'sms_template';
			$this->label = __( 'SMS template', 'sms_template' );
			add_filter( 'woocommerce_settings_tabs_array',        array( $this, 'add_settings_page' ), 20 );
			add_action( 'woocommerce_settings_' . $this->id,      array( $this, 'output' ) );
			add_action( 'woocommerce_settings_save_' . $this->id, array( $this, 'save' ) );
			add_action( 'woocommerce_sections_' . $this->id,      array( $this, 'output_sections' ) );
		}

		public function get_sections() {		
			$sections = array(
				'setup' => __( 'Section 1', 'sms_template' )
			);
			return apply_filters( 'woocommerce_get_sections_' . $this->id, $sections );
		}

		public function get_settings( $current_section = '' ) {
			$settings = apply_filters( 'sms_template_section1_settings', array(	
				array(
				'type'     => 'checkbox',
				'id'       => 'sms_template_checkbox',
				'name'     => __( 'SMS küldés engedélyezve', 'sms_template' ),
				'desc'     => __( 'Csak az SMS template üzeneteire vonatkozik.', 'sms_template' ),
				'default'  => 'no',
				),					
				) 
			);
			return apply_filters( 'woocommerce_get_settings_' . $this->id, $settings, $current_section );
		}
		
		public function output() {		
			global $current_section;
			$settings = $this->get_settings( $current_section );
			WC_Admin_Settings::output_fields( $settings );
		}

		public function save() {		
			global $current_section;			
			$settings = $this->get_settings( $current_section );
			WC_Admin_Settings::save_fields( $settings );
		}
	}
	return new WC_Settings_Smstemplate();
}

add_filter( 'woocommerce_get_settings_pages', 'sms_template_add_settings', 15 );

endif;
