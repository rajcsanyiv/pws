<?php
class Smstemplate_Table extends WP_List_Table {

    public static function get_alltemplate( $per_page = 50, $page_number = 1 ) {
        global $wpdb;
	$sql="SELECT meta_id, post_title, meta_value FROM {$wpdb->prefix}posts
                LEFT JOIN {$wpdb->prefix}postmeta
		ON {$wpdb->prefix}postmeta.post_id = {$wpdb->prefix}posts.ID
                WHERE {$wpdb->prefix}postmeta.meta_key = 'smstext'
                ORDER BY {$wpdb->prefix}posts.post_title";
        $result = $wpdb->get_results( $sql, 'ARRAY_A' );
	return $result;
    }
     
    public static function get_templates( $per_page = 50, $page_number = 1 ,$filter) {
	global $wpdb;
	$sql2 ="SELECT meta_key, meta_id, post_title, meta_value FROM {$wpdb->prefix}posts
                LEFT JOIN {$wpdb->prefix}postmeta
		ON {$wpdb->prefix}postmeta.post_id = {$wpdb->prefix}posts.ID
                WHERE {$wpdb->prefix}postmeta.meta_key = 'smstext' 
                AND {$wpdb->prefix}postmeta.post_id = {$wpdb->prefix}posts.ID
		AND {$wpdb->prefix}posts.post_name=\"".$filter."\" 
                ORDER BY {$wpdb->prefix}posts.post_title";
        $result = $wpdb->get_results( $sql2, 'ARRAY_A' );
	return $result;
    }   

    public function __construct() {
	parent::__construct( array(
		'singular' => 'smstemplate',     
		'plural'   => 'smstemplatek',    
		'ajax'     => false,       
		) );
    }

    public function get_columns() {
        $columns = [
        	'post_title' => __( 'Megrendelés állapota', 'smstemplate' ),
        	'meta_value' => __( 'Üzenet', 'smstemplate' ),
		'meta_id' => __( 'Szerkesztés / Törlés', 'smstemplate' )
	];
        return $columns;
    }
	
    protected function get_sortable_columns() {
	$sortable_columns = array(
	);
        return $sortable_columns;
    }

    function column_post_title( $item ) {
        $title = $item['post_title'];
        return $title;
    }

    function column_meta_value( $item ) {
        $title = $item['meta_value'];
        return $title;
    }

    function column_meta_id( $item ) {
       	$title="<a href=# id=\"editsms\" onclick=\"editSms(".$item['meta_id'].")\">Szerkesztés</a>
	<a href=\"?page=smstemplate&action=delsmstemplate&template=".$item['meta_id']."\">Törlés</a>";
        return $title;
    }

    protected function column_default( $item, $column_name ) {
	switch ( $column_name ) {
		case 'meta_id':
		case 'meta_value':
	        case 'post_title':
	        return $item[ $column_name ];
            default:
                return print_r( $item, true );
        }
    }

    function prepare_items() {
	global $wpdb; 
	$per_page = 25;
	$columns  = $this->get_columns();
	$hidden   = array();
	$sortable = $this->get_sortable_columns();
	$this->_column_headers = array( $columns, $hidden, $sortable );
        if ( 'edit' === $this->current_action() || 'view' === $this->current_action())
		$data = $this->get_templates();
	else
		$data = $this->get_alltemplate();
		usort( $data, array( $this, 'usort_reorder' ) );
		$current_page = $this->get_pagenum();
		$total_items = count( $data );
		$data = array_slice( $data, ( ( $current_page - 1 ) * $per_page ), $per_page );
		$this->items = $data;
		$this->set_pagination_args( array(
			'total_items' => $total_items,                    
			'per_page'    => $per_page,  
			'total_pages' => ceil( $total_items / $per_page ), 
		) );
	}

function prepare_filter($filter) {
	global $wpdb; 
	$per_page = 25;
	$columns  = $this->get_columns();
	$hidden   = array();
	$sortable = $this->get_sortable_columns();
	$this->_column_headers = array( $columns, $hidden, $sortable );
        if ( 'edit' === $this->current_action() || 'view' === $this->current_action())
		$data = $this->get_templates(50,1,$filter);
	else
		$data = $this->get_templates(50,1,$filter);
		usort( $data, array( $this, 'usort_reorder' ) );
		$current_page = $this->get_pagenum();
		$total_items = count( $data );
		$data = array_slice( $data, ( ( $current_page - 1 ) * $per_page ), $per_page );
		$this->items = $data;
		$this->set_pagination_args( array(
			'total_items' => $total_items,                    
			'per_page'    => $per_page,  
			'total_pages' => ceil( $total_items / $per_page ), 
		) );
	}
}

class Smstemplatefiltered_Table extends WP_List_Table {

    public static function get_alltemplate( $per_page = 50, $page_number = 1 ) {
        global $wpdb;
	$sql="SELECT meta_id, post_title, meta_value FROM {$wpdb->prefix}posts
                LEFT JOIN {$wpdb->prefix}postmeta
		ON {$wpdb->prefix}postmeta.post_id = {$wpdb->prefix}posts.ID
                WHERE {$wpdb->prefix}postmeta.meta_key = 'smstext'
                ORDER BY {$wpdb->prefix}posts.post_title";
        $result = $wpdb->get_results( $sql, 'ARRAY_A' );
	return $result;
    }
     
    public static function get_templates( $per_page = 50, $page_number = 1 ,$filter) {
	global $wpdb;
	$sql2 ="SELECT meta_key, meta_id, post_title, meta_value FROM {$wpdb->prefix}posts
                LEFT JOIN {$wpdb->prefix}postmeta
		ON {$wpdb->prefix}postmeta.post_id = {$wpdb->prefix}posts.ID
                WHERE {$wpdb->prefix}postmeta.meta_key = 'smstext' 
                AND {$wpdb->prefix}postmeta.post_id = {$wpdb->prefix}posts.ID
		AND {$wpdb->prefix}posts.post_name=\"".$filter."\" 
                ORDER BY {$wpdb->prefix}posts.post_title";
        $result = $wpdb->get_results( $sql2, 'ARRAY_A' );
	return $result;
    }   

    public function __construct() {
	parent::__construct( array(
		'singular' => 'smstemplate',     
		'plural'   => 'smstemplatek',    
		'ajax'     => false,       
		) );
    }
	
    public function get_columns() {
        $columns = [
        	'post_title' => __( 'Megrendelés állapota', 'smstemplate' ),
        	'meta_value' => __( 'Üzenet', 'smstemplate' )
	];
        return $columns;
    }
	
    protected function get_sortable_columns() {
	$sortable_columns = array(
	);
        return $sortable_columns;
    }

    function column_post_title( $item ) {
        $title = $item['post_title'];
        return $title;
    }

    function column_meta_value( $item ) {
        $title = $item['meta_value'];
        return $title;
    }    

    protected function column_default( $item, $column_name ) {
	switch ( $column_name ) {
		case 'meta_id':
		case 'meta_value':
	        case 'post_title':
	        return $item[ $column_name ];
            default:
                return print_r( $item, true );
        }
    }

    function prepare_items() {
	global $wpdb; 
	$per_page = 25;
	$columns  = $this->get_columns();
	$hidden   = array();
	$sortable = $this->get_sortable_columns();
	$this->_column_headers = array( $columns, $hidden, $sortable );
        if ( 'edit' === $this->current_action() || 'view' === $this->current_action())
		$data = $this->get_templates();
	else
		$data = $this->get_alltemplate();
		usort( $data, array( $this, 'usort_reorder' ) );
		$current_page = $this->get_pagenum();
		$total_items = count( $data );
		$data = array_slice( $data, ( ( $current_page - 1 ) * $per_page ), $per_page );
		$this->items = $data;
		$this->set_pagination_args( array(
			'total_items' => $total_items,                    
			'per_page'    => $per_page,  
			'total_pages' => ceil( $total_items / $per_page ), 
		) );
	}

    function prepare_filter($filter) {
	global $wpdb; 
	$per_page = 25;
	$columns  = $this->get_columns();
	$hidden   = array();
	$sortable = $this->get_sortable_columns();
	$this->_column_headers = array( $columns, $hidden, $sortable );
        if ( 'edit' === $this->current_action() || 'view' === $this->current_action())
		$data = $this->get_templates(50,1,$filter);
	else
		$data = $this->get_templates(50,1,$filter);
		usort( $data, array( $this, 'usort_reorder' ) );
		$current_page = $this->get_pagenum();
		$total_items = count( $data );
		$data = array_slice( $data, ( ( $current_page - 1 ) * $per_page ), $per_page );
		$this->items = $data;
		$this->set_pagination_args( array(
			'total_items' => $total_items,                    
			'per_page'    => $per_page,  
			'total_pages' => ceil( $total_items / $per_page ), 
		) );
	}

}
