<?php

/*
  Plugin Name: Advanced Order Filtering
  Plugin URI: http://
  Description: Promera webshop extra functions
  Version: 0.1.0
  Author: Peter Schveitzer / WBS
  Author URI: http://
  Text Domain: Advanced Order
  Domain Path: /languages
 */

class Filter_Orders_By_Payment {
	protected static $instance;
	public function __construct() {
		if ( is_admin() ) {
			add_action( 'restrict_manage_posts', array( $this, 'filter_orders_by_payment_method') , 20 );
			add_filter( 'request',               array( $this, 'filter_orders_by_payment_method_query' ) );
		}
	}
	public function filter_orders_by_payment_method() {
		global $typenow;

		if ( 'shop_order' === $typenow ) {

			// get all payment methods, even inactive ones
			$gateways = WC()->payment_gateways->payment_gateways();
                        unset($gateways['cheque']);unset($gateways['ppec_paypal']);
		?>
			<select name="_shop_order_payment_method" id="dropdown_shop_order_payment_method">
				<option value="">
					<?php esc_html_e( 'Összes fizetés', 'wc-filter-orders-by-payment' ); ?>
				</option>

				<?php foreach ( $gateways as $id => $gateway ) : ?>
				<option value="<?php echo esc_attr( $id ); ?>" <?php echo esc_attr( isset( $_GET['_shop_order_payment_method'] ) ? selected( $id, $_GET['_shop_order_payment_method'], false ) : '' ); ?>>
					<?php
                                            $string = esc_html( $gateway->get_method_title() );
                                            print $string;
                                        ?>
				</option>
				<?php endforeach; ?>
			</select>
			<?php
		}
                echo '<style type="text/css">';
                echo 'select[id=filter-by-date] {display: none;}';
                echo '</style>';
	}
	public function filter_orders_by_payment_method_query( $vars ) {
		global $typenow;
		if ( 'shop_order' === $typenow && isset( $_GET['_shop_order_payment_method'] ) ) {
			$vars['meta_key']   = '_payment_method';
			$vars['meta_value'] = wc_clean( $_GET['_shop_order_payment_method'] );
		}
		return $vars;
	}
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
}

class Filter_Orders_By_Shipping {
	private static $instance = null;
	private function __construct() {
		if ( !in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) || !is_admin() ){
			return;
		}
                add_action( 'restrict_manage_posts', array( $this, 'filter_orders_by_payment_method') , 20 );
		add_action( 'posts_where', array( $this, 'product_filter_where' ));
	}
        public function filter_orders_by_payment_method() {
            $url = $_GET['post_type'];
            if(  $url == "product" ){
                print ' <style>#date-range-filter-interval{display: none;}#dropdown_shop_order_shipping_method{display: none;}</style>';
            }
            global $wpdb;
            $val = $_GET['_shop_order_shipping_method'];
            $sql = "SELECT `order_item_name` FROM `{$wpdb->prefix}woocommerce_order_items` WHERE `order_item_type` LIKE 'shipping' GROUP BY `order_item_name`";
            $result = $wpdb->get_results($sql, 'ARRAY_N');
            print '<select name="_shop_order_shipping_method" id="dropdown_shop_order_shipping_method">';
            print '<option value="all">Összes szállítás</option>';
            foreach ($result as $value) {
                print '<option value="'.$value[0].'">'.$value[0].'</option>';
            }
            ?>

                <script>
                    $( document ).ready(function() {
                        var value = "<?php print $val ?>";
                        if(value == ""){
                            document.getElementById("dropdown_shop_order_shipping_method").value = "all";
                        }
                        else {
                            document.getElementById("dropdown_shop_order_shipping_method").value = value;
                        }
                    });
                </script>
            <?php
        }
        public function filter_orders_by_payment_method_X() {
            global $typenow;
            $val = $_GET['_shop_order_shipping_method'];
            if ( 'shop_order' === $typenow ) {
			$gateways = WC()->shipping->get_shipping_methods();
			?>
                        <script>
                        var value = "<?php print $val ?>"
                            $( document ).ready(function() {
                                //console.log(value+'dx');
                                //document.getElementById("dropdown_shop_order_shipping_method").value = value;
                                document.getElementById('name').value = "<?php echo $_GET['_shop_order_shipping_method'];?>";
                            });
                            document.getElementById('name').value = "<?php echo $_GET['_shop_order_shipping_method'];?>";
                        </script>;
			<select name="_shop_order_shipping_method" id="dropdown_shop_order_shipping_method">
				<option value="">
					<?php esc_html_e( 'Szállítási mód', 'wc-filter-orders-by-payment' ); ?>
				</option>

                                <option value="Átalány">
					Átalány_V_2.0
				</option>
				<?php foreach ( $gateways as $id => $gateway ) : ?>
				<option value="<?php echo esc_attr( $id ); ?>" <?php echo esc_attr( isset( $_GET['_shop_order_payment_method'] ) ? selected( $id, $_GET['_shop_order_payment_method'], false ) : '' ); ?>>
					<?php echo esc_html( $gateway->get_method_title() ); ?>
				</option>
				<?php endforeach; ?>
			</select>
			<?php
            }
	}
	public function product_filter_where( $where ) {
            global $wpdb;
            //if( is_search() ) {
                $method = $_GET['_shop_order_shipping_method'];
                if ( isset( $_GET['_shop_order_shipping_method'] ) && !empty( $_GET['_shop_order_shipping_method'] ) ) {
                    if($method == "all"){
                        //$where .= " AND {$wpdb->prefix}posts.ID IN (SELECT `order_id` FROM `{$wpdb->prefix}woocommerce_order_items` WHERE `order_item_type` <> ( 'shipping' ))";
                    }
                    else {
                    $where .= " AND {$wpdb->prefix}posts.ID IN (
                                        SELECT `order_id`
                                        FROM `{$wpdb->prefix}woocommerce_order_items`
                                        WHERE `order_item_type` = 'shipping'
                                        AND `order_item_name` = '".$method."'
                                        )";
                    }
                }
            //}
            return $where;
	}
        public static function instance() {
		if ( null == self::$instance ) {
			self::$instance = new self;
		}
		return self::$instance;
	}
}

Filter_Orders_By_Payment::instance();
Filter_Orders_by_Shipping::instance();