<?php
/*
Plugin Name: New order states
Description: This plugin adds new order states for courier services.
Version: 1.0
Author: Viktor Rajcsanyi
*/

if ( ! defined( 'ABSPATH' ) ) exit; 

function register_order_statuses() {
    register_post_status( 'wc-order-placed', array(
        'label'                     => 'Megrendelés beérkezett',
        'public'                    => true,
        'exclude_from_search'       => false,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
        'label_count'               => _n_noop( 'Megrendelés beérkezett <span class="count">(%s)</span>', 'Megrendelés beérkezett <span class="count">(%s)</span>' )
    ) );
    register_post_status( 'wc-order-billed', array(
        'label'                     => 'Számlázva',
        'public'                    => true,
        'exclude_from_search'       => false,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
        'label_count'               => _n_noop( 'Számlázva <span class="count">(%s)</span>', 'Számlázva <span class="count">(%s)</span>' )
    ) );
    register_post_status( 'wc-order-packed', array(
        'label'                     => 'Rendelés összekészítve',
        'public'                    => true,
        'exclude_from_search'       => false,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
        'label_count'               => _n_noop( 'Rendelés összekészítve <span class="count">(%s)</span>', 'Rendelés összekészítve <span class="count">(%s)</span>' )
    ) );
    register_post_status( 'wc-order-sent', array(
        'label'                     => 'Átadva a futárszolgálatnak',
        'public'                    => true,
        'exclude_from_search'       => false,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
        'label_count'               => _n_noop( 'Átadva a futárszolgálatnak <span class="count">(%s)</span>', 'Átadva a futárszolgálatnak <span class="count">(%s)</span>' )
    ) );
    register_post_status( 'wc-order-paid', array(
        'label'                     => 'Megrendelés kifizetve',
        'public'                    => true,
        'exclude_from_search'       => false,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
        'label_count'               => _n_noop( 'Megrendelés kifizetve <span class="count">(%s)</span>', 'Megrendelés kifizetve <span class="count">(%s)</span>' )
    ) );
}
add_action( 'init', 'register_order_statuses' );

function add_new_items_to_order_statuses( $order_statuses ) {
    $new_order_statuses = array();
    foreach ( $order_statuses as $key => $status ) {
        $new_order_statuses[ $key ] = $status;
        if ( 'wc-processing' === $key ) {
            $new_order_statuses['wc-order-placed'] = 'Megrendelés beérkezett';
            $new_order_statuses['wc-order-billed'] = 'Számlázva';
            $new_order_statuses['wc-order-packed'] = 'Rendelés összekészítve';
            $new_order_statuses['wc-order-sent'] = 'Átadva a futárszolgálatnak';
            $new_order_statuses['wc-order-paid'] = 'Megrendelés kifizetve';
        }
    }
    return $new_order_statuses;
}
add_filter( 'wc_order_statuses', 'add_new_items_to_order_statuses' );

