<?php
/*
Plugin Name: New order states
Description: This plugin adds new order states for courier services.
Version: 1.0
Author: Viktor Rajcsanyi
Author URI: http://promera.hu
Text Domain: neworderstates
Domain Path: /languages/
*/

if ( ! defined( 'ABSPATH' ) ) exit; 

function register_order_statuses() {
    register_post_status( 'wc-order-placed', array(
        'label'                     => __( 'Megrendelés beérkezett', 'neworderstates' ),
        'public'                    => true,
        'exclude_from_search'       => false,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
    ) );
    register_post_status( 'wc-order-billed', array(
        'label'                     => __( 'Számlázva', 'neworderstates' ),
        'public'                    => true,
        'exclude_from_search'       => false,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
    ) );
    register_post_status( 'wc-order-packed', array(
        'label'                     => __('Rendelés összekészítve', 'neworderstates' ),
        'public'                    => true,
        'exclude_from_search'       => false,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
    ) );
    register_post_status( 'wc-order-sent', array(
        'label'                     => __('Átadva a futárszolgálatnak', 'neworderstates' ),
        'public'                    => true,
        'exclude_from_search'       => false,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
    ) );
    register_post_status( 'wc-order-paid', array(
        'label'                     => __('Megrendelés kifizetve', 'neworderstates' ),
        'public'                    => true,
        'exclude_from_search'       => false,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
    ) );
}
add_action( 'init', 'register_order_statuses' );

function add_new_items_to_order_statuses( $order_statuses ) {
    $new_order_statuses = array();
    foreach ( $order_statuses as $key => $status ) {
        $new_order_statuses[ $key ] = $status;
        if ( 'wc-processing' === $key ) {
            $new_order_statuses['wc-order-placed'] = __('Megrendelés beérkezett', 'neworderstates' );
            $new_order_statuses['wc-order-billed'] = __('Számlázva', 'neworderstates' );
            $new_order_statuses['wc-order-packed'] = __('Rendelés összekészítve', 'neworderstates' );
            $new_order_statuses['wc-order-sent'] = __('Átadva a futárszolgálatnak', 'neworderstates' );
            $new_order_statuses['wc-order-paid'] = __('Megrendelés kifizetve', 'neworderstates' );
        }
    }
    return $new_order_statuses;
}
add_filter( 'wc_order_statuses', 'add_new_items_to_order_statuses' );

