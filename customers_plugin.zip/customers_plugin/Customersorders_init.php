<?php

function Customersorders_init($file) {

    require_once('Customersorders_Plugin.php');
    $aPlugin = new Customersorders_Plugin();

    if (!$aPlugin->isInstalled()) {
        $aPlugin->install();
    }
    else {
        $aPlugin->upgrade();
    }

    $aPlugin->addActionsAndFilters();

    if (!$file) {
        $file = __FILE__;
    }
    register_activation_hook($file, array(&$aPlugin, 'activate'));
    register_deactivation_hook($file, array(&$aPlugin, 'deactivate'));
}
