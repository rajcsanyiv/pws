<?php
/**
 * Forms footer
 */
?>

<div class="submit-row">
	<span class="spinner"></span>
	<input type="submit" class="button button-primary send-form" value="<?php echo esc_attr( $this->get_var( 'cta' ) ); ?>">
</div>

</form>
