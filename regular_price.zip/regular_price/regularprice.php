<?php
/*
Plugin Name: Regularprice plugin
Description: Price for offline shopping
Version: 1.0
Author: Viktor Rajcsanyi / Promera
Author URI: http://promera.hu
Text Domain: regularprice
Domain Path: /languages
*/

function Regularprice_i18n_init() {
    $pluginDir = dirname(plugin_basename(__FILE__));
    load_plugin_textdomain('regularprice', false, $pluginDir . '/languages/');
}

add_action('plugins_loaded','Regularprice_i18n_init');

include_once('regularprice_init.php');
Regularprice_init(__FILE__);

