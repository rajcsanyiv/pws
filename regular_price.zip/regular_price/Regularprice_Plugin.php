<?php

include_once('Regularprice_LifeCycle.php');

class Regularprice_Plugin extends Regularprice_LifeCycle {

    public function getPluginDisplayName() {
        return 'Regularprice';
    }

    protected function getMainPluginFileName() {
        return 'regularprice.php';
    }

    public function addActionsAndFilters() {
        add_action('admin_menu', array(&$this, 'addSettingsSubMenuPage'));
        add_action('admin_enqueue_scripts', function() {
            wp_enqueue_style('admin-styles', plugins_url('css/price.css', __FILE__));
            wp_enqueue_script('admin-scripts', plugins_url('js/price.js', __FILE__));
        });
        // <editor-fold defaultstate="collapsed" desc="extra fogyasztói ár">
        add_action('woocommerce_product_options_pricing', function() {
            /* @var $product_object WC_Product */
            global $product_object;
            $price_sale = $product_object->get_sale_price('edit');
            $price_regular = $product_object->get_regular_price('edit');
            $price_fogyi = $product_object->get_meta('fogyasztoi_ar');
            if (!$price_fogyi) {
                $price_fogyi = $price_regular;
            }
            woocommerce_wp_text_input(array(
                'id' => 'fogyasztoi_ar',
                'label' => 'Fogyasztói ár (Ft)',
                'data_type' => 'price',
                'value' => $price_fogyi,
            ));
            echo '<p class="form-field"><label>Nettó árak</label><span class="short">';
            echo '<b>' . wc_price(wc_get_price_excluding_tax($product_object, array('price' => $price_fogyi))) . '</b>';
            echo ' | <b>' . wc_price(wc_get_price_excluding_tax($product_object, array('price' => $price_regular))) . '</b>';
            echo ' | <b>' . ($price_sale ? wc_price(wc_get_price_excluding_tax($product_object, array('price' => $price_sale))) : '-') . '</b>';
            echo ' (módosítás esetén, csak mentés után frissül)</span></p>';
        });
        $far_save = function($post_id) {
            $far = isset($_POST['fogyasztoi_ar']) ? $_POST['fogyasztoi_ar'] : '';
            if (!$far) {
                $prod = wc_get_product($post_id);
                $far = $prod->get_regular_price();
            }
            if ($far) {
                update_post_meta($post_id, 'fogyasztoi_ar', esc_attr($far));
            }
        };
        add_action('woocommerce_process_product_meta', $far_save);
        add_action('woocommerce_product_quick_edit_save', $far_save);
        // </editor-fold>
        // <editor-fold defaultstate="collapsed" desc="árak variálása">
        add_action('manage_product_posts_custom_column', function($column, $post_id) {
            if ($column == 'price') {
                /* @var $prod WC_Product */
                $prod = wc_get_product($post_id);
                echo '<ins class="netto">nettó: ' . wc_price(wc_get_price_excluding_tax($prod)) . '</ins>';
            }
        }, 10, 2);
        add_filter('woocommerce_get_price_html', function($price, $prod) {
            if ($price) {
		$post_id=$prod->get_id();
		$args = array(
		'post_type'     => 'product_variation',
		'post_status'   => array( 'private', 'publish' ),
		'numberposts'   => -1,
		'post_parent'   => $post_id
		);
	        $variations = get_posts( $args );
	        if($variations==NULL) {
                	$price_sale = $prod->is_on_sale('edit') ? $prod->get_sale_price('edit') : 0;
	                $price_regular = $prod->get_regular_price('edit');
        	        $price_fogyi = $prod->get_meta('fogyasztoi_ar', true, 'edit');
        	        if (!$price_fogyi) {
                	    $price_fogyi = $price_regular;
                	}
		}
	        else {
			update_post_meta( $post_id,"_sale_price", "");
			update_post_meta( $post_id,"_regular_price", "");
			update_post_meta( $post_id,"fogyasztoi_ar", "");
			update_post_meta( $post_id,"_price", "");
			$price_fogyimin=10000000;
			$price_fogyiminregular=10000000;
			foreach ( $variations as $variation ) {
				$product=get_product($variation->ID);
				$price_sale = $product->is_on_sale('edit') ? $product->get_sale_price('edit') : 0;
        	       		$price_regular = $product->get_regular_price('edit');
		                //$price_fogyi = $prod->get_meta('fogyasztoi_ar', true, 'edit');
				$price_fogyi = get_post_meta($variation->ID,'fogyasztoi_ar', true);
        	        	if (!$price_fogyi) {
        	            		$price_fogyi = $price_regular;
		                }
				if($price_fogyi<$price_fogyimin){
					$price_fogyimin=$price_fogyi;
					$price_fogyiminregular=$price_regular;
				}
			}
			$price_fogyi=$price_fogyimin;
			$price_regular=$price_fogyiminregular;
			$rpercent = $price_fogyi > 0 ? (int) (100 - ($price_regular / $price_fogyi * 100)) : 0;
	                $spercent = $price_fogyi > 0 ? (int) (100 - ($price_sale / $price_fogyi * 100)) : 0;
        	        $percent = '<strong class="percent-strong">-%d%%</strong>';
		}
		if($variations!=NULL){//varialhato termek fogyasztoi ar
	                $price_prefix = '<del class="fogyar">' . (is_numeric($price_fogyi) ? wc_price($price_fogyi) : $price_fogyi) . '</del> ';
		}
		else{//nem varialhato termek fogyasztoi ar
	                $price_prefix = '<del class="fogyar">' . (is_numeric($price_fogyi) ? wc_price($price_fogyi) : $price_fogyi) . '</del>';
		}
                if($variations!=NULL){
                if ($prod->is_on_sale()) {
                    $infotitle = sprintf(__('Az akció %s%s tart.', 'regularprice'), '<b>' . __('visszavonásig', 'regularprice') . '</b>', '');
                    $dateto = $prod->get_date_on_sale_to('edit');
                    if ($dateto) {
                        $infotitle = sprintf(__('Az akció %s%s tart.', 'regularprice'), '<b>' . $dateto->date_i18n() . '</b>', __('-ig', 'regularprice'));
                    }
                    $info = '<i class="glyphicon glyphicon-info-sign" data-toggle="tooltip" data-html="true" data-trigger="hover focus click" data-container="body" data-placement="top" title="' . $infotitle . '"></i>';
                    $info .= '<script type="text/javascript"> jQuery(function () { jQuery(\'[data-toggle="tooltip"]\').tooltip(); }); </script>';
                    $price = str_replace('<ins>', '<ins class="akcios">', $price);
                    $price = str_replace('</ins>', $info . ($price_sale ? sprintf($percent, $spercent) : '') . '</ins>', $price);
                    $price = str_replace('<del>', '<del class="webar">', $price);
                    $price = str_replace('</del>', ($rpercent ? sprintf($percent, $rpercent) : '') . '</del>', $price);
                    $price = $price_prefix . $price;
                } else {//varialhato termek webaruhazi ar
                    $price = $price_prefix . '<ins class="webar">' . $price . ($rpercent ? sprintf($percent, $rpercent) : '') . '</ins>';
                }
		}
		else{
		$rpercent = $price_fogyi > 0 ? (int) (100 - ($price_regular / $price_fogyi * 100)) : 0;
                $spercent = $price_fogyi > 0 ? (int) (100 - ($price_sale / $price_fogyi * 100)) : 0;
                $percent = '<strong class="percent-strong">-%d%%</strong>';
                if ($prod->is_on_sale()) {
                    $infotitle = sprintf(__('Az akció %s%s tart.', 'regularprice'), '<b>' . __('visszavonásig', 'regularprice') . '</b>', '');
                    $dateto = $prod->get_date_on_sale_to('edit');
                    if ($dateto) {
                        $infotitle = sprintf(__('Az akció %s%s tart.', 'regularprice'), '<b>' . $dateto->date_i18n() . '</b>', __('-ig', 'regularprice'));
                    }
                    $info = '<i class="glyphicon glyphicon-info-sign" data-toggle="tooltip" data-html="true" data-trigger="hover focus click" data-container="body" data-placement="top" title="' . $infotitle . '"></i>';
                    $info .= '<script type="text/javascript"> jQuery(function () { jQuery(\'[data-toggle="tooltip"]\').tooltip(); }); </script>';
                    $price = str_replace('<ins>', '<ins class="akcios">', $price);
                    $price = str_replace('</ins>', $info . ($price_sale ? sprintf($percent, $spercent) : '') . '</ins>', $price);
                    $price = str_replace('<del>', '<del class="webar">', $price);
                    $price = str_replace('</del>', ($rpercent ? sprintf($percent, $rpercent) : '') . '</del>', $price);
                    $price = $price_prefix . $price;
                } else {//nem varialhato termek webaruhazi ar
                    $price = $price_prefix . '<ins class="webar">' . $price . ($rpercent ? sprintf($percent, $rpercent) : '') . '</ins>';
                }
		}
            }
if($variations!=NULL){
//$price=str_replace('&#70;&#116','&#70;&#116;&#45;&#116;ó&#108', $price);
}
            return $price;
        }, 1, 2);
function variable_price_format( $price, $product ) {
 
    $prefix = "";
 
    $min_price_regular = $product->get_variation_regular_price( 'min', true );
    $min_price_sale    = $product->get_variation_sale_price( 'min', true );
    $max_price = $product->get_variation_price( 'max', true );
    $min_price = $product->get_variation_price( 'min', true );
 
    $price = ( $min_price_sale == $min_price_regular ) ?
        wc_price( $min_price_regular ) :
        '<del>' . wc_price( $min_price_regular ) . '</del>' . '<ins>' . wc_price( $min_price_sale ) . '</ins>';
 
    return ( $min_price == $max_price ) ?
        $price :
        sprintf('%s%s', $prefix, $price);
 
}
 
add_filter( 'woocommerce_variable_sale_price_html', 'variable_price_format', 10, 2 );
add_filter( 'woocommerce_variable_price_html', 'variable_price_format', 10, 2 );

    }
}

