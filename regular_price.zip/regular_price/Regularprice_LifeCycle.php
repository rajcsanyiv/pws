<?php

include_once('Regularprice_InstallIndicator.php');

class Regularprice_LifeCycle extends Regularprice_InstallIndicator {

    public function install() {
    }

    public function uninstall() {
    }

    public function upgrade() {
    }

    public function activate() {
    }

    public function deactivate() {
    }

    protected function initOptions() {
    }

    public function addActionsAndFilters() {
    }

    protected function unInstallDatabaseTables() {
    }

    protected function otherInstall() {
    }

    protected function otherUninstall() {
    }

    public function addSettingsSubMenuPage() {
    }

    public function adminScripts() {
    }

    protected function requireExtraPluginFiles() {
    }

    protected function getSettingsSlug() {
    }
}
