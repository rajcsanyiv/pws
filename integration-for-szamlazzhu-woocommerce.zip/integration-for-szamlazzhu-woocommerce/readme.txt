=== Integration for Szamlazz.hu & WooCommerce ===
Contributors: passatgt
Tags: szamlazz.hu, szamlazz, woocommerce, szamlazo, magyar
Requires at least: 3.5
Tested up to: 5.0
Stable tag: 3.2.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Számlázz.hu összeköttetés WooCommerce-hez.

== Description ==

> **PRO verzió**
> A bővítménynek elérhető a PRO verziója 10.000 Ft-ért, amelyet itt vásárolhatsz meg: [https://szamlazz.visztpeter.me/](https://szamlazz.visztpeter.me/)
> A licensz kulcs egy weboldalon aktiválható és 1 év emailes support is jár hozzá beállításhoz, testreszabáshoz, konfiguráláshoz.
> A vásárlással támogathatod a fejlesztést akkor is, ha esetleg a PRO verzióban elérhető funkciókra nincs is szükséged.

= Funkciók =

* **Manuális számlakészítés**
Minden rendelésnél a jobb oldalon megjelenik egy új gomb, rákattintáskor elküldi az adatokat számlázz.hu-nak és legenerálja a számlát.
* **Automata számlakészítés**
Lehetőség van a számlát automatikusan elkészíteni bizonyos fizetési módoknál, vagy ha a rendelés teljesítve lett
* **Mennyiségi egység** _PRO_
A tételek mellett a mennyiségi egységet is feltüntetni a számlát, amelyet a beállításokban minden termékhez külön-külön meg tudod adni és megjegyzést is tudsz megadni a tételhez
* **E-Nyugta** _PRO_
Ha elektronikus termékeket, jegyeket, letölthető tartalmakat értékesítesz, nem fontos bekérni a vásárló számlázási címét, elég csak az email címét, a bővítmény pedig elekronikus nyugtát készít
* **Számlaértesítő** _PRO_
Az ingyenes verzióban a számlázz.hu küldi ki a számlaértesítőt a vásárlónak. A PRO verzióban csatolni lehet a WooCommerce által küldött emailekhez, így nem fontos használni a Számlázz.hu számlaértesítőjét és a vásárlód egyel kevesebb emailt fog kapni
* **Nemzetközi számla** _PRO_
Ha külföldre értékesítesz például euróban, lehetőség van a számla nyelv átállítására és az aktuális MNB árfolyam feltüntetésére a számlán. Kompatibilis WPML-el és Polylang-al is.
* **Nemzetközi számla** _PRO_
Ha a rendelés állapota átállítódik függőben lévőre, automatán legenerálja a díjbekérő számlát. Lehet kézzel egy-egy rendeléshez külön díjbekérőt is csinálni.
* **Előleg számla** _PRO_
A díjbekérő helyett lehetőség van előleg számlát készíteni
* **IPN és teljesítettnek jelölés** _PRO_
A kifizetettségéről értesítést kaphat a webáruház, illetve automatán teljesítettnek jelölheti a számlát
* **Naplózás**
Minden számlakészítésnél létrehoz egy megjegyzést a rendeléshoz, hogy mikor, milyen néven készült el a számla
* **Sztornózás** _PRO_
A számla sztornózható a rendelés oldalon, vagy kikapcsolható 1-1 rendeléshez
* **Szállítólevél** _PRO_
Lehetőség van arra, hogy a számlakészítés mellett szállítólevelet is készítsen automatikusan a rendszer
* **Adószám mező**
A WooCommerce-ben alapértelmezetten nincs adószám mező. Ezzel az opcióval bekapcsolható, hogy a számlázási adatok között megjelenjen. Az adószámot a rendszer eltárolja, a vásárlónak küldött emailben és a rendelés adatai között is megjelenik. Lehetőség van arra, hogy csak 100.000 Ft áfatartalom felett látszódjon.
* **Automata teljesítettnek jelölés**
Beállítható, melyik fizetési módoknál jelölje meg a számlát teljesítettnek automatikusan
* **És még sok más**
Vezetéknév / keresztnév csere(PRO), Város kitöltése irányítószám alapján(PRO), Papír és elektronikus számla állítás, Áfakulcs állítás(PRO), Számlaszám előtag módosítása(PRO), Letölthető számlák a vásárló profiljában, Hibás számlakészítésről e-mailes értesítő(PRO) stb...

= Fontos kiemelni =
* A generált számlát letölti saját weboldalra is, egy véletlenszerű fájlnéven tárolja a wp-content/uploads/wc_szamlazz mappában, így csak az tudja letölteni, aki ismeri a fájlnevet:)
* Fizetési határidő és megjegyzés írható a számlákhoz
* Kuponokkal is működik, a számlán negatív tételként fog megjelenni a végén
* Szállítást is ráírja a számlára
* A PDF fájl letölthető egyből a Rendelések oldalról is(táblázat utolsó oszlopa)

= Használat =
Telepítés után a WooCommerce / Beállítások oldalon meg kell adni a szamlazz.hu felhasználónevet és jelszót, illetve az ott található többi beállításokat igény szerint.
Minden rendelésnél jobb oldalon megjelenik egy új doboz, ahol egy gombnyomással létre lehet hozni a számlát. Az Opciók gombbal felül lehet írni a beállításokban megadott értékeket 1-1 számlához.
Ha az automata számlakészítés be van kapcsolva, akkor a rendelés lezárásakor(Teljesített rendelés státuszra állítás) automatikusan létrehozza a számlát a rendszer.
A számlakészítés kikapcsolható 1-1 rendelésnél az Opciók legördülőn belül.
Az elkészült számla a rendelés aloldalán és a rendelés listában az utolsó oszlopban található PDF ikonra kattintva letölthető.

**FONTOS:** Mindenen esetben ellenőrizd le, hogy a számlakészítés megfelelő e és konzultálj a könyvelőddel, neki is megfelelnek e a generált számlák. Sajnos minden esetet nem tudok tesztelni, különböző áfakulcsok, termékvariációk, kuponok stb..., így mindenképp teszteld le éles használat előtt és ha valami gond van, jelezd felém és megpróbálom javítani.

= Fejlesztőknek =

A plugin egy XML fájlt generál, ezt küldi el a szamlazz.hu-nak, majd az egy pdf-ben visszaküldi az elkészített számlát. Az XML fájl generálás előtt módosítható a `wc_szamlazz_xml` filterrel. Ez minden esetben az éppen aktív téma functions.php fájlban történjen, hogy az esetleges plugin frissítés ne törölje ki a módosításokat!

Lehetőség van sikeres és sikertelen számlakészítés után egyedi funckiók meghívására a bővítmény módosítása nélkül:

   <?php
   add_action('wc_szamlazz_after_invoice_success', 'sikeres_szamlakeszites',10,4);
   function($order, $response, $szamlaszam, $pdf_link) {
     //...
   }

   add_action('wc_szamlazz_after_invoice_error', 'sikeres_szamlakeszites',10,5);
   function($order, $response, $agent_error_code, $agent_error, $agent_body) {
     //...
   }
   ?>

== Installation ==

1. Töltsd le a bővítményt
2. Wordpress-ben bővítmények / új hozzáadása menüben fel kell tölteni
3. WooCommerce / Integráció menüpontban találhatod a Számlázz.hu beállítások, itt legalább a felhasználónév és jelszó mezőt kötelező kitölteni
4. Működik

== Frequently Asked Questions ==

= Mi a különbség a PRO verzió és az ingyenes között? =

A PRO verzió néhány hasznos funckiót tud, amiről [itt](https://szamlazz.visztpeter.me/) olvashatsz. De a legfontosabb az E-Nyugta támogatás, amivel digitális termékeidet(letölthető könyvek, tanfolyamok, jegyek) számla helyett nyugtával is eladhatsz, így a vásárlódnak nem kell megadnia az összes személyes adatát(csak név + email). Továbbá 1 éves emailes support is jár hozzá.

= Hogyan lehet tesztelni a számlakészítést? =

A számlázz.hu-tól lehet kérni kapcsolat űrlapon keresztül, hogy állítsák át a fiókot Teszt üzemmódba, így lehet próbálgatni a számlakészítést.

= Teszt módban vagyok, de a számlaértesítő nem a vásárló emailcímére megy. =

A számlaértesítő teszt módban nem a vásárló emailcímére érkezik, hanem a számlázz.hu-n használt fiók emailcímére.

== Screenshots ==

1. Beállítások képernyő(WooCommerce / Beállítások)
2. Számlakészítés doboz a rendelés oldalon

== Changelog ==

= 3.2.1 =
* Átláthatóbb és bővebb kezelőfelület a fizetési módokhoz kapcsolódó beállításokhoz - megadható fizetési határidő külön-külön a fizetési módokhoz
* PRO verzióban elrejthető a szállítási cím a számlán
* PRO verzióban lehetőség van arra, hogy akciós termék esetén az eredeti árat feltüntesse a számlán a tétel megjegyzéseként
* Figyelmeztetés arra, ha kerekítési hibák lehetnek Számlázz.hu és WooCommerce között
* Automata városkitöltés irányítószám alapján javítva
* Apróbb admin felület design javítások

= 3.2 =
* PRO verzió aktiválás régi PHP verziókon javítva
* Ha a fizetés idejét eltárolta a rendelés(pl bankkártyás fizetésnél), akkor automatikusan ezt írja rá a jóváírás rögzítésekor(teljessítettnek jelöléskor) dátumnak
* A teljesítettnek jelöléshez tartozó filter át lett nevezve a rossz "wc_szamlazz_xml_dijbekero" névről "wc_szamlazz_xml_kifiz"-re
* Manuális számlakészítéskor is automatán megy a jóváírás rögzítése, ha be van kapcsolva(Automata teljesítettnek jelölés)
* PRO verzióban külön megadható, hogy céges rendelésnél papír vagy elektronikus számlát készítsen(ha volt megadva cégnév, akkor céges rendelés)

= 3.1.10 =
* Kupon áfakulcs javítás
* PHP 5.3 kompatibilitás(de ha lehet, inkább frissíts PHP 7-re)

= 3.1.9 =
* A kupon külön tételként is megjeleníthető a számlán levonásként
* Ha PRO felhasználó vagy, nem látszik feleslegesen a PRO felirat beállításoknál

= 3.1.8 =
* Variálható terméknél is megadható egyedi mennyiségi egység és tétel megjegyzés

= 3.1.7 =
* IPN üzenet esetén ha lezárja a rendelést, nem fog mégegy számlát készíteni feleslegesen, ha már számlázz.hu létrehozott egyet(pl Autokassza, vagy ha díjbekérőhöz manuálisan csinálsz számlát a számlázz.hu felületén)

= 3.1.6 =
* Adószám mező bugfix és az adószám mező a számlázási adatok végén jelenik meg, nem a legelején

= 3.1.5 =
* Kiírja adminfelületen, ha volt egy hibás automata számlakészítés
* Opcionálisan emailt küld, ha volt egy hibás automata számlakészítés

= 3.1.4 =
* Egy olyan hiba javítva, ami miatt összeakadhatott más WC bővítményekkel

= 3.1.3 =
* A számla megjegyzésben a {customer_email} kóddal megadható a vásárló email címe
* Beállítható, hogy cégnév megadása esetén is ráírja a vásárló rendes nevét is a számlára(sokszor előfordul, hogy "Nincs" van megadva cégnévnek)

= 3.1.2 =
* Szállítólevél készítés
* Kupon megjegyzés hibajavítás
* Új ikonok a rendelések táblázatban
* Képernyőképek frissítve
* Ikon és fejléc kép a wordpress.org-ra

= 3.1.1 =
* Vevő országának feltüntetése a számlán(csak akkor, ha nem Magyarország)

= 3.1.0 =
* Megadható, hogy melyik rendelés státusznál készítsen számlát
* Bővítmény törléskor letörli felesleges adatokat adatbázisból
* Hibajavítások

= 3.0.9 =
* Mennyiségi egység feltüntetése számlán
* A termék szerkesztésekor a Haladó fülön megadható extra leírás, ami a számla tétel leírásaként fog megjelenni
* A kupon által generált számlamegjegyzés nem írja felül az alap megjegyzést, csak kiegészíti

= 3.0.8 =
* WPML bugfix
* Polylang kompatibilitás
* WC 3.5 kompatibilitás

= 3.0.7 =
* Termékkép eltűnés bugfix

= 3.0.6 =
* Előleg számla bugfix

= 3.0.5 =
* WPML kompatibilitás - többnyelvű webshopnál a rendelés nyelve szerint fog számlát készíteni
* Irányítószám alapján város kitöltés automatán
* Díjbekérő helyett lehetőség van előlegszámlát csinálni

= 3.0.4 =
* E-Nyugta bugfix

= 3.0.3 =
* Bővítmény aktiválással kapcsolatos bugfix

= 3.0.2 =
* Számlák csatolhatók a gyári WooCommerce emailekhez, így nem fontos a számlaértesítőt használni
* Átláthatóbb beállítások oldal
* Ha IPN-en keresztül szól Számlázz.hu, akkor a rendelést lezárja automatikusan
* A szamlazz.hu jelszó megadható a wp_config.php fájlban is, így nem adatbázisban tárolja plain text-ként
* Adószám mező látszik akkor is, ha nincs 100.000 Ft felett az áfatartalom

= 3.0.1 =
* Release bugfix

= 3.0 =
* PRO verzió
* E-Nyugta támogatás
* Cserélhető kereszt- és vezetéknév
* Beállítható adókulcs(pl AAM)
* A beállítások átkerültek az Integráció menüpontba
* Deviza számlák készítése, számla nyelv módosítása

= 2.1.2 =
* Release bugfix

= 2.1.1 =
* WooCommerce 3.0+ kupon kezelés javítás. Mivel 3.0-tól kezdve már nem külön tételként számolja a kupont, így a számla megjegyzésben lesz ráírva, hogy mennyi volt az összes kedvezmény

= 2.1 =
* A díjbekérő készítés most fizetési módhoz van csatolva, egyszerre többet is ki lehet választani és automatán generálja őket
* Több fizetési módot is ki lehet választani az automata teljesítettnek jelölés opciónál
* Opcionálisan a vásárló Rendeléseim oldalán mutatja a díjbekérő és a számla linkeket minden rendelésnél
* Ki/be lehet kapcsolni az email értesítő küldését
* Ha nincs cURL bekapcolva, kiírja a hibát
* Javítva mégegy WooCommerce 3.0 kompatibilitás probléma

= 2.0 =
* WooCommerce 3.0 kompatibilitás(visszafele kompatibilis, tehát frissíthetsz akkor is, ha még régebbi WooCommerce-et használsz.)
* Sztornózni lehet számlát
* wc_szamlazz_after_invoice_success és wc_szamlazz_after_invoice_error action-nel lehet extra funkciókat futtatni sikeres és sikertelen számlakészítés után. Lásd leírásban segítséget.

= 1.2.2 =
* Akkor is lesz számla, ha a cégnévben & karakter van
* A wc_szamlazz_xml filterrel módosítható az eladó számlaszáma(külföldi rendelénél pl ne az alapértelmezett magyar számlát írja rá, hanem a devizát)

= 1.2.1 =
* 1.2-ben előjött bug lett javítva

= 1.2 =
* Számla teljesítettnek jelölése: manuálisan vagy számlakészítéskor automatán egy kiválasztott fizetési módnál
* Ha szamlazz.hu-n teljesítettnek jelölsz egy számlát, az áruházban is az lesz. (lásd beállítások fülön bővebb infót)

= 1.1.4 =
* Megadható az adószám, 100e ft feletti áfatartalomnál a vásárlás oldalon megjelenik az adószám mező(opcionális) és egy figyelmeztetés, hogy kötelező megadni, ha van.

= 1.1.3 =
* Variációs terméknél a megjegyzésben feltüntetésre kerül a kiválasztott variáció
* Manuális díjbekérő készítésekor jó a letöltés link(eddig frissíteni kellett egyet)
* Ha cégnév meg van adva, nem kerül rá a számlára a rendes név

= 1.1.2 =
* 0 Ft-os terméknél nem dob hibát
* Biztonsági hibajavítás - thx @csurga

= 1.1.1 =
* Teszt fiókkal is működik a számlakészítés

= 1.1 =
* WordPress.org-ra feltöltött plugin első verziója
