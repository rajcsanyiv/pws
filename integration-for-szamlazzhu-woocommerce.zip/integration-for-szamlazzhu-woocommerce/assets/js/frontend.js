jQuery(document).ready(function($) {

  $('input#nyugta').change(function(e) {
    e.preventDefault();

    //Set reload_checkout in session to reload the page
    var nonce = $(this).data('nonce');
    var nyugta = 'receipt';
    var $form = $('form.woocommerce-checkout');
    var billing_first_name = $('#billing_first_name').val();
    var billing_last_name = $('#billing_last_name').val();
    var billing_email = $('#billing_email').val();

    if($(this).is(":checked")) {
      nyugta = 'invoice';
    }

    var data = {
      action: 'wc_szamlazz_nyugta_check',
      nonce: wc_checkout_params.update_order_review_nonce,
      checked: nyugta,
      billing_first_name: billing_first_name,
      billing_last_name: billing_last_name,
      billing_email: billing_email
    };

    $form.addClass( 'processing' );
    $form.block({
      message: null,
      overlayCSS: {
        background: '#fff',
        opacity: 0.6
      }
    });

    $.post(wc_checkout_params.ajax_url, data, function(response) {

      window.location.reload();
      return;

    });

  });

  if(typeof wc_szamlazz_postcodes != 'undefined' && $('.woocommerce-checkout #billing_postcode').length) {
    var $postcodeField = $('.woocommerce-checkout #billing_postcode');
    var $cityField = $('.woocommerce-checkout #billing_city');
    var cityFieldTouched = false;

    $cityField.keyup(function(){
      cityFieldTouched = true;
    });

    $postcodeField.keyup(function(){
      var postcode = parseInt($postcodeField.val());
      var cityIndex = wc_szamlazz_postcodes.indexOf(postcode);
      var city = wc_szamlazz_cities[cityIndex];
      if($postcodeField.val().length == 4 && cityIndex > -1 && ($cityField.val() == '' || !cityFieldTouched) && wc_szamlazz_postcodes[cityIndex+1] != postcode) {
        $cityField.val(city);
      }
    });
  }

});
