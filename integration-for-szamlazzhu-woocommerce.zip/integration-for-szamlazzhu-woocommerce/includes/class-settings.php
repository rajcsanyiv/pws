<?php

if ( ! class_exists( 'WC_Szamlazz_Settings' ) ) :

class WC_Szamlazz_Settings extends WC_Integration {
	public static $activation_url;

	/**
	 * Init and hook in the integration.
	 */
	public function __construct() {
		$this->id                 = 'wc_szamlazz';
		$this->method_title       = __( 'Szamlazz.hu', 'wc-szamlazz' );
		$this->method_description = __( 'Nézd át az alábbi beállításokat ahhoz, hogy számlákat tudj generálni.', 'wc-szamlazz' );

		// Load the settings.
		$this->init_form_fields();
		$this->init_settings();

		// Define user set variables.
		$this->wc_szamlazz_pro_key = $this->get_option_stored( 'wc_szamlazz_pro_key' );
		$this->wc_szamlazz_username = $this->get_option_stored( 'wc_szamlazz_username' );
    $this->wc_szamlazz_password = $this->get_option_stored( 'wc_szamlazz_password' );
    $this->wc_szamlazz_invoice_type = $this->get_option_stored( 'wc_szamlazz_invoice_type' );
		$this->wc_szamlazz_invoice_type_company = $this->get_option_stored( 'wc_szamlazz_invoice_type_company' );
    $this->wc_szamlazz_payment_deadline = $this->get_option_stored( 'wc_szamlazz_payment_deadline' );
    $this->wc_szamlazz_note = $this->get_option_stored( 'wc_szamlazz_note' );
		$this->wc_szamlazz_cegnev = $this->get_option_stored( 'wc_szamlazz_cegnev' );
		$this->wc_szamlazz_coupon_type = $this->get_option_stored( 'wc_szamlazz_coupon_type' );
		$this->wc_szamlazz_discount_note = $this->get_option_stored( 'wc_szamlazz_discount_note' );
		$this->wc_szamlazz_hide_shipping_info = $this->get_option_stored( 'wc_szamlazz_hide_shipping_info' );
    $this->wc_szamlazz_auto_email = $this->get_option_stored( 'wc_szamlazz_auto_email' );
    $this->wc_szamlazz_auto = $this->get_option_stored( 'wc_szamlazz_auto' );
		$this->wc_szamlazz_auto_status = $this->get_option_stored( 'wc_szamlazz_auto_status' );
    $this->wc_szamlazz_debug = $this->get_option_stored( 'wc_szamlazz_debug' );
    $this->wc_szamlazz_vat_number_form = $this->get_option_stored( 'wc_szamlazz_vat_number_form' );
    $this->wc_szamlazz_vat_number_form_min = $this->get_option_stored( 'wc_szamlazz_vat_number_form_min' );
    $this->wc_szamlazz_vat_number_notice = $this->get_option_stored( 'wc_szamlazz_vat_number_notice' );
    $this->wc_szamlazz_auto_completes = $this->get_option_stored( 'wc_szamlazz_auto_completes' );
    $this->wc_szamlazz_payment_request_autos = $this->get_option_stored( 'wc_szamlazz_payment_request_autos' );
    $this->wc_szamlazz_customer_download = $this->get_option_stored( 'wc_szamlazz_customer_download' );
		$this->wc_szamlazz_afakulcs = $this->get_option_stored( 'wc_szamlazz_afakulcs' );
		$this->wc_szamlazz_elotag = $this->get_option_stored( 'wc_szamlazz_elotag' );
		$this->wc_szamlazz_nyelv = $this->get_option_stored( 'wc_szamlazz_nyelv' );
		$this->wc_szamlazz_nyelv_wpml = $this->get_option_stored( 'wc_szamlazz_nyelv_wpml' );
		$this->wc_szamlazz_eloleg = $this->get_option_stored( 'wc_szamlazz_eloleg' );
		$this->wc_szamlazz_nev_csere = $this->get_option_stored( 'wc_szamlazz_nev_csere' );
		$this->wc_szamlazz_nyugta = $this->get_option_stored( 'wc_szamlazz_nyugta' );
		$this->wc_szamlazz_nyugta_elotag = $this->get_option_stored( 'wc_szamlazz_nyugta_elotag' );
		$this->wc_szamlazz_nyugta_megjegyzes = $this->get_option_stored( 'wc_szamlazz_nyugta_megjegyzes' );
		$this->wc_szamlazz_nyugta_email = $this->get_option_stored( 'wc_szamlazz_nyugta_email' );
		$this->wc_szamlazz_nyugta_email_subject = $this->get_option_stored( 'wc_szamlazz_nyugta_email_subject' );
		$this->wc_szamlazz_nyugta_email_text = $this->get_option_stored( 'wc_szamlazz_nyugta_email_text' );
		$this->wc_szamlazz_nyugta_email_replyto = $this->get_option_stored( 'wc_szamlazz_nyugta_email_replyto' );
		$this->wc_szamlazz_attachment = $this->get_option_stored( 'wc_szamlazz_attachment' );
		$this->wc_szamlazz_ipn_close_order = $this->get_option_stored( 'wc_szamlazz_ipn_close_order' );
		$this->wc_szamlazz_iranyitoszam_auto = $this->get_option_stored( 'wc_szamlazz_iranyitoszam_auto' );
		$this->wc_szamlazz_szallitolevel = $this->get_option_stored( 'wc_szamlazz_szallitolevel' );
		$this->wc_szamlazz_error_email = $this->get_option_stored( 'wc_szamlazz_error_email' );
		$this->wc_szamlazz_payment_method_options = $this->get_option_stored( 'wc_szamlazz_payment_method_options' );

		// Migrate old settings
		$saved_values = get_option('wc_szamlazz_payment_method_options');

		//Migrate old values
		if(!$saved_values) {
			$saved_values = array();
			if($this->wc_szamlazz_auto_completes) {
				foreach ($this->wc_szamlazz_auto_completes as $payment_method_id) {
					$saved_values[$payment_method_id]['complete'] = true;
				}
			}

			if($this->wc_szamlazz_payment_request_autos) {
				foreach ($this->wc_szamlazz_payment_request_autos as $payment_method_id) {
					$saved_values[$payment_method_id]['request'] = true;
				}
			}

			foreach ($saved_values as $key => $saved_value) {
				$saved_values[$key]['deadline'] = $this->wc_szamlazz_payment_deadline;
				if(!isset($saved_values[$key]['complete'])) $saved_values[$key]['complete'] = false;
				if(!isset($saved_values[$key]['request'])) $saved_values[$key]['request'] = false;
			}

			update_option('wc_szamlazz_payment_method_options', $saved_values);
		}

		// Action to save the fields
		add_action( 'woocommerce_update_options_integration_' .  $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'woocommerce_update_options_integration_' .  $this->id, array( $this, 'save_payment_options' ) );

		//Check and save PRO version
		add_action( 'wp_ajax_wc_szamlazz_pro_check', array( $this, 'wc_szamlazz_pro_check' ) );
		add_action( 'wp_ajax_nopriv_wc_szamlazz_pro_check', array( $this, 'wc_szamlazz_pro_check' ) );
		add_action( 'wp_ajax_wc_szamlazz_pro_deactivate', array( $this, 'wc_szamlazz_pro_deactivate' ) );
		add_action( 'wp_ajax_nopriv_wc_szamlazz_pro_deactivate', array( $this, 'wc_szamlazz_pro_deactivate' ) );

		//Define activation url
		if(defined('PHP_MAJOR_VERSION') && PHP_MAJOR_VERSION < 7) {
			self::$activation_url = 'http://szamlazz.visztpeter.me/validate.php';
		} else {
			self::$activation_url = 'https://szamlazz.visztpeter.me/validate.php';
		}

	}

  //Function to get previously saved values in general settings page, which is stored simply in wp_options
  public function get_option_stored($key) {
		//If new value is not stored, check for the old one
		$value = '';
		if($this->get_option($key)) {
			$value = $this->get_option($key);
		} else if(get_option($key)) {
			$value = $this->get_option($key, get_option($key));
		}
		return $value;
  }

	/**
	 * Initialize integration settings form fields.
	 *
	 * @return void
	 */
	public function init_form_fields() {
		$disabled = false;
		$pro_icon = '';
		if(!get_option('_wc_szamlazz_pro_enabled')) {
			$disabled = true;
			$pro_icon = '<i class="wc_szamlazz_pro_label">PRO</i>';
		}

		$this->form_fields = array(
			'wc_szamlazz_pro_key' => array(
        'title'    => __( 'PRO verzió', 'wc-szamlazz' ),
  			'type'     => 'pro'
			),
			'wc_szamlazz_username' => array(
        'title'    => __( 'Email cím vagy bejelentkezési név', 'wc-szamlazz' ),
  			'type'     => 'text',
				'class'		 => 'teszt'
			),
			'wc_szamlazz_password' => array(
        'title'    => __( 'Jelszó', 'wc-szamlazz' ),
  			'type'     => 'password',
				'description'		 => __("A jelszó sima szövegként van tárolva az adatbázisban. Javasolt, hogy inkább a WordPress konfigurációs fájlába add meg, úgy biztonságosabb. Hagyd üresen ezt a mezőt és a wp-config.php fájlhoz add hozzá ezt a sort: <pre>define( 'WC_SZAMLAZZ_JELSZO', 'jelszavad' );</pre>", 'wc-szamlazz' )
			),
			'wc_szamlazz_section_invoice_settings' => array(
				'title' => __( 'Számla beállítások', 'wc-szamlazz' ),
				'type'  => 'title',
				'description'  => __( 'A számlával kapcsolatos alapértelmezett beállítások.', 'wc-szamlazz' ),
			),
			'wc_szamlazz_invoice_type' => array(
        'title'    => __( 'Számla típusa', 'wc-szamlazz' ),
  			'class'    => 'chosen_select',
  			'css'      => 'min-width:300px;',
  			'type'     => 'select',
  			'options'     => array(
  				'electronic'  => __( 'Elektronikus', 'wc-szamlazz' ),
  				'paper' => __( 'Papír', 'wc-szamlazz' )
  			)
			),
			'wc_szamlazz_invoice_type_company' => array(
        'title'    => __( 'Számla típusa céges rendelésnél', 'wc-szamlazz' ).$pro_icon,
				'disabled' => $disabled,
  			'class'    => 'chosen_select',
  			'css'      => 'min-width:300px;',
  			'type'     => 'select',
  			'options'     => array(
					'' => __( 'Alapértelmezett', 'wc-szamlazz' ),
  				'electronic'  => __( 'Elektronikus', 'wc-szamlazz' ),
  				'paper' => __( 'Papír', 'wc-szamlazz' )
  			),
				'desc_tip' => __( 'Céges rendelés esetén a számla típusa. A rendelés akkor céges, ha volt megadva cégnév.')
			),
			'wc_szamlazz_payment_deadline' => array(
        'title'    => __( 'Fizetési határidő(nap)', 'wc-szamlazz' ),
  			'type'     => 'number'
			),
			'wc_szamlazz_note' => array(
        'title'    => __( 'Megjegyzés', 'wc-szamlazz' ),
  			'type'     => 'text',
				'desc_tip' => __( 'A {customer_email} kóddal megjelenítheted a vásárló email címét a megjegyzésben')
			),
			'wc_szamlazz_afakulcs' => array(
				'type'		 => 'select',
				'disabled' => $disabled,
				'title'    => __( 'Áfakulcs', 'wc-szamlazz' ).$pro_icon,
				'options'  => array(
					'' => __( 'Alapértelmezett', 'wc-szamlazz' ),
					'TAM' => __( 'TAM', 'wc-szamlazz' ),
					'AAM' => __( 'AAM', 'wc-szamlazz' ),
					'EU' => __( 'EU', 'wc-szamlazz' ),
					'EUK' => __( 'EUK', 'wc-szamlazz' ),
					'MAA' => __( 'MAA', 'wc-szamlazz' ),
					'F.AFA' => __( 'F.AFA', 'wc-szamlazz' ),
					'ÁKK' => __( 'ÁKK', 'wc-szamlazz' ),
				),
				'desc_tip'     => __( 'Az áfakulcs, ami a számlán szerepelni fog. Alapértelmezetten százalékos értéket fog mutatni.', 'wc-szamlazz' ),
				'default'  => ''
			),
			'wc_szamlazz_elotag' => array(
				'disabled' => $disabled,
				'title'    => __( 'Számlaszám előtag', 'wc-szamlazz' ).$pro_icon,
				'type'     => 'text',
				'desc_tip' => __('A szamlazz.hu rendszerében a beállítások / előtagok menünpontban található lista valamelyik engedélyezett sorának számlaszám előtag értéke.', 'wc-szamlazz')
			),
			'wc_szamlazz_nyelv' => array(
				'disabled' => $disabled,
				'type'		 => 'select',
				'title'    => __( 'Számla nyelve', 'wc-szamlazz' ).$pro_icon,
				'options'  => array(
					'hu' => __( 'Magyar', 'wc-szamlazz' ),
					'de' => __( 'Német', 'wc-szamlazz' ),
					'en' => __( 'Angol', 'wc-szamlazz' ),
					'it' => __( 'Olasz', 'wc-szamlazz' ),
					'fr' => __( 'Francia', 'wc-szamlazz' ),
					'hr' => __( 'Horvát', 'wc-szamlazz' ),
					'ro' => __( 'Román', 'wc-szamlazz' ),
					'sk' => __( 'Szlovák', 'wc-szamlazz' ),
					'es' => __( 'Spanyol', 'wc-szamlazz' ),
					'pl' => __( 'Lengyel', 'wc-szamlazz' ),
					'cz' => __( 'Cseh', 'wc-szamlazz' ),
				),
				'default'  => 'hu'
			),
			'wc_szamlazz_nyelv_wpml' => array(
				'disabled' => $disabled,
				'title'    => __( 'WPML és Polylang kompatibilitás', 'wc-szamlazz' ).$pro_icon,
				'type'     => 'checkbox',
				'desc_tip' => __('Ha be van kapcsolva, akkor a WPML vagy a Polylang által a rendelés adataiban tárolt nyelvkódot fogja használja a számla létrehozásához', 'wc-szamlazz')
			),
			'wc_szamlazz_eloleg' => array(
				'disabled' => $disabled,
				'title'    => __( 'Díjbekérő helyett előlegszámla', 'wc-szamlazz' ).$pro_icon,
				'type'     => 'checkbox',
				'desc_tip' => __('Ha be van kapcsolva, akkor a díjbekérő helyett előlegszámlát készít', 'wc-szamlazz')
			),
			'wc_szamlazz_mennyisegi_egyseg' => array(
				'disabled' => $disabled,
				'title'    => __( 'Mennyiségi egység', 'wc-szamlazz' ).$pro_icon,
				'type'     => 'text',
				'desc_tip' => __('Ez lesz az alapértelmezett mennyiségi egység a számlán a tételeknél, például "db". A termék szerkesztésekor a Haladó fülön megadható egyedi mennyiségi egység külön-külön minden termékhez.', 'wc-szamlazz')
			),
			'wc_szamlazz_cegnev' => array(
				'disabled' => $disabled,
				'title'    => __( 'Cégnév + név', 'wc-szamlazz' ).$pro_icon,
				'type'     => 'checkbox',
				'desc_tip' => __('Ha be van kapcsolva és vásárláskor cégnév van megadva, a vásárló nevét is feltünteti egy kötőjellel a cégnév után a számlán.', 'wc-szamlazz')
			),
			'wc_szamlazz_coupon_type' => array(
				'disabled' => $disabled,
				'title'    => __( 'Kupon külön tételként', 'wc-szamlazz' ).$pro_icon,
				'type'     => 'checkbox',
				'desc_tip' => __('Ha be van kapcsolva, akkor a rendeléshez használt kupont külön tételként tünteti fel a számlán, a vásárolt tételeknél pedig az eredeti árat fogja mutatni, nem a kedvezménnyel levontat.', 'wc-szamlazz')
			),
			'wc_szamlazz_discount_note' => array(
				'disabled' => $disabled,
				'title'    => __( 'Akciós termék megjegyzés', 'wc-szamlazz' ).$pro_icon,
				'type'     => 'text',
				'desc_tip' => __('A tétel megjegyzésében fel tudod tüntetni az eredeti árat és a kedvezmény mértékét. Használd ezeket a helyettesítőket: {eredeti_ar}, {kedvezmeny_merteke}, {kedvezmenyes_ar}', 'wc-szamlazz')
			),
			'wc_szamlazz_hide_shipping_info' => array(
				'disabled' => $disabled,
				'title'    => __( 'Szállítási adatok elrejtése', 'wc-szamlazz' ).$pro_icon,
				'type'     => 'checkbox',
				'desc_tip' => __('Ha be van kapcsolva, akkor nem tüntetni fel a vásárló szállítási címét a számlán, csak a számlázásit.', 'wc-szamlazz')
			),
			'wc_szamlazz_section_automatic' => array(
				'title' => __( 'Automatizálás', 'wc-szamlazz' ),
				'type'  => 'title',
				'description'  => __( 'Számlakészítés automatizálásával kapcsolatos beállítások. Ha az adott fizetési módnál a teljesítettnek jelölés be van pipálva, akkor a rendelés teljesítettnek jelölésekor automatikusan kifizetettnek jelöli meg a számlát. Ha a díjbekérő be van pipálva, akkor a rendelés létrehozásakor díjbekérőt is készít. A határidő minden fizetési módhoz egyedileg beállítható(az alapértelmezett érték a fenti beállításokban van).', 'wc-szamlazz' ),
			),
			'wc_szamlazz_auto' => array(
        'title'    => __( 'Automata számlakészítés', 'wc-szamlazz' ),
  			'type'     => 'checkbox',
  			'desc_tip'     => __( 'Ha be van kapcsolva, akkor a rendelés lezárásakor automatán kiállításra kerül a számla és a szamlazz.hu elküldi a vásárló email címére.', 'wc-szamlazz' ),
			),
			'wc_szamlazz_auto_status' => array(
				'type' => 'select',
				'title' => __( 'Számlakészítés státusznál', 'wc-szamlazz' ),
				'class' => 'wc-enhanced-select',
				'default' => 'wc-completed',
				'options'  => wc_get_order_statuses(),
				'desc_tip' => __( 'Ha a rendelés ebbe a státuszba kerül, akkor fogja automatán megcsináni a számlát(csak ha az automata számlakészítés be van kapcsolva). ', 'wc-szamlazz' ),
			),
			'wc_szamlazz_auto_email' => array(
				'title'    => __( 'Számlaértesítő', 'wc-szamlazz' ),
				'type'     => 'checkbox',
				'desc_tip'     => __( 'Ha be van kapcsolva, akkor a vásárlónak a szamlazz.hu kiküldi a számlaértesítőt automatán.', 'wc-szamlazz' ),
				'default'  => 'yes'
			),
			'wc_szamlazz_payment_methods' => array(
				'title'    => __( 'Fizetési módok', 'wc-szamlazz' ),
				'type'     => 'payment_methods'
			),
			'wc_szamlazz_ipn_url' => array(
				'title'    => __( 'Szamlazz.hu IPN Url', 'wc-szamlazz' ).$pro_icon,
				'type'     => 'ipn',
				'disabled' => $disabled,
				'default'  => $this->get_ipn_url(),
				'custom_attributes' => array(
					'readonly' => 'readonly'
				),
				'description'     => __( 'Van lehetőség arra, hogy egy számla kifizetettségéről értesítést kapjon a webáruház (vagy egyéb üzleti alkalmazás). Ezt az üzenetet a Számlázz.hu küldi egy meghatározott webcímre. Az URL megadható a számlakibocsátó fiókban <a href="https://www.szamlazz.hu/szamla/?action=directlogin&targetpage=beallitasokstep4" target="_blank">ezen</a> az oldalon.', 'wc-szamlazz' )
			),
			'wc_szamlazz_ipn_close_order' => array(
				'title'    => __( 'Rendelés lezárása IPN alapján', 'wc-szamlazz' ).$pro_icon,
				'type'     => 'checkbox',
				'disabled' => $disabled,
				'desc_tip'     => __( 'Ha a Számlázz.hu IPN-en keresztül szól, hogy ki lett egyenlítve a számla, akkor a rendelést automatikusan lezárja(ha még nem volt).', 'wc-szamlazz' ),
				'default'  => 'yes'
			),
			'wc_szamlazz_szallitolevel' => array(
				'disabled' => $disabled,
				'title'    => __( 'Szállítólevél számla mellé', 'wc-szamlazz' ).$pro_icon,
				'type'     => 'checkbox',
				'desc_tip' => __('Ha be van kapcsolva, akkor a számla mellé automatán elkészül a szállítólevél is', 'wc-szamlazz')
			),
			'wc_szamlazz_section_vat_number' => array(
				'title' => __( 'Adószám', 'wc-szamlazz' ),
				'type'  => 'title',
				'description'  => __( '100.000 Ft áfatartalomnál magasabb rendeléseknél kötelező adószámot bekérni, ha van a vevőnek. Az alábbi opciókkal egy adószám mezőt lehet hozzáadni a pénztár űrlaphoz.', 'wc-szamlazz' ),
			),
			'wc_szamlazz_vat_number_form' => array(
        'title'    => __( 'Adószám mező vásárláskor', 'wc-szamlazz' ),
  			'type'     => 'checkbox',
  			'desc_tip'     => __( 'A számlázási adatok alján egy új mezőben lesz bekérve. Eltárolja a rendelés adataiban, illetve számlára is ráírja. Ha kézzel kell megadni utólag a rendeléskezelőben, akkor az egyedi mezőknél az "adoszam" mezőt kell kitölteni.', 'wc-szamlazz' ),
			),
			'wc_szamlazz_vat_number_form_min' => array(
        'title'    => __( 'Csak 100.000 Ft áfa felett', 'wc-szamlazz' ),
  			'type'     => 'checkbox',
  			'desc_tip'     => __( 'Az adószám mező csak akkor látszik, ha 100.000 Ft felett van az áfatartalom.', 'wc-szamlazz' ),
			),
			'wc_szamlazz_vat_number_notice' => array(
				'title'    => __( 'Adószám figyelmeztetés', 'wc-szamlazz' ),
				'type'     => 'textarea',
				'default'	 => __( 'A vásárlás áfatartalma több, mint 100.000 Ft, ezért amennyiben rendelkezik adószámmal, azt kötelező megadni a számlázási adatoknál.', 'wc-szamlazz'),
				'desc_tip'     => __( 'Ez az üzenet jelenik meg, ha az adószám mező be van pipálva felül a fizetés oldalon és 100.000 Ft felett van az áfatartalom.', 'wc-szamlazz' ),
			),
			'wc_szamlazz_section_nyugta' => array(
				'title' => __( 'E-Nyugta', 'wc-szamlazz' ).$pro_icon,
				'type'  => 'title',
				'description'  => __( 'Ebben a szekcióban találod az E-Nyugta készítéshez szükséges beállításokat. Ezzel az opcióval a pénztár oldalon a vásárlónak csak a nevét és email címét kell megadnia és a vásárlásról nyugta készül, amit emailben kap meg a vásárló. Ideális jegyvásárláshoz, digitális termékekhez. Könyvelővel célszerű egyeztetni, megfelel e ez a megoldás. Ha a vásárló szeretne számlát kérni, akkor megadhatja a számlzási adatait is.', 'wc-szamlazz' ),
			),
			'wc_szamlazz_nyugta' => array(
				'disabled' => $disabled,
				'title'    => __( 'E-Nyugta', 'wc-szamlazz' ),
				'type'     => 'checkbox',
			),
			'wc_szamlazz_nyugta_elotag' => array(
				'title'    => __( 'Nyugtaszám előtag', 'wc-szamlazz' ),
				'type'     => 'text'
			),
			'wc_szamlazz_nyugta_megjegyzes' => array(
				'title'    => __( 'Nyugta megjegyzés', 'wc-szamlazz' ),
				'type'     => 'text',
				'description' => __( 'Általános szöveges megjegyzés, nyugtán megjelenik', 'wc-szamlazz' )
			),
			'wc_szamlazz_nyugta_email' => array(
				'title'    => __( 'Nyugta kiküldés', 'wc-szamlazz' ),
				'type'     => 'checkbox',
				'desc_tip'     => __( 'A Számlázz.hu Agent nyugtaküldő interfésze a szükséges adatok beérkezése után a hivatkozott nyugtát kiküldni a címzett e-mail címére. Nincs csatolt fájl küldés, a nyugta adatait a levéltörzsben jeleníti meg.', 'wc-szamlazz' ),
			),
			'wc_szamlazz_nyugta_email_subject' => array(
				'title'    => __( 'Nyugta email tárgy', 'wc-szamlazz' ),
				'type'     => 'text',
				'default'  => __( 'Nyugta', 'wc-szamlazz' )
			),
			'wc_szamlazz_nyugta_email_text' => array(
				'title'    => __( 'Nyugta email szöveg', 'wc-szamlazz' ),
				'type'     => 'textarea'
			),
			'wc_szamlazz_nyugta_email_replyto' => array(
				'title'    => __( 'Nyugta email cím', 'wc-szamlazz' ),
				'type'     => 'text',
				'desc_tip'     => __( 'Ha valaki válaszol az emailre, erre a címre érkezik a válasz(reply-to)', 'wc-szamlazz' ),
			),
			'wc_szamlazz_section_other' => array(
				'title' => __( 'Egyéb beállítások', 'wc-szamlazz' ),
				'type'  => 'title'
			),
			'wc_szamlazz_customer_download' => array(
				'title'    => __( 'Számlák a profilban', 'wc-szamlazz' ),
				'type'     => 'checkbox',
				'desc_tip'     => __( 'Ha be van kapcsolva, akkor a díjbekérőt és a számlát is le tudja tölteni a felhasználó belépés után, a Rendeléseim menüben.', 'wc-szamlazz' ),
				'default'  => 'no'
			),
			'wc_szamlazz_attachment' => array(
				'disabled' => $disabled,
				'title'    => __( 'Számla és nyugta csatolása rendelés emailekhez', 'wc-szamlazz' ).$pro_icon,
				'type'     => 'checkbox',
				'desc_tip'     => __( 'A számlák és nyugták a WooCommerce által kiküldött emailekhez is csatolva lesznek. Érdemes ilyenkor a számlaértesítőt kikapcsolni. A Rendelés feldolgozása/Megrendelés fizetésre vár emailhez csatolja a díjbekérőt(ha van), a Teljesített rendelés/Vásárlói számla/Rendelési adatok emailhez az elkészült számlát, a Visszamondott/Visszatérített emailekhez pedig a sztornó számlát.', 'wc-szamlazz' ),
			),
			'wc_szamlazz_nev_csere' => array(
				'disabled' => $disabled,
				'title'    => __( 'Vezetéknév / keresztnév csere', 'wc-szamlazz' ).$pro_icon,
				'type'     => 'checkbox',
				'desc_tip'     => __( 'Ha rosszul jelenik meg a számlán a vevő neve, ezzel az opcióval meg lehet cserélni a vezetéknevet és a keresztnevet.', 'wc-szamlazz' ),
			),
			'wc_szamlazz_debug' => array(
        'title'    => __( 'Fejlesztői mód', 'wc-szamlazz' ),
  			'type'     => 'checkbox',
  			'desc_tip' => __( 'Ha be van kapcsolva, akkor a szamlazz.hu részére generált XML fájl nem lesz letörölve, teszteléshez használatos opció. Az XML fájlok a wp-content/uploads/wc_szamlazz/ mappában vannak, fájlnév a rendelés száma.', 'wc-szamlazz' ),
			),
			'wc_szamlazz_iranyitoszam_auto' => array(
				'disabled' => $disabled,
				'title'    => __( 'Város kitöltése irányítószám alapján', 'wc-szamlazz' ).$pro_icon,
				'type'     => 'checkbox',
				'desc_tip'     => __( 'Ha be van kapcsolva, akkor az irányítószám megadásakor automatán kitölti a város mezőt.', 'wc-szamlazz' ),
			),
			'wc_szamlazz_error_email' => array(
				'disabled' => $disabled,
				'title'    => __( 'Email cím hibajelzéshez', 'wc-szamlazz' ).$pro_icon,
				'type'     => 'text',
				'desc_tip'     => __( 'Ha megadsz egy email címet, akkor ide küld a rendszer egy levelet, ha volt a webáruházban egy sikertelen automata számlakészítés. Hagyd üresen, ha nem szeretnél emailt kapni(a számlázz.hu is szokott küldeni).', 'wc-szamlazz' ),
			)
		);
	}

	//Get IPN url
	public function get_ipn_url() {
		$url = '';
		if(get_option('_wc_szamlazz_pro_enabled')) {
			add_option( 'wc_szamlazz_ipn_url', substr(md5(rand()),5)); //this will only store it if doesn't exists yet
			$url = home_url( '?wc_szamlazz_ipn_url=' ).get_option('wc_szamlazz_ipn_url');
		}
		return $url;
	}

  //Get payment methods
  public function get_payment_methods() {
    $available_gateways = WC()->payment_gateways->payment_gateways();
		$payment_methods = array();
		foreach ($available_gateways as $available_gateway) {
			if($available_gateway->enabled == 'yes') {
				$payment_methods[$available_gateway->id] = $available_gateway->title;
			}
		}
    return $payment_methods;
  }

	public function generate_ipn_html( $key, $data ) {
		$field_key = $this->get_field_key( $key );
		$defaults  = array(
			'title'             => '',
			'disabled'          => false,
			'class'             => '',
			'css'               => '',
			'placeholder'       => '',
			'type'              => 'text',
			'desc_tip'          => false,
			'description'       => '',
			'custom_attributes' => array(),
		);

		$data = wp_parse_args( $data, $defaults );

		ob_start();
		?>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<label for="<?php echo esc_attr( $field_key ); ?>"><?php echo wp_kses_post( $data['title'] ); ?> <?php echo $this->get_tooltip_html( $data ); ?></label>
			</th>
			<td class="forminp">
				<fieldset>
					<legend class="screen-reader-text"><span><?php echo wp_kses_post( $data['title'] ); ?></span></legend>
					<input class="input-text regular-input" type="text" value="<?php echo esc_attr( $this->get_ipn_url() ); ?>" <?php disabled( $data['disabled'], true ); ?> <?php echo $this->get_custom_attribute_html( $data ); ?> />
					<?php echo $this->get_description_html( $data ); ?>
				</fieldset>
			</td>
		</tr>
		<?php
		return ob_get_clean();
	}

	public function generate_pro_html( $key, $data ) {
		$field    = $this->plugin_id . $this->id . '_' . $key;
		$defaults = array(
			'class'             => 'button-secondary',
			'css'               => '',
			'custom_attributes' => array(),
			'desc_tip'          => false,
			'description'       => '',
			'title'             => '',
		);
		$data = wp_parse_args( $data, $defaults );
		ob_start();
		?>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<label for="<?php echo esc_attr( $field ); ?>"><?php echo wp_kses_post( $data['title'] ); ?></label>
				<?php echo $this->get_tooltip_html( $data ); ?>
			</th>
			<td class="forminp">
				<fieldset>
					<?php if(get_option('_wc_szamlazz_pro_enabled')): ?>
						<div class="wc_szamlazz_pro_version_active"><span class="dashicons dashicons-yes"></span> <?php _e('PRO verzió aktív', 'wc-szamlazz'); ?></div>
						<p><?php _e('Kulcs:', 'wc-szamlazz'); ?> <?php echo get_option('_wc_szamlazz_pro_key'); ?></p>
						<p><?php _e('Email:', 'wc-szamlazz'); ?> <?php echo get_option('_wc_szamlazz_pro_email'); ?></p>
					<?php else: ?>
						<input class="input-text regular-input" type="text" name="woocommerce_wc_szamlazz_pro_key" id="woocommerce_wc_szamlazz_pro_key" value="" placeholder="Termékkulcs"><br>
						<input class="input-text regular-input" type="text" name="woocommerce_wc_szamlazz_pro_email" id="woocommerce_wc_szamlazz_pro_email" value="" placeholder="Vásárláshoz használt email cím">
					<?php endif; ?>
					<p>
						<?php if(get_option('_wc_szamlazz_pro_enabled')): ?>
							<button class="button-secondary" type="button" name="<?php echo esc_attr( $field ); ?>-deactivate" id="<?php echo esc_attr( $field ); ?>-deactivate"><?php _e('Deaktiválás', 'wc-szamlazz'); ?></button>
						<?php else: ?>
							<button class="button-primary" type="button" name="<?php echo esc_attr( $field ); ?>" id="<?php echo esc_attr( $field ); ?>"><?php _e('Aktiválás', 'wc-szamlazz'); ?></button>
						<?php endif; ?>
					</p>
					<?php if(!get_option('_wc_szamlazz_pro_enabled')): ?>
						<p class="description"><?php _e('A PRO verzió aktiválása a termékkulcssal, amit <a href="https://szamlazz.visztpeter.me" target="_blank">itt</a> tudsz megvenni.', 'wc-szamlazz'); ?></p>
					<?php endif; ?>
					<div class="notice notice-error inline" style="display:none;"><p></p></div>
				</fieldset>
			</td>
		</tr>
		<?php
		return ob_get_clean();
	}

	public function wc_szamlazz_pro_check() {

		if ( !current_user_can( 'edit_shop_orders' ) )  {
			wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
		}
		$pro_key = $_POST['key'];
		$pro_email = $_POST['email'];

		$args = array(
			'request'     => 'activation',
			'license_key' => $pro_key,
			'email'			  => $pro_email
		);

		$base_url = WC_Szamlazz_Settings::$activation_url;
		$target_url = $base_url . '?' . http_build_query( $args );
		$data = wp_remote_get( $target_url );
		$data = json_decode( $data['body'] );

		if(isset($data->error)) {
			wp_send_json_error(array(
				'message' => __('Nem sikerült az aktiválás, kérlek ellenőrizd az adatok helyességét.', 'wc-szamlazz')
			));
		} else {

			//Store the key and email
			update_option('_wc_szamlazz_pro_key', $pro_key);
			update_option('_wc_szamlazz_pro_email', $pro_email);
			update_option('_wc_szamlazz_pro_enabled', true);

			wp_send_json_success();
		}

	}

	public function wc_szamlazz_pro_deactivate() {

		if ( !current_user_can( 'edit_shop_orders' ) )  {
			wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
		}
		$pro_key = get_option('_wc_szamlazz_pro_key');
		$pro_email = get_option('_wc_szamlazz_pro_email');

		$args = array(
			'request'     => 'activation_reset',
			'license_key' => $pro_key,
			'email'			  => $pro_email,
		);

		$base_url = WC_Szamlazz_Settings::$activation_url;
		$target_url = $base_url . '?' . http_build_query( $args );

		$data = wp_remote_get( $target_url );
		$data = json_decode( $data['body'] );

		if(isset($data->error)) {
			wp_send_json_error(array(
				'message' => __('Nem sikerült a deaktiválás, kérlek ellenőrizd az adatok helyességét.', 'wc-szamlazz')
			));
		} else {

			//Store the key and email
			delete_option('_wc_szamlazz_pro_key');
			delete_option('_wc_szamlazz_pro_email');
			delete_option('_wc_szamlazz_pro_enabled');

			wp_send_json_success();
		}

	}

	public function generate_payment_methods_html() {
		ob_start();

		$payment_methods = $this->get_payment_methods();
		$saved_values = get_option('wc_szamlazz_payment_method_options');

		?>
		<tr valign="top">
			<th scope="row" class="titledesc"><?php esc_html_e( 'Fizetési módok:', 'woocommerce' ); ?></th>
			<td class="forminp">
				<div class="wc_input_table_wrapper">
					<table class="widefat wc_input_table" cellspacing="0">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Fizetési mód', 'woocommerce' ); ?></th>
								<th><?php esc_html_e( 'Fizetési határidő(nap)', 'woocommerce' ); ?></th>
								<th><?php esc_html_e( 'Teljesítettnek jelölés', 'woocommerce' ); ?></th>
								<th><?php esc_html_e( 'Díjbekérő létrehozása', 'woocommerce' ); ?></th>
							</tr>
						</thead>
						<tbody class="wc_szamlazz_settings_payment_methods">
							<?php foreach ( $payment_methods as $payment_method_id => $payment_method ): ?>
								<?php
								if($saved_values && $saved_values[esc_attr( $payment_method_id )]) {
									$value_deadline = esc_attr( $saved_values[esc_attr( $payment_method_id )]['deadline']);
									$value_complete = $saved_values[esc_attr( $payment_method_id )]['complete'];
									$value_request = $saved_values[esc_attr( $payment_method_id )]['request'];
								} else {
									$value_deadline = '';
									$value_complete = false;
									$value_request = false;
								}
								?>
								<tr>
									<td><strong><?php echo $payment_method; ?></strong></td>
									<td><input type="number" name="wc_szamlazz_payment_options[<?php echo esc_attr( $payment_method_id ); ?>][deadline]" value="<?php echo $value_deadline; ?>" /></td>
									<td><input type="checkbox" name="wc_szamlazz_payment_options[<?php echo esc_attr( $payment_method_id ); ?>][complete]" value="1" <?php checked( $value_complete ); ?> /></td>
									<td><input type="checkbox" name="wc_szamlazz_payment_options[<?php echo esc_attr( $payment_method_id ); ?>][request]" value="1" <?php checked( $value_request ); ?> /></td>
								</tr>
							<?php endforeach ?>
						</tbody>
					</table>
				</div>
			</td>
		</tr>
		<?php
		return ob_get_clean();

	}

	public function save_payment_options() {
		$accounts = array();

		if ( isset( $_POST['wc_szamlazz_payment_options'] ) ) {

			foreach ($_POST['wc_szamlazz_payment_options'] as $payment_method_id => $payment_method) {
				$deadline = wc_clean($payment_method['deadline']);
				$complete = isset($payment_method['complete']) ? true : false;
				$request = isset($payment_method['request']) ? true : false;

				$accounts[$payment_method_id] = array(
					'deadline' => $deadline,
					'complete' => $complete,
					'request'  => $request
				);
			}

		}

		update_option( 'wc_szamlazz_payment_method_options', $accounts );
	}

}

endif;
