<?php
/**
 * Admin View: Notice - Welcome
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div class="notice notice-error wc-szamlazz-notice">
	<p>A <strong>WooCommerce + Szamlazz.hu</strong> bővítmény használatához a cURL funkció szükséges és úgy néz ki, ezen a tárhelyen nincs bekapcsolva. Ha nem tudod mi ez, kérd meg a tárhelyszolgáltatót, hogy kapcsolják be.</p>
</div>
