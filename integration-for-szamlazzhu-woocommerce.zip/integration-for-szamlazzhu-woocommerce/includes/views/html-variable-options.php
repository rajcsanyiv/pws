<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<div>
  <?php
	woocommerce_wp_text_input( array(
		'id' => 'wc_szamlazz_mennyisegi_egyseg[' . $loop . ']',
		'label' => __('Mennyiségi egység', 'wc-szamlazz'),
    'placeholder' => __('db', 'wc-szamlazz'),
    'desc_tip' => true,
		'value' => get_post_meta( $variation->ID, 'wc_szamlazz_mennyisegi_egyseg', true ),
		'description' => __('A Számlázz.hu által generált számlán a tételnél feltüntetett mennyiségi egység. Az alapértelmezett értéket a bővítmény beállításokban tudod beállítani.', 'wc-szamlazz')
	));

	woocommerce_wp_text_input( array(
		'id' => 'wc_szamlazz_megjegyzes[' . $loop . ']',
		'label' => __('Tétel megjegyzés', 'wc-szamlazz'),
    'desc_tip' => true,
		'value' => get_post_meta( $variation->ID, 'wc_szamlazz_megjegyzes', true ),
		'description' => __('A Számlázz.hu által generált számlán a tételnél feltüntetett megjegyzés.', 'wc-szamlazz')
	));
  ?>
</div>
