<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div class="notice notice-error wc-szamlazz-notice wc-szamlazz-welcome">
	<div class="wc-szamlazz-welcome-body">
    <button type="button" class="notice-dismiss wc-szamlazz-hide-notice" data-nonce="<?php echo wp_create_nonce( 'wc-szamlazz-hide-notice' )?>" data-notice="error"><span class="screen-reader-text"><?php _e( 'Dismiss' ); ?></span></button>
		<h2>Sikertelen számlakészítés</h2>
		<p><?php printf( esc_html__( 'A #%s sorszámú rendeléshez tartozó számlát nem sikerült valamiért létrehozni automatikusan. A rendelés jegyzetekben látod a pontos hibát.', 'wc-szamlazz' ), $order_number ); ?></p>
		<p>
			<a class="button-secondary" href="<?php echo $order_link; ?>"><?php _e( 'Rendelés adatai', 'wc-szamlazz' ); ?></a>
		</p>
	</div>
</div>
