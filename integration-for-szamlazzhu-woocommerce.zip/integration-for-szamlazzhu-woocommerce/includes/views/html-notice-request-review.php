<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div class="notice notice-info wc-szamlazz-notice wc-szamlazz-request-review">
	<p>⭐️ <?php printf( __( 'Szia! Tetszik a %sWooCommerce Számlázz.hu%s bővítmény? Kérlek, értékeld a WordPress.org-on. Csak egy perc az egész. Köszönöm!', 'wc-szamlazz' ), '<strong>', '</strong>' ); ?></p>
	<p>
		<a class="button-primary" target="_blank" rel="noopener noreferrer" href="https://wordpress.org/support/plugin/integration-for-szamlazzhu-woocommerce/reviews/?filter=5#new-post"><?php _e( 'Igen, értékelem!', 'wc-szamlazz' ); ?></a>
		<a class="button-secondary wc-szamlazz-hide-notice remind-later" data-nonce="<?php echo wp_create_nonce( 'wc-szamlazz-hide-notice' )?>" data-notice="request_review" href="#"><?php _e( 'Emlékeztess később', 'wc-szamlazz' ); ?></a>
		<a class="button-secondary wc-szamlazz-hide-notice" data-nonce="<?php echo wp_create_nonce( 'wc-szamlazz-hide-notice' )?>" data-notice="request_review" href="#"><?php _e( 'Nem, köszi', 'wc-szamlazz' ); ?></a>
	</p>
</div>
