<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div class="notice notice-info wc-szamlazz-notice wc-szamlazz-welcome">
	<div class="wc-szamlazz-welcome-body">
    <button type="button" class="notice-dismiss wc-szamlazz-hide-notice" data-nonce="<?php echo wp_create_nonce( 'wc-szamlazz-hide-notice' )?>" data-notice="welcome"><span class="screen-reader-text"><?php _e( 'Dismiss' ); ?></span></button>
		<h2>WooCommerce + Szamlazz.hu PRO</h2>
		<p>Köszönöm, hogy telepítetted a bővítményt. Ha esetleg nem tudnád, van egy PRO verziója is, amivel sokkal több funkciót érhetsz el, például E-Nyugta készítés, deviza számlák, WPML támogatás és 1 éves support. A bővítmény használatához a beállításokban add meg a számlázással kapcsolatos adataidat.</p>
		<p>
			<a class="button-primary" target="_blank" rel="noopener noreferrer" href="https://visztpeter.me/szamlazz/"><?php _e( 'PRO verzió vásárlása', 'woocommerce' ); ?></a>
			<a class="button-secondary" href="<?php echo admin_url( wp_nonce_url('admin.php?page=wc-settings&tab=integration&section=wc_szamlazz&welcome=1', 'wc-szamlazz-hide-notice' ) ); ?>"><?php _e( 'Beállítások', 'woocommerce' ); ?></a>
		</p>
	</div>
</div>
