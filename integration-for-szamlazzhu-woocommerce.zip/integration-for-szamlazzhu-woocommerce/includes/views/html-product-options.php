<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<div class="options_group hide_if_variable hide_if_grouped">
  <?php
  woocommerce_wp_text_input(array(
    'id' => 'wc_szamlazz_mennyisegi_egyseg',
    'label' => __('Mennyiségi egység', 'wc-szamlazz'),
    'placeholder' => __('db', 'wc-szamlazz'),
    'desc_tip' => true,
    'value' => esc_attr( $post->wc_szamlazz_mennyisegi_egyseg ),
    'description' => __('A Számlázz.hu által generált számlán a tételnél feltüntetett mennyiségi egység. Az alapértelmezett értéket a bővítmény beállításokban tudod beállítani.', 'wc-szamlazz')
  ));
  ?>
  <?php
  woocommerce_wp_text_input(array(
    'id' => 'wc_szamlazz_megjegyzes',
    'label' => __('Tétel megjegyzés', 'wc-szamlazz'),
    'desc_tip' => true,
    'value' => esc_attr( $post->wc_szamlazz_megjegyzes ),
    'description' => __('A Számlázz.hu által generált számlán a tételnél feltüntetett megjegyzés.', 'wc-szamlazz')
  ));
  ?>
</div>
