<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div class="notice notice-error wc-szamlazz-notice wc-szamlazz-welcome">
	<div class="wc-szamlazz-welcome-body">
    <button type="button" class="notice-dismiss wc-szamlazz-hide-notice" data-nonce="<?php echo wp_create_nonce( 'wc-szamlazz-hide-notice' )?>" data-notice="rounding"><span class="screen-reader-text"><?php _e( 'Dismiss' ); ?></span></button>
		<h2>Gondok lehetnek a kerekítéssel</h2>
		<p>A WooCommerce-ben jelenleg az árakat nettóban adtad meg. Javasolt, hogy a bruttó, kerekített árak legyenek megadva inkább, mert a WooCommerce és a Számlázz.hu máshogy működik.</p>
		<p>Előbbi a rendelés végösszegét kerekíti egész számra, utóbbi pedig a tételeket egyesével, így előfordulhat a számla és a rendelés végösszege között 1-2 forintos eltérés.</p>
		<p>Például ha van két tétel a rendelésben, amelyeknek a bruttó ára 100,25 Ft, akkor:</p>
		<ul>
			<li>A WooCommerce így kerekít: 100,25 + 100,25 = 200,5 -> 201 Ft</li>
			<li>A Számlázz.hu pedig így: 100,25 + 100,25 = 200 Ft</li>
		</ul>
		<p>Ha a bruttó kerek értéket adod meg, akkor azt soha nem kell kerekíteni, így mindig egyforma lesz a rendelés és a számla végösszege.</p>
	</div>
</div>
