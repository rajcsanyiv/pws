<?php
/*
Plugin Name: Product runout
Description: Product runout
Version: 1.0
Author: Viktor Rajcsányi / Promera
Author URI: http://promera.hu
Text Domain: runout
Domain Path: /languages/
*/

if ( ! defined( 'WPINC' ) ){
    die('Permission denied');
}

register_activation_hook( __FILE__, 'runout_install' );
register_activation_hook( __FILE__, 'runout_install_data' );

global $runout_db_version;
$runout_db_version = '1.0';

/**
 * Első indításnál létrehozza a plusz adatbázis táblát
 * 
 *
 */
function runout_install() {
    global $wpdb;
    global $runout_db_version;

    $table_name = $wpdb->prefix . 'runout';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
	id mediumint(9) NOT NULL AUTO_INCREMENT,
	customerid bigint(20),
	productid bigint(20),
        days int(11),
	time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
	status tinytext NOT NULL,
	PRIMARY KEY  (id)
    ) $charset_collate;";
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
    add_option( 'runout_db_version', $runout_db_version );
}

/**
 * Az új adatbázis táblába ír egy sort az aktuális dátummal és "install" szöveggel
 *
 */
function runout_install_data() {
    global $wpdb;
    $first = 'install';
/*
	$results = $wpdb->get_results( 
                    $wpdb->prepare("SELECT count(id) as total FROM {$wpdb->prefix}. 'runout' WHERE status=%d", $first) 
                 );
*/
//az előzőt is itt hagyom referenciaként, de ez szebb megoldás
    $query="SELECT count(id) FROM {$wpdb->prefix}runout WHERE status='$first'";
    $rowcount = $wpdb->get_var($query);
    if($rowcount==0) {
        $table_name = $wpdb->prefix . 'runout';
        $wpdb->insert( 
	$table_name, 
            array( 
		'time' => current_time( 'mysql' ), 
		'status' => $first, 
            ) 
        );
    }
}

add_action('admin_menu', 'productrunout_create_page');

/**
 * Létrehozza a menü elemet
 *
 */
function productrunout_create_page() {
    add_menu_page(__( 'Vevőnél elfogyó termékek', 'runout' ), __( 'Elfogyó termékek', 'runout' ), 'list_users', 'runout', 'runout_menu', 'dashicons-admin-generic', 51);
    add_submenu_page('runout', __( 'Lista lekérdezés', 'runout' ), __( 'Lista lekérdezés', 'runout' ), 'list_users', 'runout', 'runout_menu');
}

/**
 * Létrehozza a menü kattintásra megnyíló oldalt,
 * Beolvassa az adatbázisból a napok számát, hogy hány nap múlva elfogyó terméket keressen,
 * majd a kapott sorokon végiglépkedve képernyőre írja az adatokat, valamint elkészíti a letölthető XML-t.
 *
 */
function runout_menu() {
    echo "<h1 class=\"wp-heading-inline\">".__( 'Elfogyó termékek lekérdezése', 'runout' )."</h1><br/>";
    echo "Napok száma amíg még nem fogy el: ".get_option( 'runout_days' )." ";
    $ma=date("Y-m-d H:i:s");
    $napokmulvastring="+".get_option( 'runout_days' )." day";
    $napokmulvavegestring="+".(get_option( 'runout_days' )+1)." day";
    $napokmulva=date('Y-m-d', strtotime($napokmulvastring));
    $napokmulvavege=date('Y-m-d', strtotime($napokmulvavegestring));
    echo "(".$napokmulva.")<br/>";
    $dom = new DOMDocument();
    $dom->encoding = 'utf-8';
    $dom->xmlVersion = '1.0';
    $dom->formatOutput = true;
    $xml_file_name = 'product_list.xml';
    $root = $dom->createElement('Customers');
    global $wpdb;
    $results = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}runout WHERE time>%s and time<%s order by customerid",$napokmulva,$napokmulvavege ));
    $customerid=0;
    foreach ( $results as $sor ){
        $product = wc_get_product( $sor->productid );
        $customer = get_user_by( 'id', $sor->customerid );
        echo "Vevő:";
        echo $customer->user_firstname . " " .$customer->user_lastname;
        echo " ,".$customer->user_email;
        echo " (".$customer->ID.")<br/>";
        echo $product->get_title();
        echo " (".get_post_meta( $sor->productid,'runout_days', true )." napra elég)</br>";
        if($customerid==$sor->customerid ){
            $products_node = $dom->createElement('Product', $product->get_title());
            $customer_node->appendChild($products_node);
            $attr_product_id = new DOMAttr('product_id', $sor->productid);
            $products_node->setAttributeNode($attr_product_id);
        }
        else{
            if($customerid!=0)
                $root->appendChild($customer_node);
            $customerid = $sor->customerid;
            $customer_node = $dom->createElement('customer');
            $attr_customer_id = new DOMAttr('customer_id', $customer->ID);
            $customer_node->setAttributeNode($attr_customer_id);
            $products_node = $dom->createElement('Product', $product->get_title());
            $customer_node->appendChild($products_node);
            $attr_product_id = new DOMAttr('product_id', $sor->productid);
            $products_node->setAttributeNode($attr_product_id);
        }
	$root->appendChild($customer_node);
    }
    $dom->appendChild($root);
    $dom->save($xml_file_name);
    echo '<a href= "'.$xml_file_name.'">' . $xml_file_name . '</a> elkészült';
}

/**
 * A rendelés teljsítésekor ("Teljesített" státuszba lépéskor) ellenőrzi, hogy a megrendelő
 * vásárolt-e már ilyen terméket. Ha nem, akkor az aktuális dátum plusz a megrendelt mennyiség alapján
 * becsült időt rögzíti az ügyfélhez az adott termékhez. Ha már volt vásárlás, akkor a már rögzített
 * dátumot módosítja a most megrendelt mennyiség függvényében. 
 *
 */
function mysite_woocommerce_order_status_completed( $order_id ) {
    $order = wc_get_order( $order_id );
    if ( count( $order->get_items() ) > 0 ) {
	$order_items = $order->get_items();
	$napok=0;
	global $wpdb;
	foreach( $order_items as $product ) {
            if(!empty(get_post_meta( $product['product_id'],'runout_days', true ))){
                $napok=get_post_meta( $product['product_id'],'runout_days', true )*$product['qty'];
                $vanemar="SELECT * FROM runout WHERE customerid=".$order->get_customer_id()." AND productid=".$product['product_id'];
		$numbers = $wpdb->get_var( 
                $wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}runout WHERE customerid=%d AND productid=%d",$order->get_customer_id(),$product['product_id'] ) 
                );
		$results = $wpdb->get_results( 
                $wpdb->prepare("SELECT * FROM {$wpdb->prefix}runout WHERE customerid=%d AND productid=%d",$order->get_customer_id(),$product['product_id'] ) 
                );
		if($numbers==0){
                    $datum='DATE_ADD(NOW(), INTERVAL '.$napok.' DAY)';
                    $query="SELECT $datum";
                    $datum = $wpdb->get_var($query);
                    $table_name = $wpdb->prefix . 'runout';
                    $wpdb->insert( 
			$table_name, 
			array( 
                            'customerid' => $order->get_customer_id(),
                            'productid' => $product['product_id'],
                            'days' => get_post_meta( $product['product_id'],'runout_days', true ),
                            'time' => $datum, 
                            'status' => 'new', 
			) 
                    );
		}
                else{
                    foreach ( $results as $sor ){
                        $utolsonap="'".$sor->time."'";
                        $datum='DATE_ADD('.$utolsonap.', INTERVAL '.$napok.' DAY)';
                        $query="SELECT $datum";
                        $datum = $wpdb->get_var($query);
                        $table_name = $wpdb->prefix . 'runout';
                        $wpdb->update( 
                            $table_name, 
                            array( 
                            'time' => $datum, 
                            ), 
                            array('id'=>$sor->id)
                    );
                    }
                }
            }
	}
    }
}

add_action( 'woocommerce_order_status_completed', 'mysite_woocommerce_order_status_completed', 10, 1 );

/**
 * Létrehozza az admin felületen a plusz mezőket ahol be lehet állítani a 
 * paramétereket, hogy egy kiszerelés egységnyi termék átlagosan hány napra elegendő.
 * 
 */
if ( ! class_exists( 'WC_Settings_Runout' ) ) :

function runout_create_custom_field() {
    $args = array(
        'id' => 'runout_days',
        'label' => __( 'Hány napra elegendő?', 'runout' ),
        'class' => 'runoout-custom-field',
        'desc_tip' => true,
        'description' => __( 'Egységnyi termék ennyi nap alatt fogy el.', 'runout' ),
    );
    woocommerce_wp_text_input( $args );
}

add_action( 'woocommerce_product_options_general_product_data', 'runout_create_custom_field' );

function runout_save_custom_field( $post_id ) {
    $product = wc_get_product( $post_id );
    $title = isset( $_POST['runout_days'] ) ? $_POST['runout_days'] : '';
    $product->update_meta_data( 'runout_days', sanitize_text_field( $title ) );
    $product->save();
}

add_action( 'woocommerce_process_product_meta', 'runout_save_custom_field' );

if ( ! class_exists( 'WC_Settings_Page' ) ) {
    require_once( substr(plugin_dir_path(__FILE__),0,strlen(plugin_dir_path(__FILE__))-12) . '/woocommerce/includes/admin/settings/class-wc-settings-page.php' );
}

/**
 *
 * Az admin felületen a beállítások között létrehozza az oldalt, ahol be lehet állítani, hogy
 * hány nap múlva elfogyó termékek szerepeljenek a lekérdezésben.
 *
 */
function runout_add_settings() {
    class WC_Settings_Runout extends WC_Settings_Page {
	public function __construct() {
            $this->id    = 'runout';
            $this->label = __( 'Vevő elfogyó termékei', 'runout' );
            add_filter( 'woocommerce_settings_tabs_array',        array( $this, 'add_settings_page' ), 20 );
            add_action( 'woocommerce_settings_' . $this->id,      array( $this, 'output' ) );
            add_action( 'woocommerce_sections_' . $this->id,      array( $this, 'output_sections' ) );
            add_action( 'woocommerce_settings_save_' . $this->id, array( $this, 'save' ) );
	}

        public function get_sections() {		
            $sections = array(
		'setup' => __( 'Termékek', 'runout' ),
            );
            return apply_filters( 'woocommerce_get_sections_' . $this->id, $sections );
	}

        public function get_settings( $current_section = 'Árak' ) {
            $settings = apply_filters( 'runout_section1_settings', array(
                array(
                    'name' => __('Vevőnél elfogyó termékek kezelése', 'runout'),
                    'type' => 'title',
                    'desc' => '',
                    'id' => 'runout_main_title',
		),
                array(
                    'type'     => 'text',
                    'id'       => 'runout_days',
                    'name'     => __( 'Hátralevő napok száma', 'runout' ),
                    'desc'     => __( '', 'runoout' ),
                    'default'  => '25',
		),
		array(
                    'type' => 'sectionend',
                     'id' => 'runoutsetup' 
		)
            ));
            return apply_filters( 'woocommerce_get_settings_' . $this->id, $settings, $current_section );
	}
		
	public function output() {		
            global $current_section;
            $settings = $this->get_settings( $current_section );
            WC_Admin_Settings::output_fields( $settings );
	}

        public function save() {		
            global $current_section;			
            $settings = $this->get_settings( $current_section );
            WC_Admin_Settings::save_fields( $settings );
	}
    }
    return new WC_Settings_Runout();
}

add_filter( 'woocommerce_get_settings_pages', 'runout_add_settings', 15 );

endif;
