Telepítés a mappába lépve:

image létrehozása:
docker build -t dockerwebshop .

dockerek indítása:
docker-compose up

futó webshop konténer id lekérdezése:
docker ps

az install.txt-ben a szükséges módosítások elvégzése (url, user, pass, email...), majd: 
docker exec -i webshopkonténerid bash < ./install.txt

Ezek után a rendszer elérhető a docker-compose.yml-ben beállított porton (alapbeállítás 8089).

