<?php
/*
Plugin Name: WooCommerce BACS Order Email
Description: Plugin for sending email when the selected payment is bacs.
Version: 0.1
Author: Viktor Rajcsanyi
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

function add_bacs_order_email($email_classes) {
	require_once( 'includes/class-bacs-order-email.php' );
	$email_classes['BACS_Order_Email'] = new BACS_Order_Email();
	return $email_classes;
}
add_filter( 'woocommerce_email_classes', 'add_bacs_order_email' );
