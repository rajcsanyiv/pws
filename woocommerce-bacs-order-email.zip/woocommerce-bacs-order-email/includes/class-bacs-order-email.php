<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class BACS_Order_Email extends WC_Email {
	public function __construct() {
		$this->id = 'wc_bacs_order';
		$this->title = 'BACS Order';
		$this->description = 'Automata email amikor a megrendelés fizetési módja banki átutalás';
		$this->heading = 'Új megrendelés';
		$this->subject = 'Új megrendelés';
		$this->template_html  = 'emails/bacs-new-order.php';
		$this->template_plain = 'emails/plain/bacs-new-order.php';
		//add_action( 'woocommerce_order_status_pending_to_processing_notification', array( $this, 'trigger' ) );
		//add_action( 'woocommerce_order_status_failed_to_processing_notification',  array( $this, 'trigger' ) );
		add_action( 'woocommerce_new_order', 'trigger', 20, 1 );
		parent::__construct();
		$this->recipient = $this->get_option( 'recipient' );
		if ( ! $this->recipient )
			$this->recipient = get_option( 'admin_email' );
	}

	public function trigger( $order_id ) {

		if ( ! $order_id )
			return;

		if( ! $order->has_status( 'pending' ) ) 
			return;

		$this->object = new WC_Order( $order_id );
		
		if(!$order->get_payment_method()!='bacs')
			return;

		$this->find[] = '{order_date}';
		$this->replace[] = date_i18n( woocommerce_date_format(), strtotime( $this->object->order_date ) );

		$this->find[] = '{order_number}';
		$this->replace[] = $this->object->get_order_number();

		if ( ! $this->is_enabled() || ! $this->get_recipient() )
			return;
//ide kellhet pluszba a vevő, ha a wc nem kezeli alapból: teszt
//$recipient .= "," . $order->get_billing_email();
//ahol az $order lehet hogy a $this->object
		$this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
	}

	public function get_content_html() {
		ob_start();
		woocommerce_get_template( $this->template_html, array(
			'order'         => $this->object,
			'email_heading' => $this->get_heading()
		) );
		return ob_get_clean();
	}

	public function get_content_plain() {
		ob_start();
		woocommerce_get_template( $this->template_plain, array(
			'order'         => $this->object,
			'email_heading' => $this->get_heading()
		) );
		return ob_get_clean();
	}

	public function init_form_fields() {

		$this->form_fields = array(
			'enabled'    => array(
				'title'   => 'Engedélyezés/Tiltás',
				'type'    => 'jelölőnégyzet',
				'label'   => 'Email értesítés enedélyezése',
				'default' => 'igen'
			),
			'recipient'  => array(
				'title'       => 'Címzett(ek)',
				'type'        => 'szöveg',
				'description' => sprintf( 'Címzettek megadása (vesszővel leválasztva) az üzenethez. Alapértelmezett: <code>%s</code>.', esc_attr( get_option( 'admin_email' ) ) ),
				'placeholder' => '',
				'default'     => ''
			),
			'subject'    => array(
				'title'       => 'Téma',
				'type'        => 'text',
				'description' => sprintf( 'Ez a levél témája. Üresen hagyva az alapértelmezés: <code>%s</code>.', $this->subject ),
				'placeholder' => '',
				'default'     => ''
			),
			'heading'    => array(
				'title'       => 'Email fejléc',
				'type'        => 'text',
				'description' => sprintf( __( 'Ez az üzenet fejléce, alapértelmezettként: <code>%s</code>.' ), $this->heading ),
				'placeholder' => '',
				'default'     => ''
			),
			'email_type' => array(
				'title'       => 'Email típusa',
				'type'        => 'select',
				'description' => 'Az email formátuma.',
				'default'     => 'html',
				'class'       => 'email_type',
				'options'     => array(
					'plain'	    => __( 'Egyszerű szöveg', 'woocommerce' ),
					'html' 	    => __( 'HTML', 'woocommerce' ),
					'multipart' => __( 'Különböző formátumok', 'woocommerce' ),
				)
			)
		);
	}


}
