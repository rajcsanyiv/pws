<?php
/*
Plugin Name: Importstart
Description: Product import initial state setup
Version: 1.0
Author: Viktor Rajcsányi / Promera
Author URI: http://promera.hu
Text Domain: productimport
Domain Path: /languages/
*/

if ( ! defined( 'WPINC' ) ){
	die('Permission denied');
}


add_action('admin_menu', 'productimport_create_page');

function productimport_create_page() {
    add_menu_page(__('Import előkészítés','productimport'), __('Import előkészítés','productimport'), 'list_users', 'productimport', 'productimport_menu', 'dashicons-admin-generic', 51);
    add_submenu_page('productimport', __('Kezdeti állapot','productimport'), __('Kezdeti állapot','productimport'), 'list_users', 'productimport', 'productimport_menu');
}

function productimport_menu() {
    $startid=get_option( 'startid' );
    echo "<h1 class=\"wp-heading-inline\">";
    _e('Import kezdeti állapot beállítása','productimport');
    echo "</h1><br/>";
    _e('Hibás import folyamat esetén az ismételt importáláshoz a csv-t módosítani kell az új kezdeti ID értéknek megfelelően.','productimport');
    echo "<br/>";
    _e('Az első ID mezőben ilyenkor Beállítás után információként megjelenik az előző kezdőérték, ami felül lett írva.','productimport');
    echo "<hr>";
    _e('A termék importhoz tartozó első ID beállítása.','productimport'); 
    ?> <div class="wrap">
                <hr>
                <form method="GET">
                    <input type="hidden" name="page" value="productimport">
                    <label for="startid"><font size="3"><?php esc_html_e('Első ID', 'productimport'); ?></font></label>
                    <input type="text" name="startid" id="startid" value="<?php echo $startid; ?>">
                    <input type="submit" class="button action" value="<?php esc_html_e('Beállít', 'productimport'); ?>">
                </form>
            </div>
<?php
if (isset($_GET["startid"])) {
$hiba = "";

if(!is_numeric($_GET["startid"]))
$hiba.=__(' - a megadott érték hibás','productimport');
/*
if(get_option( 'startid' )!=false)
$hiba.=" - egyszer már történt importálás";
*/
global $wpdb;
$result  = $wpdb->get_results( "SHOW TABLE STATUS LIKE 'wp_posts'", ARRAY_A );
if($result[0]['Auto_increment']>$_GET["startid"])
$hiba .=__(' - létezik már ilyen ID','productimport');


if(strlen($hiba)==0){
update_option('startid',$_GET["startid"],false);
global $wpdb;
$my_post = array(
    'ID'=> $_GET["startid"],
    'post_title'    => 'Start import',
    'post_content'  => 'Import.',
    'post_status'   => 'publish',
    'post_author'   => 1
);
 
$wpdb->insert('wp_posts',$my_post);
_e('A beállított kezdőérték: ','productimport'); 
echo get_option( 'startid' );
}
else
{
_e('hiba:','productimport');
echo $hiba;
}
}

}



