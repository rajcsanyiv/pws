function getElementByXpath(path) {
    return document.evaluate(path, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
}

var table = getElementByXpath('/html/body/section/section[2]/div/div/div[1]/div/article/div/div/div/div[1]');
table.style.display = "none";
table = getElementByXpath('/html/body/section/section[2]/div/div/div[1]/div/article/div/div/div/p');
table.style.display = "none";
table = getElementByXpath('/html/body/section/section[2]/div/div/div[1]/div/article/div/div/div/h3');
table.style.display = "none";
