window.addEventListener("popstate", function() {
	if(location.hash === "#!/status-konyhafelszerelesek") {
		history.replaceState(null, document.title, location.pathname);
		var href=window.location.href;
		var n=href.indexOf("status-konyha");
		var alaphref = href.substring(0, n);
		var ujhref = alaphref.concat("status-konyhafelszerelesek/");
		setTimeout(function(){
  			location.replace(ujhref);
		},0);
	}
	if(location.hash === "#!/kavek") {
		history.replaceState(null, document.title, location.pathname);
		var href=window.location.href;
		var n=href.indexOf("status-konyha");
		var alaphref = href.substring(0, n);
		var ujhref = alaphref.concat("kavek/");
		setTimeout(function(){
			location.replace(ujhref);
		},0);
	}
	if(location.hash === "#!/autoapolas") {
		history.replaceState(null, document.title, location.pathname);
		var href=window.location.href;
		var n=href.indexOf("status-konyha");
		var alaphref = href.substring(0, n);
		var ujhref = alaphref.concat("autoapolas/");
		setTimeout(function(){
			location.replace(ujhref);
		},0);
	}
}, false);

function showKevesebbet(){
	var href=window.location.href;
	var n=href.indexOf("status-konyha");
	if(n>0){
		var alaphref = href.substring(0, n);
		var ujhref = alaphref.concat("status-konyhafelszerelesek/");
		history.replaceState(null, document.title, ujhref+"#!/status-konyhafelszerelesek");
		history.pushState(null, document.title, ujhref+"#!/status-konyhafelszerelesek");
	}
	n=href.indexOf("kavek");
	if(n>0){
		var alaphref = href.substring(0, n);
		var ujhref = alaphref.concat("kavek/");
		history.replaceState(null, document.title, ujhref+"#!/kavek");
		history.pushState(null, document.title, ujhref+"#!/kavek");
	}
	n=href.indexOf("autoapolas");
	if(n>0){
		var alaphref = href.substring(0, n);
		var ujhref = alaphref.concat("autoapolas/");
		history.replaceState(null, document.title, ujhref+"#!/autoapolas");
		history.pushState(null, document.title, ujhref+"#!/autoapolas");
	}
	document.getElementsByClassName("vc_tta-panel-heading")[0].style.visibility="hidden";
	document.getElementsByClassName("vc_tta-panel")[0].style.visibility="hidden";
	document.getElementsByClassName("vc_tta-panel-heading")[1].style.visibility="visible";
	document.getElementsByClassName("vc_tta-panel")[1].style.visibility="visible";
	document.getElementsByClassName("vc_tta-panel")[0].parentNode.insertBefore(document.getElementsByClassName("vc_tta-panel")[1], document.getElementsByClassName("vc_tta-panel")
[0]);
	document.getElementsByClassName("vc_tta-panel-heading")[1].style.borderStyle = "none";       
	setTimeout(function(){
		document.getElementsByClassName("vc_tta-panel")[1].classList.toggle("vc_active");
	},10);     
}

function showTobbet(){
	var href=window.location.href;
	var n=href.indexOf("status-konyha");
	if(n>0){
		var alaphref = href.substring(0, n);
		var ujhref = alaphref.concat("status-konyhafelszerelesek/");
		history.replaceState(null, document.title, ujhref+"#!/status-konyhafelszerelesek");
		history.pushState(null, document.title, ujhref+"#!/status-konyhafelszerelesek");
	}
	n=href.indexOf("kavek");
	if(n>0){
		var alaphref = href.substring(0, n);
		var ujhref = alaphref.concat("kavek/");
		history.replaceState(null, document.title, ujhref+"#!/kavek");
		history.pushState(null, document.title, ujhref+"#!/kavek");
	}
	n=href.indexOf("autoapolas");
	if(n>0){
		var alaphref = href.substring(0, n);
		var ujhref = alaphref.concat("autoapolas/");
		history.replaceState(null, document.title, ujhref+"#!/autoapolas");
		history.pushState(null, document.title, ujhref+"#!/autoapolas");
	}
	document.getElementsByClassName("vc_tta-panel-heading")[0].style.visibility="hidden";
	document.getElementsByClassName("vc_tta-panel")[1].style.visibility="visible";
	document.getElementsByClassName("vc_tta-panel-heading")[1].style.visibility="visible";
	document.getElementsByClassName("vc_tta-panel")[0].parentNode.insertBefore(document.getElementsByClassName("vc_tta-panel")[1], document.getElementsByClassName("vc_tta-panel")[0]);
	document.getElementsByClassName("vc_tta-panel lenyilo")[0].style.backgroundColor = "#f8f8f8";       
	document.getElementsByClassName("vc_tta-panel-heading")[0].style.borderStyle = "none";       
	setTimeout(function(){		
		document.getElementsByClassName("vc_tta-panel-body")[1].style.borderStyle = "none";
		document.getElementsByClassName("vc_tta-panel-body")[0].style.borderStyle = "none";              
	},500);
}

var x = document.getElementsByClassName("vc_tta-panel");
if(x.length>1){
	x[1].addEventListener("click", showKevesebbet);
        x[0].addEventListener("click", showTobbet);
	document.getElementsByClassName("vc_tta-panel-heading")[1].style.visibility="hidden";
        document.getElementsByClassName("vc_tta-panel")[1].style.visibility="hidden";
	document.getElementsByClassName("vc_tta-controls-icon")[0].classList.remove("vc_tta-controls-icon-plus");
	document.getElementsByClassName("vc_tta-controls-icon")[1].classList.remove("vc_tta-controls-icon-plus");
}
