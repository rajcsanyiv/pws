/* global initWCSPPP, google */

var selMethod;
var selcdType;
var selcdOwner;

jQuery(document).ready(function ($) {
    $('form[name="checkout"]').on('keyup keypress', function (e) {
        var keyCode = e.keyCode || e.which;
        if (keyCode === 13) {
            e.preventDefault();
            return false;
        }
    });
    $('form[name="checkout"]').on('submit', function (e) {
        e.preventDefault();
    });

    // XXX info begin
    var infopo = $('<abbr class="info" data-toggle="popover" data-placement="top" data-trigger="hover" data-content="" data-original-title="Információ"></abbr>');
    infopo.clone().attr('data-content', 'Kérem, válassza ki a megfelelő megszólítást').appendTo($('#billing_title_field label'));
    infopo.clone().attr('data-content', 'Kérem, adja meg vezetéknevét!').appendTo($('#billing_last_name_field label'));
    infopo.clone().attr('data-content', 'Kérem, adja meg keresztnevét (Hölgyek esetén lánykori keresztnév)').appendTo($('#billing_first_name_field label'));
    infopo.clone().attr('data-content', 'Kérem, írja be aktív emailcímét!').appendTo($('#billing_email_field label'));
    infopo.clone().attr('data-content', 'Kérem, erősítse meg aktív emailcímét!').appendTo($('#billing_email_re_field label'));
    infopo.clone().attr('data-content', 'Kérem, adja meg aktív telefonszámát, amire az aktíváló sms-t küldjük!').appendTo($('#billing_phone_field label'));
    infopo.clone().attr('data-content', 'Céges számla igényléséhez, kérem adja meg a pontos cégnevet').appendTo($('#billing_company_field label'));
    infopo.clone().attr('data-content', 'Kérem, adja meg cége adószámát').appendTo($('#billing_vat_field label'));
    infopo.clone().attr('data-content', 'Kérem, adja meg vezetéknevét!').appendTo($('#shipping_last_name_field label'));
    infopo.clone().attr('data-content', 'Kérem, adja meg keresztnevét (Hölgyek esetén lánykori keresztnév)').appendTo($('#shipping_first_name_field label'));
    infopo.clone().attr('data-content', 'Kérem, válassza ki a megfelelő megszólítást').appendTo($('#shipping_title_field label'));
    $('abbr.info').popover();
    // XXX info end

    $('#billing_iscompany').on('change', function () {
        if ($(this).val() == 'true') {
            $('#btn-magan').removeClass('active');
            $('#btn-ceges').addClass('active');
            $('#billing_type_title').text('céges');
            $('#billing_company_field').css('visibility', 'visible');
            $('#billing_vat_field').css('visibility', 'visible');
        } else {
            $('#btn-ceges').removeClass('active');
            $('#btn-magan').addClass('active');
            $('#billing_type_title').text('magán');
            $('#billing_company_field').css('visibility', 'hidden');
            $('#billing_vat_field').css('visibility', 'hidden');
        }
    });
    $('#btn-ceges').on('click', function () {
        $('#billing_iscompany').val('true');
        $('#billing_iscompany').trigger('change');
    });
    $('#btn-magan').on('click', function () {
        $('#billing_iscompany').val('false');
        $('#billing_iscompany').trigger('change');
    });
    $('#billing_iscompany').trigger('change');

    selMethod = $('#shipping_method input[checked="checked"]').val();
    selcdType = $('#collective_delivery_block input.cd_types[checked="checked"]').val();
    selcdOwner = $('#collective_delivery_block input.cd_owners[checked="checked"]').val();
    s_shipment_method_change();
    $(document).on('change', "#shipping_method input", function (e) {
        e.preventDefault();
        selMethod = $(this).val();
        s_shipment_method_change();
    });
    $(document).on('change', 'input[name="cd_type"]', function () {
        selcdType = $(this).val();
        $("#shipping_method input").trigger('change');
    });
    $(document).on('change', 'input[name="cd_owner"]', function () {
        selcdOwner = $(this).val();
        $('#cd_type_owner_price').html($('label[for="cd_owner_' + $(this).val() + '"] .cd_type_owner_price').html());
        $("#shipping_method input").trigger('change');
    });
});

function s_shipment_method_change() {
    $ = jQuery;
    $('input[id^="shipping_method_0_collective_delivery"]').parent().removeClass('active');
    $('#collective_delivery_tr').css('display', 'none');
    var chdiff = $('#ship-to-different-address-checkbox');
    var fextra = $(".woocommerce-shipping-fields-extra");
    chdiff.attr('checked', false).trigger('change');
    fextra.hide();
    if (selMethod) {
        $('input[name="payment_method"]').prop('disabled', false);
        if (selMethod.match(/flat_rate/g)) {
            chdiff.attr('checked', false).trigger('change');
            chdiff.attr('disabled', false);
            $(".flat_rate.woocommerce-shipping-fields-extra").show();
        } else if (selMethod.match(/local_pickup/g)) {
            chdiff.attr('checked', false).trigger('change');
            fextra.hide();
        } else if (selMethod.match(/pont_sprinter/g)) {
            chdiff.attr('checked', false).trigger('change');
            fextra.hide();
            $(".sprinter_ppp.woocommerce-shipping-fields-extra").show();
            if (typeof initWCSPPP == 'function') {
                initWCSPPP();
            }
        } else if (selMethod.match(/collective_delivery/g)) {
            $('input[id^="shipping_method_0_collective_delivery"]').parent().addClass('active');
            $('#collective_delivery_tr').css('display', 'table-row');
            if (selcdType === 'owner') {
                $('.cd_first').css('display', 'block');
                $('#cd_join_code').val('');
                $('#cd_join_code').prop('disabled', true);
                $('#cd_join_code_checked').val('');
                $('#cd_join_code_checked').prop('disabled', true);
                $('#collective_delivery_join_code_check_button').prop('disabled', true);
                if (selcdOwner === 'flat_rate') {
                    $('#cd_type_owner_price').css('visibility', 'visible');
                    $(".flat_rate.woocommerce-shipping-fields-extra").show();
                } else if (selcdOwner === 'pont_sprinter') {
                    $('#cd_type_owner_price').css('visibility', 'visible');
                    $(".sprinter_ppp.woocommerce-shipping-fields-extra").show();
                } else {
                    $('#cd_type_owner_price').css('visibility', 'hidden');
                }
            } else if (selcdType === 'join') {
                $('.cd_first').css('display', 'none');
                $('#cd_join_code').removeAttr('disabled');
                $('#cd_join_code_checked').removeAttr('disabled');
                $('#collective_delivery_join_code_check_button').removeAttr('disabled');
                $('#cd_type_owner_price').css('visibility', 'hidden');
            } else {
                $('.cd_first').css('display', 'none');
                $('#cd_join_code').val('');
                $('#cd_join_code').prop('disabled', true);
                $('#cd_join_code_checked').val('');
                $('#cd_join_code_checked').prop('disabled', true);
                $('#collective_delivery_join_code_check_button').prop('disabled', true);
                $('#cd_type_owner_price').css('visibility', 'hidden');
            }
            if (typeof initWCCD == 'function') {
                initWCCD();
            }
        } else {
            console.log('DEBUG: s_shipment_method_change');
        }
    } else {
        $('input[name="payment_method"]').prop('disabled', true).prop('checked', false);
        $('div.payment_box').hide();
    }
}

function initMap() {
    var shipping_country = document.getElementById('shipping_country').value;
    if (!shipping_country) {
        shipping_country = 'HU';
    }
    shipping_country = shipping_country.toLowerCase();

    var i_shipping_postcode = document.getElementById('shipping_postcode');
    var i_shipping_city = document.getElementById('shipping_city');
    var i_shipping_address_1 = document.getElementById('shipping_address_1');
    var i_shipping_address_2 = document.getElementById('shipping_address_2');
    var shipping_postcodeAC = new google.maps.places.Autocomplete(i_shipping_postcode,
            {
                types: ['geocode'],
                componentRestrictions: {country: shipping_country}
            });
    shipping_postcodeAC.addListener('place_changed', function () {
        var place = shipping_postcodeAC.getPlace();
        if (place.address_components) {
            for (var i = 0; i < place.address_components.length; i++) {
                var addressType = place.address_components[i].types[0];
                if (addressType == 'postal_code') {
                    i_shipping_postcode.value = place.address_components[i]['short_name'];
                } else if (addressType == 'locality') {
                    i_shipping_city.value = place.address_components[i]['long_name'];
                    for (var j = 0; j < place.address_components.length; j++) {
                        var addrType = place.address_components[j].types[0];
                        if (addrType == 'sublocality_level_1') {
                            i_shipping_city.value += ' ' + place.address_components[j]['long_name'];
                        }
                    }
                }
            }
            if (i_shipping_postcode.value) {
                if (i_shipping_city.value) {
                    i_shipping_address_1.value = i_shipping_city.value + ' ';
                    i_shipping_address_1.focus();
                } else {
                    i_shipping_city.value = i_shipping_postcode.value + ' ';
                    i_shipping_city.focus();
                }
            }
        }
    });
    var shipping_cityAC = new google.maps.places.Autocomplete(i_shipping_city,
            {
                types: ['geocode'],
                componentRestrictions: {country: shipping_country}
            });
    shipping_cityAC.addListener('place_changed', function () {
        var place = shipping_cityAC.getPlace();
        if (place.address_components) {
            for (var i = 0; i < place.address_components.length; i++) {
                var addressType = place.address_components[i].types[0];
                if (addressType == 'postal_code') {
                    i_shipping_postcode.value = place.address_components[i]['short_name'];
                } else if (addressType == 'locality') {
                    i_shipping_city.value = place.address_components[i]['long_name'];
                    for (var j = 0; j < place.address_components.length; j++) {
                        var addrType = place.address_components[j].types[0];
                        if (addrType == 'sublocality_level_1') {
                            i_shipping_city.value += ' ' + place.address_components[j]['long_name'];
                        }
                    }
                }
            }
            if (i_shipping_city.value) {
                i_shipping_address_1.value = i_shipping_city.value + ' ';
                i_shipping_address_1.focus();
            }
        }
    });
    var shipping_address_1AC = new google.maps.places.Autocomplete(i_shipping_address_1,
            {
                types: ['geocode'],
                componentRestrictions: {country: shipping_country}
            });
    shipping_address_1AC.addListener('place_changed', function () {
        var place = shipping_address_1AC.getPlace();
        if (place.address_components) {
            for (var i = 0; i < place.address_components.length; i++) {
                var addressType = place.address_components[i].types[0];
                if (addressType == 'route') {
                    i_shipping_address_1.value = place.address_components[i]['long_name'];
                } else if (addressType == 'street_number') {
                    i_shipping_address_2.value = place.address_components[i]['short_name'];
                }
            }
            if (i_shipping_address_1.value) {
                i_shipping_address_2.focus();
            }
        }
    });

    var billing_country = document.getElementById('billing_country').value;
    if (!billing_country) {
        billing_country = 'HU';
    }
    billing_country = billing_country.toLowerCase();

    var i_billing_postcode = document.getElementById('billing_postcode');
    var i_billing_city = document.getElementById('billing_city');
    var i_billing_address_1 = document.getElementById('billing_address_1');
    var i_billing_address_2 = document.getElementById('billing_address_2');
    var billing_postcodeAC = new google.maps.places.Autocomplete(i_billing_postcode,
            {
                types: ['geocode'],
                componentRestrictions: {country: billing_country}
            });
    billing_postcodeAC.addListener('place_changed', function () {
        var place = billing_postcodeAC.getPlace();
        if (place.address_components) {
            for (var i = 0; i < place.address_components.length; i++) {
                var addressType = place.address_components[i].types[0];
                if (addressType == 'postal_code') {
                    i_billing_postcode.value = place.address_components[i]['short_name'];
                } else if (addressType == 'locality') {
                    i_billing_city.value = place.address_components[i]['long_name'];
                    for (var j = 0; j < place.address_components.length; j++) {
                        var addrType = place.address_components[j].types[0];
                        if (addrType == 'sublocality_level_1') {
                            i_billing_city.value += ' ' + place.address_components[j]['long_name'];
                        }
                    }
                }
            }
            if (i_billing_postcode.value) {
                if (i_billing_city.value) {
                    i_billing_address_1.value = i_billing_city.value + ' ';
                    i_billing_address_1.focus();
                } else {
                    i_billing_city.value = i_billing_postcode.value + ' ';
                    i_billing_city.focus();
                }
            }
        }
    });
    var billing_cityAC = new google.maps.places.Autocomplete(i_billing_city,
            {
                types: ['geocode'],
                componentRestrictions: {country: billing_country}
            });
    billing_cityAC.addListener('place_changed', function () {
        var place = billing_cityAC.getPlace();
        if (place.address_components) {
            for (var i = 0; i < place.address_components.length; i++) {
                var addressType = place.address_components[i].types[0];
                if (addressType == 'postal_code') {
                    i_billing_postcode.value = place.address_components[i]['short_name'];
                } else if (addressType == 'locality') {
                    i_billing_city.value = place.address_components[i]['long_name'];
                    for (var j = 0; j < place.address_components.length; j++) {
                        var addrType = place.address_components[j].types[0];
                        if (addrType == 'sublocality_level_1') {
                            i_billing_city.value += ' ' + place.address_components[j]['long_name'];
                        }
                    }
                }
            }
            if (i_billing_city.value) {
                i_billing_address_1.value = i_billing_city.value + ' ';
                i_billing_address_1.focus();
            }
        }
    });
    var billing_address_1AC = new google.maps.places.Autocomplete(i_billing_address_1,
            {
                types: ['address'],
                componentRestrictions: {country: billing_country}
            });
    billing_address_1AC.addListener('place_changed', function () {
        var place = billing_address_1AC.getPlace();
        if (place.address_components) {
            for (var i = 0; i < place.address_components.length; i++) {
                var addressType = place.address_components[i].types[0];
                if (addressType == 'route') {
                    i_billing_address_1.value = place.address_components[i]['long_name'];
                } else if (addressType == 'street_number') {
                    i_billing_address_2.value = place.address_components[i]['short_name'];
                }
            }
            if (i_billing_address_1.value) {
                i_billing_address_2.focus();
            }
        }
    });
}
