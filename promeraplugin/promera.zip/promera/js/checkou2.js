// maganszemely piktogramm
var mag = document.getElementById("maganszemely");
mag.addEventListener("click", s_hideElements.bind(null, "mag"));
// ceg piktogramm
var ceg = document.getElementById("ceg");
ceg.addEventListener("click", s_hideElements.bind(null, "ceg"));

// account adatok
var acc = document.getElementById("account_details");

// vasarlo adatok
var szamlazas = document.getElementsByClassName("col-1")[0];

// rendeles/fizetes
var rendeles = document.getElementById("order_review");

// adoszam (vat), ceg (com), szekhely (hq)
var vat;
var com;
var hq;
var b_vat;
var b_com;
var b_hq;

// piktogrammok
var picto = document.getElementById("safis_pics");

// account adatok tovabb gomb
var a_tovabb = document.getElementById("account_next");
a_tovabb.addEventListener("click", function(event) {

    event.preventDefault();
    s_accountNext();
    });

// szamlazasi adatok tovabb gomb
var b_tovabb = document.getElementById("billing_next");
b_tovabb.addEventListener("click", function(event) {
    event.preventDefault();
    s_billingNext();
    });

// szallitasi adatok tovabb gomb
var c_tovabb = document.getElementById("shipping_next");
c_tovabb.addEventListener("click", function(event) {
    event.preventDefault();
    s_shippingNext();
    });

// szallitasi div
var szallitas = document.getElementsByClassName("col-2")[0];

// rendeles review
var review = document.getElementById("order_review_heading");

// checkout error
jQuery(document).ready(function($) {
    $( document.body ).on('checkout_error', function() {
        s_hideElements("");
    });
});

function s_hideElements(what) {
    switch (what) {
        case "mag":
            vat.style.display = "none";
            com.style.display = "none";
            hq.style.display = "none";
            b_vat.style.display = "none";
            b_com.style.display = "none";
            b_hq.style.display = "none";
            break;
        case "ceg":
            vat.style.display = "block";
            com.style.display = "block";
            hq.style.display = "block";
            b_vat.style.display = "block";
            b_com.style.display = "block";
            b_hq.style.display = "block";
            break;
        case "acc":
            acc.style.display = "none";
            break;
        case "szamlazas":
            szamlazas.style.display = "none";
            picto.style.display = "none";
            break;
        case "szallitas":
            szallitas.style.display = "none";
            break;
        case "rendeles":
            rendeles.style.display = "none";
            review.style.display = "none";
            break;
        case "account_details":
            jQuery("#account_details").hide(500);
            break;
        case "customer_details_c1" :
            jQuery("#safis_pics").hide(500);
            jQuery(".col-1").eq(0).hide(500); // szamlazasi div
            break;
        case "customer_details_c2":
            jQuery(".col-2").eq(0).hide(500); // szallitasi div
            //s_send_sms();
            break;
        default:
            // minden elrejtese az account adatokon kivul
            s_hideElements("szamlazas");
            s_hideElements("szallitas");
            s_hideElements("rendeles");
            picto.style.display = "block";
            acc.style.display = "block";
            mag.style.display = "inline";
            ceg.style.display = "inline";
    }
}

function copy_billing_info() {
    var wc_billing = document.getElementsByClassName("woocommerce-billing-fields")[0];
    var acc_copy = document.getElementById("account_copy");
    acc_copy.appendChild(wc_billing.cloneNode(true));
    var to_change = acc_copy.querySelectorAll("input");
    [].forEach.call(to_change,
                    function(el) {
                        el.id = el.id.replace("billing_", "reg_");
                        el.name = el.name.replace("billing_", "reg_");
                    });
    to_change = acc_copy.querySelectorAll("p");
    [].forEach.call(to_change,
                    function(el) {
                        el.id = el.id.replace("billing_", "reg_");
                    });
    to_change = acc_copy.querySelector("button");
    to_change.parentElement.removeChild(to_change);
    to_change = acc_copy.querySelector("h3");
    to_change.parentElement.removeChild(to_change);
    vat = document.getElementById("reg_vat_field");
    com = document.getElementById("reg_company_field");
    hq = document.getElementById("reg_headquarter_field");
    b_vat = document.getElementById("billing_vat_field");
    b_com = document.getElementById("billing_company_field");
    b_hq = document.getElementById("billing_headquarter_field");
}

function s_accountNext() {
    // account adatok eltuntetese
    s_hideElements("account_details");
    //s_hideElements("acc");
    // szamlazas megjelenitese
    var wc_billing = document.getElementsByClassName("woocommerce-billing-fields")[0];
    var acc_copy = document.getElementById("account_copy");
    var to_change = acc_copy.querySelectorAll("input");
    [].forEach.call(to_change,
                    function(el) {
                        var id = el.id.replace("reg", "billing");
                        document.getElementById(id).value = el.value;
                    });
    szamlazas.style.display = "block";
}

function s_billingNext() {
    // szamlazasi adatok eltuntetese
    s_hideElements("customer_details_c1");
    //s_hideElements("szamlazas");
    // szallitas megjelenitese
    szallitas.style.display = "block";
}

function s_shippingNext() {
    // szallitas eltuntetese
    s_hideElements("customer_details_c2");
    // s_hideElements("szallitas");
    // rendeles megjelenitese
    rendeles.style.display = "block";
}

//function s_send_sms() {
//    jQuery(document).ready(function($) {
//        var data = {
//            'action': 'my_action',
//            'phone': document.getElementById('reg_phone').value
//        };
//        jQuery.post(myAjaxObject.ajax_url, data, function(response) {
//        });
//    });
//}
