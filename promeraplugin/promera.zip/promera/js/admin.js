jQuery(document).ready(function ($) {
    var f_ar = $('#fogyasztoi_ar').parent();
    f_ar.insertBefore($('#_regular_price').parent());
    var pregular = $('<span>');
    pregular.addClass('description').addClass('description-percent');
    pregular.on('click', function () {
        var def = parseInt($(this).attr('title'));
        var p = parseInt(prompt("Add meg a %-ot", def));
        if (!isNaN(p) && p >= 0) {
            var far = parseInt($('#fogyasztoi_ar').val());
            $('#_regular_price').val(parseInt(far - (p / 100 * far))).trigger('change');
        }
    });
    pregular.insertAfter($('#_regular_price'));
    var sregular = $('<span>');
    sregular.addClass('description').addClass('description-percent');
    sregular.insertAfter($('#_sale_price'));
    sregular.on('click', function () {
        var def = parseInt($(this).attr('title'));
        if (isNaN(def)) {
            def = '';
        }
        var p = parseInt(prompt("Add meg a %-ot", def));
        if (!isNaN(p) && p >= 0) {
            var far = parseInt($('#fogyasztoi_ar').val());
            $('#_sale_price').val(parseInt(far - (p / 100 * far))).trigger('change');
        }
    });
    var ffar = function () {
        var far = parseInt($(this).val());
        var rar = parseInt($('#_regular_price').val());
        var rp = (100 - (rar / far * 100));
        pregular.attr('title', rp);
        pregular.text(parseInt(rp) + '%');
        if ($('#_sale_price').val()) {
            var sar = parseInt($('#_sale_price').val());
            var sp = (100 - (sar / far * 100));
            sregular.attr('title', sp);
            sregular.text(parseInt(sp) + '%');
        } else {
            sregular.attr('title', '');
            sregular.text('üres');
        }
    };
    var frar = function () {
        var far = parseInt($('#fogyasztoi_ar').val());
        var rar = parseInt($(this).val());
        var rp = (100 - (rar / far * 100));
        pregular.attr('title', rp);
        pregular.text(parseInt(rp) + '%');
    };
    var fsar = function () {
        var far = parseInt($('#fogyasztoi_ar').val());
        if ($(this).val()) {
            var sar = parseInt($(this).val());
            var sp = (100 - (sar / far * 100));
            sregular.attr('title', sp);
            sregular.text(parseInt(sp) + '%');
        } else {
            sregular.attr('title', '');
            sregular.text('üres');
        }
    };
    $('#fogyasztoi_ar').on('change', ffar);
    $('#fogyasztoi_ar').on('keyup', ffar);
    $('#_regular_price').on('change', frar);
    $('#_regular_price').on('keyup', frar);
    $('#_sale_price').on('change', fsar);
    $('#_sale_price').on('keyup', fsar);
    $('#fogyasztoi_ar').trigger('change');

$ = jQuery;
        $('._error').removeClass('_error');
        fields = $('li span[id^="error__"]');
        if (fields !== undefined && fields.length) {
            var ef = [];
            $.each(fields, function (i, f) {
                var ff = $(f).attr('id').split('__');
                var val = ff.length > 3 ? ff[2] : ff[1];
                if ($.inArray(val, ef) === -1) {
                    ef[ef.length] = val;
                }
            });
            if (ef.length) {
                $.each(ef, function (i, v) {
                    if (v === 'shipping' || v === 'payment') {
                        v += '_block';
                    }
                    if ($('#' + v).length && !$('#' + v).hasClass('_error')) {
                        $('#' + v).addClass('_error');
                    }
                });
            }
        }
  $('[data-toggle="tooltip"]').tooltip(); 

});
