<?php
/*
  Plugin Name: WooCommerce Order by Category
  Description: Plugin for filtering orders by category.
  Version: 1.0
  Author: Viktor Rajcsanyi
  Author URI:  http://promera.hu
  Text Domain: ordercategorylist
  Domain Path: /languages
 */

if (!defined('ABSPATH'))
    exit;

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

if (!class_exists('Category_Table')) {
    require_once( plugin_dir_path(__FILE__) . 'category-table.php' );
}

$ordercategorylist = array();

add_action('plugins_loaded', 'ordercategorylist_init', 10, 1);
add_action('admin_menu', 'ordercategorylist_create_page');

function ordercategorylist_create_page() {
    add_menu_page(__('Vodicai rendelések','ordercategorylist'), __('Vodicai rendelések','ordercategorylist'), 'list_users', 'ordercategorylist', 'ordercategorylist_menu', 'dashicons-admin-generic', 51);
    add_submenu_page('ordercategorylist', __('Vodicai rendelések','ordercategorylist'), __('Vodicai rendelések','ordercategorylist'), 'list_users', 'ordercategorylist', 'ordercategorylist_menu');
}

function ordercategorylist_init() {
	load_plugin_textdomain( 'ordercategorylist', false, dirname(plugin_basename(__FILE__)).'/languages/' );
}

function ordercategorylist_menu() {
    echo "<h1 class=\"wp-heading-inline\">".__('Vodicai rendelések','ordercategorylist')."</h1><br/>".__('A rendelések listája.','ordercategorylist');
    wp_reset_query();
    $category_table = new Category_Table();
    $category_table->prepare_items();
    echo "<form id=\"category-table\" method=\"get\">";
    $category_table->display();
    echo "</form>";
}

if (!class_exists('WC_Settings_Ordercategorylist')) :
    if (!class_exists('WC_Settings_Page')) {
        require_once( substr(plugin_dir_path(__FILE__), 0, strlen(plugin_dir_path(__FILE__)) - 14) . '/woocommerce/includes/admin/settings/class-wc-settings-page.php' );
    }

    function ordercategorylist_add_settings() {

        class WC_Settings_Ordercategorylist extends WC_Settings_Page {

            public function __construct() {
                $this->id = 'ordercategorylist';
                $this->label = __('Vodicai rendelések', 'ordercategorylist');
                add_filter('woocommerce_settings_tabs_array', array($this, 'add_settings_page'), 20);
                add_action('woocommerce_settings_' . $this->id, array($this, 'output'));
                add_action('woocommerce_settings_save_' . $this->id, array($this, 'save'));
                add_action('woocommerce_sections_' . $this->id, array($this, 'output_sections'));
            }

            public function get_sections() {
                $sections = array(
                    'setup' => __('Beállítások', 'ordercategorylist')
                );
                return apply_filters('woocommerce_get_sections_' . $this->id, $sections);
            }

            public function get_settings($current_section = '') {
                $settings = apply_filters('ordercategorylist_section1_settings', array(
                    array(
                        'type' => 'checkbox',
                        'id' => 'ordercategorylist',
                        'name' => __('Engedélyezés', 'ordercategorylist'),
                        'desc' => __('A rendelések teljesítéskor jelölést kapnak', 'ordercategorylist'),
                        'default' => 'no',
                    ))
                );
                return apply_filters('woocommerce_get_settings_' . $this->id, $settings, $current_section);
            }

            public function output() {
                global $current_section;
                $settings = $this->get_settings($current_section);
                WC_Admin_Settings::output_fields($settings);
            }

            public function save() {
                global $current_section;
                $settings = $this->get_settings($current_section);
                WC_Admin_Settings::save_fields($settings);
            }

        }

        return new WC_Settings_Ordercategorylist();
    }

    add_filter('woocommerce_get_settings_pages', 'ordercategorylist_add_settings', 15);
endif;

/*teljesített rendelés esetén rögzítse, ha volt Vodicai termék, ez gyorsítja a későbbi lekérdezést*/   
function vodicai_order_status_completed($order_id) {
	$order = wc_get_order( $order_id );
	$items = $order->get_items(); 
	foreach ( $items as $item ) {      
    		$product_id = $item['product_id'];
    		if ( has_term( 'vodicai-levendulas', 'product_cat', $product_id ) ) {
                        update_post_meta($order_id, 'vodicai', true);
        		break;
    		}
	}  
}

add_action('woocommerce_order_status_completed', 'vodicai_order_status_completed', 10, 1);
 
