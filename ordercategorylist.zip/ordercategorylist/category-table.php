<?php
if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class Category_Table extends WP_List_Table {
   
    public static function get_orderbycategory() {
	global $wpdb;
	$orders = wc_get_orders( array(
	    'limit'        => -1, // mindent
	    'orderby'      => 'date',
	    'order'        => 'DESC',
	    'meta_key'     => 'vodicai',
	    'meta_compare' => true,
        ));
        $lista="(";
        foreach( $orders as $order ){
	    $lista=$lista."".$order->get_id().",";
        }
/*utolsó , kitörlése*/
        $lista=substr_replace($lista ,"", -1);
        $lista=$lista.")";
/*ha van listaelem*/
        if(strlen($lista)>1){
	    $sql2 ="SELECT post_date, display_name, user_email FROM {$wpdb->prefix}posts INNER JOIN {$wpdb->prefix}users ON {$wpdb->prefix}users.ID = {$wpdb->prefix}posts.post_author WHERE {$wpdb->prefix}posts.ID IN ".$lista." ORDER BY {$wpdb->prefix}posts.ID DESC;  ";
        }
/*ha nincsen ilyen rendelés, a táblázat akkor egy üres mysql választ vár*/
        else{
	    $sql2 ="SELECT post_date, display_name, user_email FROM {$wpdb->prefix}posts INNER JOIN {$wpdb->prefix}users ON {$wpdb->prefix}users.ID = {$wpdb->prefix}posts.post_author WHERE {$wpdb->prefix}posts.ID = 0 ORDER BY {$wpdb->prefix}posts.ID DESC;  ";
        }
        $result = $wpdb->get_results( $sql2, 'ARRAY_A' );
        return $result;
    }   

    public function __construct() {
	parent::__construct( array(
		'singular' => __( 'megrendelés', 'ordercategorylist' ),     
		'plural'   => __( 'megrendelések', 'ordercategorylist' ),    
		'ajax'     => false,       
		) );
    }
	
    public function get_columns() {
        $columns = [
        	'post_date' => __( 'Dátum', 'ordercategorylist' ),
        	'display_name' => __( 'Név', 'ordercategorylist' ),
		'user_email' => __('Email', 'ordercategorylist')
	];
        return $columns;
    }
	
    protected function get_sortable_columns() {
	$sortable_columns = array(
	);
        return $sortable_columns;
    }

    function column_post_date( $item ) {
        $title = $item['post_date'];
        return $title;
    }

    function column_display_name( $item ) {
        $title = $item['display_name'];
        return $title;
    }

    function column_user_email( $item ) {
        $title = $item['user_email'];
        return $title;
    }
    

    protected function column_default( $item, $column_name ) {
	switch ( $column_name ) {
		case 'post_date':
		case 'display_name':
	        return $item[ $column_name ];
            default:
                return print_r( $item, true );
        }
    }

    function prepare_items() {
	global $wpdb; 
	$per_page = 100;
	$columns  = $this->get_columns();
	$hidden   = array();
	$sortable = $this->get_sortable_columns();
	$this->_column_headers = array( $columns, $hidden, $sortable );
		$data = $this->get_orderbycategory();
		usort( $data, array( $this, 'usort_reorder' ) );
		$current_page = $this->get_pagenum();
		$total_items = count( $data );
		$data = array_slice( $data, ( ( $current_page - 1 ) * $per_page ), $per_page );
		$this->items = $data;
		$this->set_pagination_args( array(
			'total_items' => $total_items,                    
			'per_page'    => $per_page,  
			'total_pages' => ceil( $total_items / $per_page ), 
		) );
	}


}

