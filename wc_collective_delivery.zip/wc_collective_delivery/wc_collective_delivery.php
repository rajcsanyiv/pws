<?php

/**
 * Plugin Name: Collective Delivery for Woocommerce
 * Description: Gyűjtő szállítás.
 * Version: 1.0
 * Author: Naszádi László [WBS]
 * Author URI: http://promera.hu
 * Text Domain: collectivedelivery
 * Domain Path: /languages
 */

$plugin = plugin_basename( __FILE__ );

if (!defined('ABSPATH')) {
    exit;
}

if( !function_exists('is_plugin_active') ) {
    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

if( !class_exists( 'WooCommerce' ) ) {
        $plugin = plugin_basename( __FILE__ );
	if( is_plugin_active($plugin) ) {
//        deactivate_plugins( $plugin );
//        wp_die( __( 'Please install and Activate WooCommerce.', 'woocommerce-addon-slug' ), 'Plugin dependency check', array( 'back_link' => true ) );
    }
}

if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
if( is_plugin_active($plugin) ) {
        deactivate_plugins( $plugin );
}
$url=strtok($_SERVER["REQUEST_URI"],'?');
    echo"<a href=".$url.">Back</a>";
    wp_die( __( 'Please install and Activate WooCommerce, Collective Delivery shutting down. ', 'collectivedelivery' ), 'Plugin dependency check', array( 'back_link' => false ) );
    exit;
}

$theme = wp_get_theme();
if ( 'Basel Child' != $theme->name ) {
if( is_plugin_active($plugin) ) {
        deactivate_plugins( $plugin );
}
$url=strtok($_SERVER["REQUEST_URI"],'?');
    echo"<a href=".$url.">Back</a>";
    wp_die( __( 'Please install and Activate Basel Child theme, Collective Delivery shutting down. ', 'collectivedelivery' ), 'Plugin dependency check', array( 'back_link' => false ) );
    exit;
}

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

add_action('wp_enqueue_scripts','ava_test_init');

function ava_test_init() {
    wp_enqueue_script( 'ava-test-js', plugins_url( '/asset/shipping.js', __FILE__ ));
}

require dirname(__FILE__) . '/includes/group-orders-table.php';

add_action('wp_head', 'myplugin_ajaxurldelivery');

function myplugin_ajaxurldelivery() {

   echo '<script type="text/javascript">
           var ajaxurl = "' . admin_url('admin-ajax.php') . '";
         </script>';
}

// <editor-fold defaultstate="collapsed" desc="inits">

add_action('init', function() {
    if (!session_id()) {
        session_start();
    }
}, 10, 0);

function cd_create_page() {
	add_menu_page( __('Gyűjtő szállítások','collectivedelivery'), __('Gyűjtő szállítások','collectivedelivery'), 'edit_posts', 'group_orders_list', 'group_orders_list', 'dashicons-clipboard', 49 );
}

add_action( 'admin_menu', 'cd_create_page' );

function group_orders_list() {
        $group_orders_table = new Group_Orders_Table();
        $group_orders_table->prepare_items();
        include dirname(__FILE__) . '/includes/orderlistpage.php';
}
// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="collective delivery settings page">

add_filter('woocommerce_get_settings_pages', function() {

    class WC_Collective_Delivery_Settings_Page extends WC_Settings_Page {

        public function __construct() {
            parent::__construct();
            $this->id = 'collective_delivery';
            $this->label = __('Gyűjtő Szállítás', 'collectivedelivery');
            add_filter('woocommerce_settings_tabs_array', array($this, 'add_settings_page'), 20);
            add_action('woocommerce_settings_' . $this->id, array($this, 'output'));
            add_action('woocommerce_settings_save_' . $this->id, array($this, 'save'));
        }

        public function get_settings() {
            $settings = apply_filters('collective_delivery_settings', array(
                array(
                    'name' => __('Auto lezárás (óra)', 'collectivedelivery'),
                    'id' => 'wc_collective_delivery_autoclose_hours',
                    'type' => 'number',
                    'css' => 'max-width:50px;',
                    'custom_attributes' => array(
                        'min' => '1',
                        'max' => '48',
                        'step' => '1',
                    ),
                    'default' => '24',
                    'desc' => __('Automatikusan ennyi óra múlva záródik le egy nyitott gyűjtő szállítás.', 'collectivedelivery'),
                    'desc_tip' => true,
                ),
            ));
            return apply_filters('woocommerce_get_settings_' . $this->id, $settings);
        }

        public function output() {
            $settings = $this->get_settings();
            WC_Admin_Settings::output_fields($settings);
        }

        public function save() {
            $settings = $this->get_settings();
            WC_Admin_Settings::save_fields($settings);
        }

    }

    return new WC_Collective_Delivery_Settings_Page();
}, 15, 0);

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="collective delivery shipping method">
add_action('woocommerce_shipping_init', function() {

    class WC_Collective_Delivery_Shipping_Method extends WC_Shipping_Method {

        var $notify_url;

        public function __construct($instance_id = 0) {
            parent::__construct($instance_id);
            $this->id = 'collective_delivery';
            $this->instance_id = absint($instance_id);
            $this->method_title = __('Gyűjtő szállítás', 'collectivedelivery');
            $this->method_description = __('Több rendelés, egy szállítás alá gyűjthető.', 'collectivedelivery');
            $this->notify_url = WC()->api_request_url('WC_Collective_Delivery_Shipping_Method');
            $this->supports = array(
                'shipping-zones',
                'instance-settings',
                'instance-settings-modal',
            );
            $this->instance_form_fields = array(
                'title' => array(
                    'title' => __('Method Title', 'woocommerce'),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.', 'collectivedelivery'),
                    'default' => __('Gyűjtő szállítás', 'collectivedelivery'),
                    'desc_tip' => true,
                ),
            );
            $this->title = $this->get_option('title');
            add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
        }

        public function calculate_shipping($package = array()) {
            $rate = array(
                'id' => $this->id . ':' . $this->instance_id,
                'label' => $this->title,
                'cost' => -1,
                'package' => $package,
            );
            $this->add_rate($rate);
        }

    }

});

add_filter('woocommerce_shipping_methods', function($methods) {
    $methods['collective_delivery'] = new WC_Collective_Delivery_Shipping_Method();
    return $methods;
}, 10, 1);

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="frontend assets">

add_action('wp_enqueue_scripts', function() {
    wp_enqueue_script('wc-collective-delivery', WC_Collective_Delivery::get_plugin_url() . 'asset/wc_collective_delivery.js', array('jquery'), '3.2');
    wp_enqueue_style('wc-collective-delivery', WC_Collective_Delivery::get_plugin_url() . 'asset/wc_collective_delivery.css');
}, 10, 0);

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="action - woocommerce_review_order_after_shipping">

add_action('woocommerce_checkout_before_order_review', function() {
    $cd_type = WC()->session->get('collective_delivery_type');
    $cd_owner = WC()->session->get('collective_delivery_owner');
    $cd_code = WC()->session->get('collective_delivery_code');
    $cd_code_checked = WC()->session->get('collective_delivery_code_checked');
    $packages = WC()->shipping->get_packages();
    $fri = null;
    $psi = null;
    $loc = null;
    foreach (array_keys($packages[0]['rates']) as $rate) {
        $rate = explode(':', $rate);
        if ($rate[0] == 'flat_rate' && isset($rate[1])) {
            $fri = 'flat_rate:' . $rate[1];
        }
        if ($rate[0] == 'pont_sprinter' && isset($rate[1])) {
            $psi = 'pont_sprinter:' . $rate[1];
        }
        if ($rate[0] == 'local_pickup' && isset($rate[1])) {
            $loc = 'local_pickup:' . $rate[1];
        }
    }
    if($fri !== null){
	$cd_owner_flat_rate_price = wc_price($packages[0]['rates'][$fri]->cost + $packages[0]['rates'][$fri]->get_shipping_tax());
    }
    if($psi !== null){
	if ( null !== wc_price($packages[0]['rates'][$psi] ) )  {
	    $cd_owner_pont_sprinter_price = wc_price($packages[0]['rates'][$psi]->cost + $packages[0]['rates'][$psi]->get_shipping_tax());
        }
    }
    if($loc !== null){
	$cd_owner_local_pickup_price = wc_price($packages[0]['rates'][$loc]->cost + $packages[0]['rates'][$loc]->get_shipping_tax());
    }
    $c1 = '';
    $c1 .= '<div id="cd_first" class="col-md-6">';
    $c1 .= '<div style="height: 260px;">';
    $c1 .= '<input id="cd_type_owner" type="radio" class="cd_types with-font" name="cd_type" value="owner"' . ($cd_type == 'owner' ? ' checked="checked"' : '') . '>';
    $c1 .= '<label for="cd_type_owner">Kezdeményezés<br>';
    $c1 .= '<span id="cd_type_owner_price">' . ($cd_owner == 'flat_rate' ? $cd_owner_flat_rate_price : $cd_owner_pont_sprinter_price) . '</span>';
    $c1 .= '</label>';
    $c1 .= '<div class="cd_owner_note">' . __('Amennyiben Önhöz további vásárlók csatlakoznak, kérjük ossza meg velük a csatlakozáshoz szükséges kódot. 24 órán belül a csomagot vagy csomagokat automatikusan kiküldjük.', 'collectivedelivery') . '</div>';
    $c1 .= '</div>';
if($fri !== null){
    $c1 .= '<div class="cd_first">';
    $c1 .= '<input id="cd_owner_flat_rate" type="radio" class="cd_owners with-font" name="cd_owner" value="flat_rate"' . ($cd_owner == 'flat_rate' ? ' checked="checked"' : '') . '>';
    $c1 .= '<label for="cd_owner_flat_rate">' . $packages[0]['rates'][$fri]->label . '<br>';
    $c1 .= '<span class="cd_type_owner_price">' . $cd_owner_flat_rate_price . '</span>';
    $c1 .= '</label>';
    $c1 .= '</div>';
}
if($psi !== null){
    $c1 .= '<div class="cd_first">';
    $c1 .= '<input id="cd_owner_pont_sprinter" type="radio" class="cd_owners with-font" name="cd_owner" value="pont_sprinter"' . ($cd_owner == 'pont_sprinter' ? ' checked="checked"' : '') . '>';
    $c1 .= '<label for="cd_owner_pont_sprinter">' . $packages[0]['rates'][$psi]->label . '<br>';
    $c1 .= '<span class="cd_type_owner_price">' . $cd_owner_pont_sprinter_price . '</span>';
    $c1 .= '</label>';
    $c1 .= '</div>';
}
if($loc !== null){
    $c1 .= '<div class="cd_first">';
    $c1 .= '<input id="cd_owner_local_pickup" type="radio" class="cd_owners with-font" name="cd_owner" value="local_pickup"' . ($cd_owner == 'local_pickup' ? ' checked="checked"' : '') . '>';
    $c1 .= '<label for="cd_owner_local_pickup">' . $packages[0]['rates'][$loc]->label . '<br>';
    $c1 .= '<span class="cd_type_owner_price">' . $cd_owner_local_pickup_price . '</span>';
    $c1 .= '</label>';
    $c1 .= '</div>';
}
    $c1 .= '</div>';
    $c1 .= '<div id="cd_second" class="col-md-6">';
    $c1 .= '<div style="height: 160px;">';
    $c1 .= '<input id="cd_type_join" type="radio" class="cd_types with-font" name="cd_type" value="join"' . ($cd_type == 'join' ? ' checked="checked"' : '') . '>';
    $c1 .= '<label for="cd_type_join">'.__('Csatlakozás','collectivedelivery').'<br>';
    $c1 .= '<span class="woocommerce-Price-amount amount">'.__('Megosztott költség','collectivedelivery').'"</span>';
    $c1 .= '</label>';
    $c1 .= '<div style="margin-left: 35px;">';
    $c1 .= '<label for="cd_join_code" style="font-size: 12px; color: #ccc; margin-bottom: 0px;">KÓD MEGADÁSA</label>';
    $c1 .= '<input id="cd_join_code" type="text" name="cd_join_code" value="' . ($cd_code ? $cd_code : '') . '"' . ($cd_type == 'owner' ? ' disabled="disabled"' : '') . '>';
    $c1 .= '<input id="cd_join_code_checked" type="hidden" name="cd_join_code_checked" value="' . ($cd_code_checked ? $cd_code_checked : '') . '"' . ($cd_type == 'owner' ? ' disabled="disabled"' : '') . '>';
    $c1 .= '<button id="collective_delivery_join_code_check_button" class="btn btn-sm">'.__('ellenőrzés','collectivedelivery').'</button>';
    $c1 .= '</div>';
    $c1 .= '<div class="load-spinner" style="display: none; position: absolute; top: 3px; right: 12px;"><img style="width: 25px;" src="/wp-admin/images/spinner-2x.gif"/></div>';
    $c1 .= '</div>';
    $c1 .= '</div>';
    $c2 = '<div id="cd_foot_link" class="text-right"><a data-toggle="modal" data-target="#cdModal">'.__('További tudnivalók itt.','collectivedelivery').'</a></div>';
    $c2 .= '<div class="modal fade" id="cdModal" tabindex="-1" role="dialog" aria-labelledby="cdModalLabel"><div class="modal-dialog" role="document"><div class="modal-content"><div class="modal-header"><h4 class="modal-title" id="cdModalLabel">'.__("Tudnivalók","collectivedelivery").'</h4></div><div class="modal-body">'.__("Csoportos szállítás esetén a Kezdeményező által megadott címre fog érkezni a csatlakozók által rendelt termék is.","collectivedelivery").'</div></div><div class="modal-footer"><button type="button" class="btn btn-default" data-dismiss="modal">'.__("Bezár","collectivedelivery").'</button></div></div></div></div>';
    echo '<div id="collective_delivery_tr"><div id="collective_delivery_block" class="row">' . $c1 . '</div>' . $c2 . '</div>';
}, 1, 0);

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="action - ajax - join code check">

function collective_delivery_join_code_check() {
    $cpayment = WC()->session->get('chosen_payment_method');
    WC()->session->set('collective_delivery_code_checked', '');
    $res = new stdClass();
    $res->errormsg = __('Hiba a feldolgozás során...', 'collectivedelivery');
    if (isset($_POST['action']) && $_POST['action'] == 'collective_delivery_join_code_check' && isset($_POST['cdid'])) {
        $cdid = (string) $_POST['cdid'];
        WC()->session->set('collective_delivery_code', $cdid);
        $orders = get_posts(
                array(
                    'numberposts' => -1,
                    'meta_key' => 'collective_delivery_id',
                    'meta_value' => $cdid,
                    'post_type' => wc_get_order_types(),
                    'post_status' => array_keys(wc_get_order_statuses()),
                )
        );
        $count = count($orders);
        if ($count == 0) {
            $res->errormsg = __('Nem létezik ilyen "gyűjtő szállítás azonosító"!', 'collectivedelivery');
        } else if ($count != 1) {
            $res->errormsg = __('Hiba a feldolgozás során!', 'collectivedelivery');
        } else {
            /* @var $order WC_Order */
            $order = wc_get_order($orders[0]->ID);
            if ('open' == get_post_meta($order->get_id(), 'collective_delivery_state', true)) {
                $res->errormsg = '';
                $ppp = get_post_meta($order->get_id(), 'sprinter_ppp', true);
                if (is_array($ppp)) {
                    $res->info = __("Szállítás módja: PickPackPont\n","collectivedelivery");
                    $res->info .= __("Szállítás címe:\n","collectivedelivery");
                    $res->info .= implode("\n", $ppp);
                } else {
                    $res->info = __("Szállítás módja: Házhozszállítás\n","collectivedelivery");
                    $res->info .= __("Szállítás címe:\n","collectivedelivery");
                    $res->info .= str_replace(["<br/>", "<br>"], "\n", $order->get_formatted_shipping_address());
                }
                $res->info .= __("\nFizetés módja: ","collectivedelivery");
                $payment = $order->get_payment_method();
                $res->payment = $payment;
                WC()->session->set('chosen_payment_method', $payment);
                WC()->session->set('collective_delivery_code_checked', 'ok');
            } else {
                $res->errormsg = __('Ez a "gyűtő szállítás" nem nyitott!', 'collectivedelivery');
            }
        }
    }
    if ($res->errormsg) {
        WC()->session->set('chosen_payment_method', $cpayment);
    }
    wp_send_json($res);
    wp_die();
};

add_action('wp_ajax_collective_delivery_join_code_check', 'collective_delivery_join_code_check');
add_action('wp_ajax_nopriv_collective_delivery_join_code_check', 'collective_delivery_join_code_check');

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="filter - woocommerce_cart_get_shipping_total">

add_filter('woocommerce_cart_get_shipping_total', function($value) {
    $idx = WC_Collective_Delivery::get_rate_by_post();
    if ($idx) {
        if ($idx == '__cd__join__') {
            $value = 0;
        } else if ($idx != '__cd__') {
            $packages = WC()->shipping->get_packages();
            /* @var $ratei WC_Shipping_Rate */
            $ratei = $packages[0]['rates'][$idx];
            $value = $ratei->get_cost();
        }
    }
    return $value;
});

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="filter - woocommerce_cart_get_shipping_tax">

add_filter('woocommerce_cart_get_shipping_tax', function($value) {
    $idx = WC_Collective_Delivery::get_rate_by_post();
    if ($idx) {
        if ($idx == '__cd__join__') {
            $value = 0;
        } else if ($idx != '__cd__') {
            $packages = WC()->shipping->get_packages();
            /* @var $ratei WC_Shipping_Rate */
            $ratei = $packages[0]['rates'][$idx];
            $value = $ratei->get_shipping_tax();
        }
    }
    return $value;
});

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="filter - woocommerce_cart_get_shipping_taxes">

add_filter('woocommerce_cart_get_shipping_taxes', function($value) {
    $idx = WC_Collective_Delivery::get_rate_by_post();
    if ($idx) {
        if ($idx == '__cd__join__') {
            $value = array();
        } else if ($idx != '__cd__') {
            $packages = WC()->shipping->get_packages();
            /* @var $ratei WC_Shipping_Rate */
            $ratei = $packages[0]['rates'][$idx];
            $value = $ratei->get_taxes();
        }
    }
    return $value;
});

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="filter - woocommerce_cart_get_total">

add_action('woocommerce_cart_get_total', function($value) {
    $idx = WC_Collective_Delivery::get_rate_by_post();
    $stotal=0;
    $stax=0;
    if ($idx) {
        $totals = WC()->cart->get_totals();
        $value = $totals['total'];
        $free = false;
        foreach (WC()->cart->get_applied_coupons() as $code) {
            $coupon = new WC_Coupon($code);
            if ($coupon->get_free_shipping()) {
                $free = true;
                break;
            }
        }
        if (!$free) {
            $value++;
        }
        if ($idx == '__cd__join__') {
            $stotal = 0;
            $stax = 0;
        } else if ($idx != '__cd__') {
            $packages = WC()->shipping->get_packages();
            /* @var $ratei WC_Shipping_Rate */
            $ratei = $packages[0]['rates'][$idx];
            $stotal = $ratei->get_cost();
            $stax = $ratei->get_shipping_tax();
        }
        $value += $stotal + $stax;
    }
    return $value;
});

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="filter - woocommerce_cart_get_total_tax">

add_action('woocommerce_cart_get_total_tax', function($value) {
    /* @var $cart WC_Cart */
    $idx = WC_Collective_Delivery::get_rate_by_post();
    $stax=0;
    if ($idx) {
        $totals = WC()->cart->get_totals();
        $value = $totals['total_tax'];
        if ($idx == '__cd__join__') {
            $stax = 0;
        } else if ($idx != '__cd__') {
            $packages = WC()->shipping->get_packages();
            /* @var $ratei WC_Shipping_Rate */
            $ratei = $packages[0]['rates'][$idx];
            $stax = $ratei->get_shipping_tax();
        }
        $value += $stax;
    }
    return $value;
});

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="action - woocommerce_checkout_create_order_shipping_item">

add_action('woocommerce_checkout_create_order_shipping_item', function($item, $package_key, $package, $order) {
    /* @var $item WC_Order_Item_Shipping */
    /* @var $order WC_Order */
    $idx = WC_Collective_Delivery::get_rate_by_post();
    $total = false;
    $taxes = array();
    if ($idx) {
        if ($idx == '__cd__join__') {
            $total = 0;
        } else if ($idx != '__cd__') {
            $packages = WC()->shipping->get_packages();
            /* @var $ratei WC_Shipping_Rate */
            $ratei = $packages[0]['rates'][$idx];
            $total = $ratei->get_cost();
            $taxes = $ratei->get_taxes();
        }
    }
    if ($total !== false) {
        $item->set_props(array(
            'method_title' => $order->get_shipping_method(),
            'total' => wc_format_decimal($total),
            'taxes' => array(
                'total' => $taxes,
            ),
        ));
    }
}, 10, 4);

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="action - woocommerce_checkout_update_order_review">

add_action('woocommerce_checkout_update_order_review', function($post) {
    $post_arr = array();
    parse_str($post, $post_arr);
    WC()->session->set('collective_delivery_type', isset($post_arr['cd_type']) && in_array($post_arr['cd_type'], ['owner', 'join']) ? $post_arr['cd_type'] : null);
    WC()->session->set('collective_delivery_owner', isset($post_arr['cd_owner']) && in_array($post_arr['cd_owner'], ['flat_rate', 'pont_sprinter']) ? $post_arr['cd_owner'] : null);
    WC()->session->set('collective_delivery_code', isset($post_arr['cd_join_code']) && $post_arr['cd_join_code'] ? $post_arr['cd_join_code'] : null);
    WC()->session->set('collective_delivery_code_checked', isset($post_arr['cd_join_code_checked']) && $post_arr['cd_join_code_checked'] == 'ok' ? $post_arr['cd_join_code_checked'] : null);
}, 1, 1);

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="action - woocommerce_checkout_process">

add_action('woocommerce_checkout_process', function() {
    WC()->session->set('collective_delivery_type', isset($_POST['cd_type']) && in_array($_POST['cd_type'], ['owner', 'join']) ? $_POST['cd_type'] : null);
    WC()->session->set('collective_delivery_owner', isset($_POST['cd_owner']) && in_array($_POST['cd_owner'], ['flat_rate', 'pont_sprinter']) ? $_POST['cd_owner'] : null);
    WC()->session->set('collective_delivery_code', isset($_POST['cd_join_code']) && $_POST['cd_join_code'] ? $_POST['cd_join_code'] : null);
    WC()->session->set('collective_delivery_code_checked', isset($_POST['cd_join_code_checked']) && $_POST['cd_join_code_checked'] == 'ok' ? $_POST['cd_join_code_checked'] : null);
    $chosen_methods = WC()->session->get('chosen_shipping_methods');
    if (strstr($chosen_methods[0], 'collective_delivery')) {
        if (empty($_POST['cd_type'])) {
            wc_add_notice(__('Kérjük válasszon a gyűjtő szállítási módozatok közül. (Kezdeményező vagy Csatlakozó)', 'collectivedelivery'), 'error', 'error__shipping__r' . rand(1000, 9999));
        } else {
            if ($_POST['cd_type'] == 'join') {
                $cdid = trim((string) $_POST['cd_join_code']);
                if (!$cdid) {
                    wc_add_notice(__('Kérjük adja meg a gyűjtő azonosító kódját.', 'collectivedelivery'), 'error', 'error__validate__cd_join_code__r' . rand(1000, 9999));
                } else {
                    if (!isset($_POST['cd_join_code_checked']) || $_POST['cd_join_code_checked'] != 'ok') {
                        wc_add_notice(__('Kérjük ellenőrizze a gyűjtő azonosító kódját.', 'collectivedelivery'), 'error', 'error__validate__cd_join_code__r' . rand(1000, 9999));
                    } else {
                        $orders = get_posts(
                                array(
                                    'numberposts' => -1,
                                    'meta_key' => 'collective_delivery_id',
                                    'meta_value' => $cdid,
                                    'post_type' => wc_get_order_types(),
                                    'post_status' => array_keys(wc_get_order_statuses()),
                                )
                        );
                        if (!isset($orders[0]) || 'close' == get_post_meta($orders[0]->ID, 'collective_delivery_state', true)) {
                            wc_add_notice(__('Helytelen gyűjtő azonosító kódot adott meg vagy a rendelés már le van zárva.', 'collectivedelivery'), 'error', 'error__validate__cd_join_code__r' . rand(1000, 9999));
                        } else {
                            /* @var $order WC_Order */
                            $order = wc_get_order($orders[0]->ID);
                            $orderBillingAddress = $order->get_address();
                            $orderShippingAddress = $order->get_address('shipping');
                            $_POST['ship_to_different_address'] = true;
                            foreach ($orderShippingAddress as $k => $v) {
                                $_POST['shipping_' . $k] = $v ? $v : $orderBillingAddress[$k];
                            }
                            $_POST['payment_method'] = $order->get_payment_method();
                        }
                    }
                }
            } else {
                if (empty($_POST['cd_owner'])) {
                    wc_add_notice(__('Kérjük válasszon a kezdeményező gyűjtő szállítás, szállítási módjai közül.', 'collectivedelivery'), 'error', 'error__validate__cd_first__r' . rand(1000, 9999));
                }
            }
        }
    }
});

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="action - woocommerce_checkout_update_order_meta">

add_action('woocommerce_checkout_update_order_meta', function($order_id) {
    $chosen_methods = WC()->session->get('chosen_shipping_methods');
    if (strstr($chosen_methods[0], 'collective_delivery') && !empty($_POST['cd_type'])) {
        if ($_POST['cd_type'] == 'join') {
            $cdid = trim((string) $_POST['cd_join_code']);
            $orders = get_posts(
                    array(
                        'numberposts' => -1,
                        'meta_key' => 'collective_delivery_id',
                        'meta_value' => $cdid,
                        'post_type' => wc_get_order_types(),
                        'post_status' => array_keys(wc_get_order_statuses()),
                    )
            );
            if (!isset($orders[0]) || 'close' == get_post_meta($orders[0]->ID, 'collective_delivery_state', true)) {
                wc_add_notice(__('Helytelen gyűjtő azonosító kódot adott meg vagy a rendelés már le van zárva.', 'collectivedelivery'), 'error', 'error__validate__cd_first__r' . rand(1000, 9999));
            } else {
                $cd_joins = get_post_meta($orders[0]->ID, 'collective_delivery_join_orders', true);
                $cd_joins[] = $order_id;
                update_post_meta($orders[0]->ID, 'collective_delivery_join_orders', $cd_joins);
                update_post_meta($order_id, 'collective_delivery_joined_id', $cdid);
                update_post_meta($order_id, 'collective_delivery_joined_order', $orders[0]->ID);
            }
        } else if (!empty($_POST['cd_owner'])) {
            $cdid = '';
            $chars = '0123456789';
            $csl = mb_strlen($chars) - 1;
            srand((int) (microtime(true) * 1000000));
            $cdida = str_split(strrev((string) $order_id));
            foreach ($cdida as $v) {
                $cdid .= $chars[rand(0, $csl)] . $v;
            }
            $cdid .= $chars[rand(0, $csl)];
            update_post_meta($order_id, 'collective_delivery_id', $cdid);
            update_post_meta($order_id, 'collective_delivery_shipping', $_POST['cd_owner']);
            update_post_meta($order_id, 'collective_delivery_state', 'open');
            update_post_meta($order_id, 'collective_delivery_join_orders', array());
        }
    }
});

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="action - woocommerce_thankyou">

add_action('woocommerce_thankyou', function ($order_id) {
    WC()->session->set('collective_delivery_type', null);
    WC()->session->set('collective_delivery_owner', null);
    WC()->session->set('collective_delivery_code', null);
    $cdid = get_post_meta($order_id, 'collective_delivery_id', true);
    if ($cdid) {
        echo '<p>' . __('Gyűjő szállítást kért, melynek azonosítója: ', 'collectivedelivery') . '<strong>' . $cdid . '</strong></p>';
    } else {
        $cdid = get_post_meta($order_id, 'collective_delivery_joined_id', true);
        if ($cdid) {
            echo '<p>' . __('Csatlakozott egy gyűjő szállításhoz, melynek azonosítója: ', 'collectivedelivery') . '<strong>' . $cdid . '</strong></p>';
        }
    }
});

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="action - woocommerce_email_before_order_table">

add_action('woocommerce_email_before_order_table', function($order, $sent_to_admin) {
    $cdid = get_post_meta($order->get_id(), 'collective_delivery_id', true);
    if ($cdid) {
        echo '<p>';
        if ($sent_to_admin) {
            echo __('Gyűjtő azonosító: ', 'collectivedelivery') . '<strong>' . $cdid . '</strong>';
        } else {
            echo __('Gyűjő szállítást kért, melynek azonosítója: ', 'collectivedelivery') . '<strong>' . $cdid . '</strong>';
            echo '<br/><i>';
            $link=esc_url($order->get_view_order_url());
            echo __('Lezárni a gyűjtő szállítást, bejelentkezés után a "Fiókom/Rendelések" menüpont alatt tudja, amit itt talál meg: ','collectivedelivery');
	    echo '<a href="' . $link . '">'.__('Rendelés','collectivedelivery').'</a>';
            echo '</i>';
        }
        echo '</p>';
    } else {
        $cdid = get_post_meta($order->get_id(), 'collective_delivery_joined_id', true);
        if ($cdid) {
            echo '<p>';
            if ($sent_to_admin) {
                $cdoid = get_post_meta($order->get_id(), 'collective_delivery_joined_order', true);
                echo __('Csatlakozott gyűjtő azonosító: ', 'collectivedelivery') . '<strong>' . $cdid . '</strong><br/>';
                echo __('Csatlakozott rendelés azonosító: ', 'collectivedelivery') . '<strong>' . $cdoid . '</strong>';
            } else {
                echo __('Csatlakozott egy gyűjő szállításhoz, melynek azonosítója: ', 'collectivedelivery') . '<strong>' . $cdid . '</strong>';
            }
            echo '</p>';
        }
    }
}, 10, 2);

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="action - woocommerce_view_order">

add_action('woocommerce_view_order', function ($order_id) {
    $cdid = get_post_meta($order_id, 'collective_delivery_id', true);
    if ($cdid) {
        $cdorders = get_post_meta($order_id, 'collective_delivery_join_orders', true);
        $cdstate = get_post_meta($order_id, 'collective_delivery_state', true);
        if ($cdstate == 'open' && isset($_GET['close'])) {
            $cdstate = 'close';
            update_post_meta($order_id, 'collective_delivery_state', $cdstate);
            $order = wc_get_order($order_id);
            $order->add_order_note(__('Gyűjtő szállítás lezárása.', 'collectivedelivery'), 0, true);
        }
        $states = array();
        echo '<h2>' . __('Gyűjő szállítás', 'collectivedelivery') . '</h2>';
        echo '<p>';
        echo __('Gyűjő szállítást kért, melynek azonosítója: ', 'collectivedelivery') . '<strong>' . $cdid . '</strong><br/>';
        echo __('Csatlakozott rendelések azonosítói: ', 'collectivedelivery') . '<strong>' . (empty($cdorders) ? '-' : implode(', ', $cdorders)) . '</strong><br/>';
        echo __('Státusz: ', 'collectivedelivery') . '<strong>' . WC_Collective_Delivery::state_titles()[$cdstate] . '</strong>';
        if ($cdstate == 'open') {
            echo '<br/><a class="button" href="?close">' . __('lezár', 'collectivedelivery') . '</a>';
        }
        echo '</p>';
    } else {
        $cdid = get_post_meta($order_id, 'collective_delivery_joined_id', true);
        if ($cdid) {
            echo '<h2>' . __('Gyűjő szállítás', 'collectivedelivery') . '</h2>';
            echo '<p>' . __('Csatlakozott egy gyűjő szállításhoz, melynek azonosítója: ', 'collectivedelivery') . '<strong>' . $cdid . '</strong></p>';
        }
    }
    return true;
}, 100);

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="action - woocommerce_admin_order_data_after_shipping_address">

add_action('woocommerce_admin_order_data_after_shipping_address', function ($order) {
    /* @var $order WC_Order */
    $cdid = get_post_meta($order->id, 'collective_delivery_id', true);
    if ($cdid) {
        $cdorders = get_post_meta($order->id, 'collective_delivery_join_orders', true);
        $cdshipping = get_post_meta($order->id, 'collective_delivery_shipping', true);
        $cdstate = get_post_meta($order->id, 'collective_delivery_state', true);
        if ($cdstate == 'open' && isset($_GET['close'])) {
            $cdstate = 'close';
            update_post_meta($order->id, 'collective_delivery_state', $cdstate);
            $order->add_order_note(__('Gyűjtő szállítás lezárása.', 'collectivedelivery'), 0, true);
        } else if ($cdstate == 'close' && isset($_GET['open'])) {
            $cdstate = 'open';
            update_post_meta($order->id, 'collective_delivery_state', $cdstate);
            $order->add_order_note(__('Gyűjtő szállítás megnyitása.', 'collectivedelivery'), 0, true);
        }
        $states = array();
        echo '<h4>' . __('Gyűjtő szállítás adatok', 'collectivedelivery') . '</h4>';
        echo '<script type="text/javascript">';
        echo '(function ($) {';
        if ($cdstate == 'open') {
            echo '$("#order_status").select2({disabled: true});';
        }
        echo "$('#custom_order_option div.inside').html('<a href=\"admin.php?page=group_orders_list&action=details&group=" . $cdid . "&_wpnonce=" . wp_create_nonce('sp_customer') . "\">" . __('Gyűjtő szállítás rendelések...', 'collectivedelivery') . "</a>');";
        echo '})(jQuery);';
        echo '</script>';
        echo '<p>';
        echo __('Gyűjő szállítást kért, melynek azonosítója: ', 'collectivedelivery') . '<a href="edit.php?s=' . $cdid . '&post_type=shop_order"><strong>' . $cdid . '</strong></a>';
        echo '<br/>' . __('Csatlakozott rendelések azonosítói: ', 'collectivedelivery');
        if (empty($cdorders)) {
            echo '-';
        } else {
            $cdoa = array();
            foreach ($cdorders as $cdo) {
                $cdoa[] = '<a about="_blank" href="?post=' . $cdo . '&action=edit">#' . $cdo . '</a>';
            }
            echo implode(' ', $cdoa);
        }
        echo '<br/>';
        echo __('Státusz: ', 'collectivedelivery') . '<strong>' . WC_Collective_Delivery::state_titles()[$cdstate] . '</strong>';
        if ($cdstate == 'open') {
            echo '<br/><a class="button button-primary" href="?post=' . $order->id . '&action=edit&close">' . __('lezár', 'collectivedelivery') . '</a>';
        } else if ($cdstate == 'close' && in_array($order->get_status(), array('pending', 'processing', 'order-placed'))) {
            echo '<br/><a class="button button-primary" href="?post=' . $order->id . '&action=edit&open">' . __('megnyit', 'collectivedelivery') . '</a>';
        }
        echo '</p>';
    } else {
        $cdid = get_post_meta($order->id, 'collective_delivery_joined_id', true);
        if ($cdid) {
            $cdoid = get_post_meta($order->id, 'collective_delivery_joined_order', true);
            echo '<h4 id="collective_delivery_admin_title">' . __('Gyűjtő szállítás adatok', 'collectivedelivery') . '</h4>';
            echo '<script type="text/javascript">';
            echo '(function ($) {';
            echo "$('#collective_delivery_admin_title').parent().find('a.edit_address').remove();";
            echo "$('#custom_order_option div.inside').html('<a href=\"admin.php?page=group_orders_list&action=details&group=" . $cdid . "&_wpnonce=" . wp_create_nonce('sp_customer') . "\">" . __('Gyűjtő szállítás rendelések...', 'collectivedelivery') . "</a>');";
            echo '})(jQuery);';
            echo '</script>';
            echo '<p>';
            echo __('Csatlakozott egy gyűjő szállításhoz, melynek azonosítója: ', 'collectivedelivery') . '<a href="edit.php?s=' . $cdid . '&post_type=shop_order"><strong>' . $cdid . '</strong></a>';
            echo '<br/>' . __('A gyűjtő szállítás indítójának rendelés azonosítója: ', 'collectivedelivery') . '<a about="_blank" href="?post=' . $cdoid . '&action=edit">#' . $cdoid . '</a>';
            echo '</p>';
        }
    }
}, 1, 1);

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="action - woocommerce_saved_order_items">

add_action('woocommerce_saved_order_items', function($order_id, $items) {
    $shippingAddressPost = array(
        'first_name' => $items['_shipping_first_name'],
        'last_name' => $items['_shipping_last_name'],
        'company' => $items['_shipping_company'],
        'address_1' => $items['_shipping_address_1'],
        'address_2' => $items['_shipping_address_2'],
        'address_3' => $items['_shipping_address_3'],
        'address_4' => $items['_shipping_address_4'],
        'city' => $items['_shipping_city'],
        'postcode' => $items['_shipping_postcode'],
        'country' => $items['_shipping_country'],
        'state' => $items['_shipping_state'],
    );
    $order = wc_get_order($order_id);
    $shippingAddress = $order->get_address('shipping');
    if ($shippingAddress !== $shippingAddressPost) {
        $cdid = get_post_meta($order_id, 'collective_delivery_id', true);
        if ($cdid) {
            $cdorders = get_post_meta($order->id, 'collective_delivery_join_orders', true);
            if (!empty($cdorders)) {
                foreach ($cdorders as $cdoid) {
                    $o = wc_get_order($cdoid);
                    $o->set_address($shippingAddressPost, 'shipping');
                    $o->save_meta_data();
                }
            }
        }
    }
}, 10, 2);

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="filter - woocommerce_shop_order_search_fields">

add_filter('woocommerce_shop_order_search_fields', function ($search_fields) {
    $search_fields[] = 'collective_delivery_id';
    $search_fields[] = 'collective_delivery_joined_id';
    $search_fields[] = 'collective_delivery_joined_order';
    return $search_fields;
}, 10, 1);

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="filter - woocommerce_order_shipping_method">

add_filter('woocommerce_order_shipping_method', function ($names, $order) {
    /* @var $order WC_Order */
    $cdid = get_post_meta($order->get_id(), 'collective_delivery_id', true);
    if ($cdid) {
        $cdshipping = get_post_meta($order->get_id(), 'collective_delivery_shipping', true);
        $names .= '; '.__('Kezdeményező','collectivedelivery').'; ' . WC_Collective_Delivery::shipping_titles()[$cdshipping] . ' - ' . $cdid;
    } else {
        $cdid = get_post_meta($order->get_id(), 'collective_delivery_joined_id', true);
        if ($cdid) {
            $names .= '; '.__('Csatlakozó.','collectivedelivery').' - ' . $cdid;
        }
    }
    return $names;
}, 10, 2);

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="hourly event">

if (!wp_next_scheduled('wc_collective_delivery_hourly_event')) {
    wp_schedule_event(time(), 'hourly', 'wc_collective_delivery_hourly_event');
}
add_action('wc_collective_delivery_hourly_event', function() {
    $hours = (int) get_option('wc_collective_delivery_autoclose_hours', 24);
    if (!$hours) {
        $hours = 24;
    }
    $posts = get_posts(
            array(
                'numberposts' => -1,
                'meta_key' => 'collective_delivery_state',
                'meta_value' => 'open',
                'post_type' => wc_get_order_types(),
                'post_status' => array_keys(wc_get_order_statuses()),
            )
    );
    $toDatetime = new DateTime();
    $diffToHours = function (DateTime $fromDatetime) use ($toDatetime) {
        $di = $fromDatetime->diff($toDatetime);
        $return = (int) $di->format('%r%a') * (60 * 60 * 24);
        $return += (int) $di->format('%r%h') * (60 * 60);
        $return += (int) $di->format('%r%i') * (60);
        $return += (int) $di->format('%r%s');
        return (int) ($return / (60 * 60));
    };
    if ($posts) {
        foreach ($posts as $post) {
            /* @var $order WC_Order */
            $order = wc_get_order($post->ID);
            if ($diffToHours($order->get_date_created()) < $hours) {
                continue;
            }
            update_post_meta($order->get_id(), 'collective_delivery_state', 'close');
            $order->add_order_note(__('Gyűjtő szállítás automatikus lezárása.', 'collectivedelivery'));
        }
    }
});

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="the class">

class WC_Collective_Delivery {

    protected static $version;
    protected static $plugin_prefix;
    protected static $plugin_url;
    protected static $plugin_path;
    protected static $plugin_basename;

    public function __construct() {
        self::$version = '1.0';
        self::$plugin_prefix = 'wc_collective_delivery_';
        self::$plugin_basename = plugin_basename(__FILE__);
        self::$plugin_url = plugin_dir_url(self::$plugin_basename);
        self::$plugin_path = trailingslashit(dirname(__FILE__));
    }

    public static function get_version() {
        return self::$version;
    }

    public static function get_plugin_prefix() {
        return self::$plugin_prefix;
    }

    public static function get_plugin_url() {
        return self::$plugin_url;
    }

    public static function get_plugin_path() {
        return self::$plugin_path;
    }

    public static function get_plugin_basename() {
        return self::$plugin_basename;
    }

    public static function get_rate_by_post() {
        $idx = '';
        $chosen_methods = WC()->session->get('chosen_shipping_methods');
        if (isset($chosen_methods[0]) && strstr($chosen_methods[0], 'collective_delivery')) {
            $idx = '__cd__';
            $post_arr = array();
            if (isset($_POST['post_data'])) {
                parse_str($_POST['post_data'], $post_arr);
            } else {
                $post_arr = $_POST;
            }
            //print_r($post_arr);
            if (isset($post_arr['cd_type'])) {
                if ($post_arr['cd_type'] == 'join') {
                    $idx = '__cd__join__';
                } else if ($post_arr['cd_type'] == 'owner') {
                    if (isset($post_arr['cd_owner'])) {
                        $packages = WC()->shipping->get_packages();
                        $fri = 'flat_rate:2';
                        $psi = 'pont_sprinter:3';
                        if (isset($packages[0]['rates'])) {
                            foreach (array_keys($packages[0]['rates']) as $rate) {
                                $rate = explode(':', $rate);
                                if ($rate[0] == 'flat_rate' && isset($rate[1])) {
                                    $fri = 'flat_rate:' . $rate[1];
                                }
                                if ($rate[0] == 'pont_sprinter' && isset($rate[1])) {
                                    $psi = 'pont_sprinter:' . $rate[1];
                                }
                            }
                            if ($post_arr['cd_owner'] == 'flat_rate') {
                                $idx = $fri;
                            } else if ($post_arr['cd_owner'] == 'pont_sprinter') {
                                $idx = $psi;
                            }
                        }
                    }
                }
            }
        }
        return $idx;
    }

    public static function state_titles() {
        return array(
            'open' => __('nyitott', 'collectivedelivery'),
            'close' => __('lezárt', 'collectivedelivery'),
        );
    }

    public static function shipping_titles() {
        return array(
            'flat_rate' => __('Házhozszállítás', 'collectivedelivery'),
            'pont_sprinter' => __('PickPackPont', 'collectivedelivery'),
        );
    }

    /**
     *
     * @staticvar \WC_Collective_Delivery $instance
     * @return \WC_Collective_Delivery
     */
    public static function instance() {
        static $instance = null;
        if (!$instance) {
            $instance = new static();
        }
        return $instance;
    }

}

WC_Collective_Delivery::instance();

// </editor-fold>
