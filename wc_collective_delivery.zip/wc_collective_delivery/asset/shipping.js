/* global initWCSPPP, google */

var selMethod;
var selcdType;
var selcdOwner;
var valasztott;

jQuery(document).ready(function ($) {
    $('form[name="checkout"]').on('keyup keypress', function (e) {
        var keyCode = e.keyCode || e.which;
        if (keyCode === 13) {
            e.preventDefault();
            return false;
        }
    });
    $('form[name="checkout"]').on('submit', function (e) {
        e.preventDefault();
    });

    selMethod = $('#shipping_method input[checked="checked"]').val();
    selcdType = $('#collective_delivery_block input.cd_types[checked="checked"]').val();
    selcdOwner = $('#collective_delivery_block input.cd_owners[checked="checked"]').val();
    s_shipment_method_change();
    $(document).on('change', "#shipping_method input", function (e) {
        e.preventDefault();
        selMethod = $(this).val();
        s_shipment_method_change();
    });
    $(document).on('change', 'input[name="cd_type"]', function () {
        selcdType = $(this).val();
        $("#shipping_method input").trigger('change');
    });
    $(document).on('change', 'input[name="cd_owner"]', function () {
        selcdOwner = $(this).val();
        $('#cd_type_owner_price').html($('label[for="cd_owner_' + $(this).val() + '"] .cd_type_owner_price').html());
        $("#shipping_method input").trigger('change');
    });
});

function s_shipment_method_change() {
valasztott=jQuery('#shipping_method input[type=radio]:checked').val();
//console.log(valasztott);
    $ = jQuery;
    $('input[id^="shipping_method_0_collective_delivery"]').parent().removeClass('active');
    $('#collective_delivery_tr').css('display', 'none');
    var chdiff = $('#ship-to-different-address-checkbox');
    var fextra = $(".woocommerce-shipping-fields-extra");
    chdiff.attr('checked', false).trigger('change');
    fextra.hide();
    if (selMethod) {
//console.log("selmethod:");
//console.log(selMethod);
        $('input[name="payment_method"]').prop('disabled', false);
        if (valasztott.match(/collective_delivery/g)) {
            $('input[id^="shipping_method_0_collective_delivery"]').parent().addClass('active');
            $('#collective_delivery_tr').css('display', 'table-row');
            if (selcdType === 'owner') {
                $('.cd_first').css('display', 'block');
                $('#cd_join_code').val('');
                $('#cd_join_code').prop('disabled', true);
                $('#cd_join_code_checked').val('');
                $('#cd_join_code_checked').prop('disabled', true);
                $('#collective_delivery_join_code_check_button').prop('disabled', true);
                if (selcdOwner === 'flat_rate') {
                    $('#cd_type_owner_price').css('visibility', 'visible');
                    $(".flat_rate.woocommerce-shipping-fields-extra").show();
                } else if (selcdOwner === 'pont_sprinter') {
                    $('#cd_type_owner_price').css('visibility', 'visible');
                    $(".sprinter_ppp.woocommerce-shipping-fields-extra").show();
                } else {
                    $('#cd_type_owner_price').css('visibility', 'hidden');
                }
            } else if (selcdType === 'join') {
                $('.cd_first').css('display', 'none');
                $('#cd_join_code').removeAttr('disabled');
                $('#cd_join_code_checked').removeAttr('disabled');
                $('#collective_delivery_join_code_check_button').removeAttr('disabled');
                $('#cd_type_owner_price').css('visibility', 'hidden');
            } else {
                $('.cd_first').css('display', 'none');
                $('#cd_join_code').val('');
                $('#cd_join_code').prop('disabled', true);
                $('#cd_join_code_checked').val('');
                $('#cd_join_code_checked').prop('disabled', true);
                $('#collective_delivery_join_code_check_button').prop('disabled', true);
                $('#cd_type_owner_price').css('visibility', 'hidden');
            }
            if (typeof initWCCD == 'function') {
                initWCCD();
            }
	
        } else if (selMethod.match(/local_pickup/g)) {
            chdiff.attr('checked', false).trigger('change');
            fextra.hide();
        } else if (selMethod.match(/pont_sprinter/g)) {
            chdiff.attr('checked', false).trigger('change');
            fextra.hide();
            $(".sprinter_ppp.woocommerce-shipping-fields-extra").show();
            if (typeof initWCSPPP == 'function') {
                initWCSPPP();
            }
        } else if (selMethod.match(/flat_rate/g)) {
            chdiff.attr('checked', false).trigger('change');
            chdiff.attr('disabled', false);
            $(".flat_rate.woocommerce-shipping-fields-extra").show();

        } else {
            console.log('DEBUG: s_shipment_method_change');
        }
    } else {
        $('input[name="payment_method"]').prop('disabled', true).prop('checked', false);
        $('div.payment_box').hide();
    }
}

