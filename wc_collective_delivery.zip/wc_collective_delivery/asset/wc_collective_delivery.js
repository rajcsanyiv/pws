(function ($) {
    initWCCD = function () {
        var cdjcok = function (payment) {
            $('#cd_join_code_checked').removeAttr('disabled');
            $('#cd_join_code').removeClass('_error').addClass('_ok');
            $('input[name="payment_method"]').prop('disabled', true);
            $('div.payment_box').hide();
            $('#payment_method_' + payment).prop('checked', true).prop('disabled', false).trigger('change');
            $('div.payment_box.payment_method_' + payment).show();
        };
        $('#cd_join_code').removeClass('_ok').removeClass('_error');
        if ($('#cd_join_code_checked').val() === 'ok') {
            var payment = $('input[name="payment_method"]:checked').length ? $('input[name="payment_method"]:checked').val() : 'cod';
            cdjcok(payment);
        }
        $('#collective_delivery_join_code_check_button').unbind('click').click(function (e) {
            e.preventDefault();
            var cdid = $('#cd_join_code').val();
            if (cdid) {
//                $('#collective_delivery_shipping_info').remove();
                $('#cd_second .load-spinner').css('display', 'block');
		jQuery.post(ajaxurl, {'action': 'collective_delivery_join_code_check', 'cdid': cdid}, function (res) {
                    $('#cd_second .load-spinner').css('display', 'none');
                    if (res.errormsg) {
                        $('#cd_join_code').removeClass('_ok').addClass('_error');
                        alert(res.errormsg);
                    } else {
                        $('#cd_join_code_checked').val('ok');
                        cdjcok(res.payment);
                        res.info += $.trim($('label[for="payment_method_' + res.payment + '"]').text());
                        alert(res.info);
//                        var info = '<div id="collective_delivery_shipping_info" style="display: none; margin: 10px 20px;">';
//                        info += '<input type="hidden" name="collective_delivery_id" value="' + cdid + '"/>';
//                        info += '<strong>Sikeresen csatlakozott a(z) <i>' + cdid + '</i> azonosítójú gyűjtő szállításhoz.</strong><br/>';
//                        info += '<u>Szállítási adatok:</u>';
//                        info += ' ' + (res.ppp ? 'PickPackPont' : 'Házhozszállítás');
//                        info += '<br/>';
//                        if (res.ppp) {
//                            info += '&bull; <i>azonosító:</i> ' + res.ppp.code + '<br>';
//                            info += '&bull; <i>név:</i> ' + res.ppp.name + '<br>';
//                            info += '&bull; <i>cím:</i> ' + res.ppp.address + '<br>';
//                        } else {
//                            $.each(res.orderAddress, function (k, v) {
//                                var label = $('label[for="shipping_' + k + '"]').text().replace('*', '').trim();
//                                if (label) {
//                                    info += '&bull; <i>' + label + ':</i> ';
//                                    info += (k === 'country' ? $('#shipping_' + k + ' option[value="' + v + '"]').text() : v) + '<br/>';
//                                }
//                                $('#shipping_' + k).val(v);
//                                //$('#shipping_' + k).val(v).attr('disabled', true);
//                            });
//                        }
//                        info += '<u>Fizetési mód:</u> ' + $('label[for="payment_method_' + res.payment + '"]').text() + '<br/>';
//                        info += '</div>';
//                        $('div.collective_delivery').append(info);
//                        $('#collective_delivery_shipping_info').fadeIn();
//                        if (!res.ppp) {
//                            $('#ship-to-different-address-checkbox').attr('checked', true).trigger('change');
//                            //$('#ship-to-different-address-checkbox').attr('disabled', true);
//                        }
                    }
                });
            } else {
                alert('Kérem adjon meg egy gyűjtő azonosítót!');
            }
        });
    };
})(jQuery);
