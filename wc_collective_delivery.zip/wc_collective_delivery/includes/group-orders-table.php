<?php

class Group_Orders_Table extends WP_List_Table {

    public static function get_customers( $per_page = 50, $page_number = 1 ) {
        global $wpdb;

        $sql="SELECT state.meta_value as state,members.meta_value as members,ID,post_date FROM {$wpdb->prefix}posts 
            join {$wpdb->prefix}postmeta as delivery ON
            delivery.post_id={$wpdb->prefix}posts.ID
            join {$wpdb->prefix}postmeta as members ON
            members.post_id={$wpdb->prefix}posts.ID
            join {$wpdb->prefix}postmeta as state ON
            state.post_id={$wpdb->prefix}posts.ID
            WHERE delivery.meta_key=\"collective_delivery_id\"
            and members.meta_key=\"collective_delivery_join_orders\"
            and state.meta_key=\"collective_delivery_state\"
	    order by post_date desc";

        $sql .= " LIMIT $per_page";
        $sql .= ' OFFSET ' . ( $page_number - 1 ) * $per_page;
        $result = $wpdb->get_results( $sql, 'ARRAY_A' );
	return $result;
    }
     
    public static function get_orders( $per_page = 50, $page_number = 1 ) {
        global $wpdb;

        $sql2="SELECT wp_users.user_nicename as name, customer.post_id as ID, wp_posts.post_date as order_date FROM {$wpdb->prefix}posts
            join {$wpdb->prefix}postmeta as collection
            on {$wpdb->prefix}posts.ID = collection.post_id
            join {$wpdb->prefix}postmeta as customer
            on {$wpdb->prefix}posts.ID = customer.post_id
            join {$wpdb->prefix}users
            on {$wpdb->prefix}users.ID = customer.meta_value
            WHERE
            (collection.meta_key='collective_delivery_joined_id'
            AND
            customer.meta_key='_customer_user'
            AND
            collection.meta_value=".esc_sql( $_REQUEST['group'] ).") OR (collection.meta_key='collective_delivery_id'
            AND
            customer.meta_key='_customer_user'
            AND
            collection.meta_value=".esc_sql( $_REQUEST['group'] ).")";
	    
        $result = $wpdb->get_results( $sql2, 'ARRAY_A' );
	return $result;
    }   

    public function __construct() {
        parent::__construct( array(
            'singular' => __('rendelés','collectivedelivery'),     
            'plural'   => __('rendelések','collectivedelivery'),    
            'ajax'     => false,       
	) );
    }

	
    public function get_columns() {
        if ( 'details' === $this->current_action() ) {
            $columns = ['name' => __( 'Név','collectivedelivery' ),
                        'order_date' => __( 'Rendelés dátuma','collectivedelivery' ),
                        'value' => __( 'Rendelés értéke','collectivedelivery' ),
			'szamla' => __( 'Számla','collectivedelivery' )];
        }
        else {
            $columns = [
            'ID'    => __( 'Indító rendelés','collectivedelivery' ),
            'post_date' => __( 'Dátum','collectivedelivery' ),
            'members' => __( 'Csatlakozott rendelések','collectivedelivery' ),
            'state' => __( 'Állapot','collectivedelivery')];
        }
        return $columns;
    }

	
    protected function get_sortable_columns() {
	}

    function column_szamla( $item ){
        //echo "<script type='text/javascript' src='http://192.168.0.2/safisdev4/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70'></script>";
	$order = new WC_Order($item[ 'ID' ]);
?>
<?php if(!get_option('wc_szamlazz_username') || !get_option('wc_szamlazz_password')): ?>
	<p style="text-align: center;"><?php _e('A számlakészítéshez meg kell adnod a számlázz.hu felhasználóneved és jelszavad a Woocommerce beállításokban!','collectivedelivery'); ?></p>
<?php else: ?>
	<div id="wc-szamlazz-messages<?php echo $item[ 'ID' ]; ?>"></div>
	<?php if(get_post_meta($item['ID'],'_wc_szamlazz_own',true)): ?>
            <div style="text-align:center;" id="szamlazz_already_div<?php echo $item[ 'ID' ]; ?>">
            <?php $note = get_post_meta($item['ID'],'_wc_szamlazz_own',true); ?>
            <p><?php _e('A számlakészítés ki lett kapcsolva, mert: ','collectivedelivery'); ?><strong><?php echo $note; ?></strong><br>
            <a id="wc_szamlazz_already_back<?php echo $item[ 'ID' ]; ?>" href="#" data-nonce="<?php echo wp_create_nonce( "wc_already_invoice" ); ?>" data-order="<?php echo $item['ID']; ?>"><?php _e('Visszakapcsolás','collectivedelivery'); ?></a>
            </p>
            </div>
	<?php endif; ?>
	<?php if(get_post_meta($item['ID'],'_wc_szamlazz_dijbekero_pdf',true)): ?>
            <p>Díjbekérő <span class="alignright"><?php echo get_post_meta($item['ID'],'_wc_szamlazz_dijbekero',true); ?> - <a href="<?php echo $this->generate_download_link($item['ID'],true); ?>"><?php _e('Letöltés','collectivedelivery')?></a></span></p>
            <hr/>
        <?php endif; ?>
        <?php if($this->is_invoice_generated($item['ID']) && !get_post_meta($item['ID'],'_wc_szamlazz_own',true)): ?>
            <div style="text-align:center;" id="wc-szamlazz-generate-button<?php echo $item['ID'];?>">
            <div id="wc-szamlazz-generated-data<?php echo $item[ 'ID' ]; ?>">
            <p><?php echo __('Számla sikeresen létrehozva és elküldve a vásárlónak emailben.','collectivedelivery'); ?></p>
            <p><?php _e('A számla sorszáma:','colectivedelivery'); ?> <strong><?php echo get_post_meta($item['ID'],'_wc_szamlazz',true); ?></strong></p>
            <p><a href="<?php echo $this->generate_download_link($item['ID']); ?>" id="wc_szamlazz_download<?php echo $item[ 'ID' ]; ?>" data-nonce="<?php echo wp_create_nonce( "wc_generate_invoice" ); ?>" class="button button-primary" target="_blank"><?php _e('Számla megtekintése','collectivedelivery'); ?></a></p>
            <?php if(!get_post_meta($item['ID'],'_wc_szamlazz_jovairas',true)): ?>
		<p><a href="#" id="wc_szamlazz_generate_complete<?php echo $item[ 'ID' ]; ?>" data-order="<?php echo $item['ID']; ?>" data-nonce="<?php echo wp_create_nonce( "wc_generate_invoice" ); ?>" target="_blank"><?php _e('Teljesítve','collectivedelivery'); ?></a></p>
            <?php else: ?>
		<p><?php _e('Jóváírás rögzítve','collectivedelivery'); ?>: <?php echo date('Y-m-d',get_post_meta($item['ID'],'_wc_szamlazz_jovairas',true)); ?></p>
	<?php endif; ?>
            </div>
            <p class="plugins"><a href="#" id="wc_szamlazz_generate_sztorno<?php echo $item[ 'ID' ]; ?>" data-order="<?php echo $item['ID']; ?>" data-nonce="<?php echo wp_create_nonce( "wc_generate_invoice" ); ?>" class="delete"><?php _e('Sztornózás','collectivedelivery'); ?></a></p>
            </div>
	<?php else: ?>
            <div style="text-align:center;<?php if(get_post_meta($item['ID'],'_wc_szamlazz_own',true)): ?>display:none;<?php endif; ?>" id="wc-szamlazz-generate-button<?php echo $item['ID'];?>">
            <p><a href="#" id="wc_szamlazz_generate<?php echo $item['ID'];?>" data-order="<?php echo $item['ID']; ?>" data-nonce="<?php echo wp_create_nonce( "wc_generate_invoice" ); ?>" class="button button-primary" target="_blank"><?php _e('Számlakészítés','collectivedelivery'); ?></a><br><a href="#" id="wc_szamlazz_options<?php echo $item['ID']; ?>"><?php _e('Opciók','collectivedelivery'); ?></a></p>
            <div id="wc_szamlazz_options_form<?php echo $item['ID']; ?>" style="display:none;">
            <div class="fields">
            <h4><?php _e('Megjegyzés','collectivedelivery'); ?></h4>
            <input type="text" id="wc_szamlazz_invoice_note<?php echo $item['ID'];?>" value="<?php echo get_option('wc_szamlazz_note'); ?>" />
            <h4><?php _e('Fizetési határidő(nap)','collectivedelivery'); ?></h4>
            <input type="text" id="wc_szamlazz_invoice_deadline<?php echo $item[ 'ID' ]; ?>" value="<?php echo get_option('wc_szamlazz_payment_deadline'); ?>" />
            <h4><?php _e('Teljesítés dátum','collectivedelivery'); ?></h4>
            <input type="text" class="date-picker" id="wc_szamlazz_invoice_completed<?php echo $item['ID'];?>" maxlength="10" value="<?php echo date('Y-m-d'); ?>" pattern="[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])">
            <h4><?php _e('Díjbekérő számla','collectivedelivery'); ?></h4>
            <input type="checkbox" id="wc_szamlazz_invoice_request<?php echo $item[ 'ID' ]; ?>" value="1" />
            </div>
            <a id="wc_szamlazz_already<?php echo $item[ 'ID' ]; ?>" href="#" data-nonce="<?php echo wp_create_nonce( "wc_already_invoice" ); ?>" data-order="<?php echo $item['ID']; ?>"><?php _e('Számlakészítés kikapcsolása','collectivedelivery'); ?></a>
            </div>
            <?php if(get_option('wc_szamlazz_auto') == 'yes'): ?>
            <p><small><?php _e('A számla automatikusan elkészül és el lesz küldve a vásárlónak, ha a rendelés állapota befejezettre lesz átállítva.','collectivedelivery'); ?></small></p>
	<?php endif; ?>
            </div>
	<?php if(get_post_meta($item['ID'],'_wc_szamlazz_sztorno',true)): ?>
            <p>Sztornó számla: <span class="alignright">
                <?php 
                    echo get_post_meta($item['ID'],'_wc_szamlazz_sztorno',true); 
                ?> 
                - <a href="
                <?php 
                    echo $this->generate_download_link($item['ID'],false,true); 
                ?>
                " target="_blank">
                <?php 
                    _e('Letöltés','collectivedelivery');
                ?>
                </a></span></p>
	<?php endif; ?>
    <?php endif; ?>
<?php endif; ?>
<script type="text/javascript">
$(document).ready(function(){
$('#wc_szamlazz_generate<?php echo $item[ 'ID' ]; ?>').click(function(e) {
    e.preventDefault();
    var r = confirm(""<?php e_('Biztosan létrehozod a számlát?','collectivedelivery'); ?>""); 
    if (r != true) {
      return false;
    }
    var nonce = $(this).data('nonce');
    var order = $(this).data('order');
    var button = $('#wc-szamlazz-generate-button<?php echo $item[ 'ID' ]; ?>');
    var note = $('#wc_szamlazz_invoice_note<?php echo $item[ 'ID' ]; ?>').val();
    var deadline = $('#wc_szamlazz_invoice_deadline<?php echo $item[ 'ID' ]; ?>').val();
    var completed = $('#wc_szamlazz_invoice_completed<?php echo $item[ 'ID' ]; ?>').val();
    var request = $('#wc_szamlazz_invoice_request<?php echo $item[ 'ID' ]; ?>').is(':checked');
    if (request) {
      request = 'on';
    } else {
      request = 'off';
    }

var data = {
      action: 'wc_szamlazz_generate_invoice',
      nonce: nonce,
      order: order,
      note: note,
      deadline: deadline,
      completed: completed,
      request: request
    };

alert("action"+data.action+"data"+JSON.stringify(data)+"nonce"+nonce+"order"+order);
    button.block({
      message: null,
      overlayCSS: {
        background: '#fff url(' + wc_szamlazz_params.loading + ') no-repeat center',
        backgroundSize: '16px 16px',
        opacity: 0.6
      }
    });

alert("post ajax");

    $.post(ajaxurl, data, function(response) {
      //Remove old messages
      $('.wc-szamlazz-message<?php echo $item[ 'ID' ]; ?>').remove();

      var responseText = response;

      //Generate the error/success messages
      if (responseText.data.error) {
        button.before('<div class="wc-szamlazz-error<?php echo $item[ 'ID' ]; ?> error wc-szamlazz-message<?php echo $item[ 'ID' ]; ?>"></div>');
      } else {
        button.before('<div class="wc-szamlazz-success<?php echo $item[ 'ID' ]; ?> updated wc-szamlazz-message<?php echo $item[ 'ID' ]; ?>"></div>');
      }

      //Get the error messages
      var ul = $('<ul>');
      $.each(responseText.data.messages, function(i, value) {
        var li = $('<li>')
        li.append(value);
        ul.append(li);
      });
      $('.wc-szamlazz-message<?php echo $item[ 'ID' ]; ?>').append(ul);

      //If success, hide the button
      if (!responseText.data.error) {
        button.slideUp();
        button.before(responseText.data.link);
      }

      button.unblock();


    });
  });

  $('#wc_szamlazz_options<?php echo $item[ 'ID' ]; ?>').click(function() {
    $('#wc_szamlazz_options_form<?php echo $item[ 'ID' ]; ?>').slideToggle();
    return false;
  });

  $('#wc_szamlazz_already<?php echo $item[ 'ID' ]; ?>').click(function(e) {
    e.preventDefault();
    var note = prompt(""<?php e_('Számlakészítés kikapcsolása. Mi az indok?','collectivedelivery'); ?>"", ""<?php _e('Ehhez a rendeléshez nem kell számla.','collectivedelivery'); ?>"");
    if (!note) {
      return false;
    }

    var nonce = $(this).data('nonce');
    var order = $(this).data('order');
    var button = $('#wc-szamlazz-generate-button<?php echo $item[ 'ID' ]; ?>');

    var data = {
      action: 'wc_szamlazz_already',
      nonce: nonce,
      order: order,
      note: note
    };

    button.block({
      message: null,
      overlayCSS: {
        background: '#fff url(' + wc_szamlazz_params.loading + ') no-repeat center',
        backgroundSize: '16px 16px',
        opacity: 0.6
      }
    });

    $.post(ajaxurl, data, function(response) {
      //Remove old messages
      $('.wc-szamlazz-message<?php echo $item[ 'ID' ]; ?>').remove();

      var responseText = response;

      //Generate the error/success messages
      if (responseText.data.error) {
        button.before('<div class="wc-szamlazz-error<?php echo $item[ 'ID' ]; ?> error wc-szamlazz-message<?php echo $item[ 'ID' ]; ?>"></div>');
      } else {
        button.before('<div class="wc-szamlazz-success<?php echo $item[ 'ID' ]; ?> updated wc-szamlazz-message<?php echo $item[ 'ID' ]; ?>"></div>');
      }

      //Get the error messages
      var ul = $('<ul>');
      $.each(responseText.data.messages, function(i, value) {
        var li = $('<li>')
        li.append(value);
        ul.append(li);
      });
      $('.wc-szamlazz-message<?php echo $item[ 'ID' ]; ?>').append(ul);

      //If success, hide the button
      if (!responseText.data.error) {
        button.slideUp();
        button.before(responseText.data.link);
      }

      button.unblock();


    });
  });

  $('#wc_szamlazz_already_back<?php echo $item[ 'ID' ]; ?>').click(function(e) {
    e.preventDefault();
    var r = confirm(""<?php _e('Biztosan visszakapcsolod a számlakészítés ennél a rendelésnél?','collectivedelivery'); ?>"");
    if (r != true) {
      return false;
    }

    var nonce = $(this).data('nonce');
    var order = $(this).data('order');
    var button = $('#wc-szamlazz-generate-button<?php echo $item[ 'ID' ]; ?>');

    var data = {
      action: 'wc_szamlazz_already_back',
      nonce: nonce,
      order: order
    };

    $('#szamlazz_already_div<?php echo $item[ 'ID' ]; ?>').block({
      message: null,
      overlayCSS: {
        background: '#fff url(' + wc_szamlazz_params.loading + ') no-repeat center',
        backgroundSize: '16px 16px',
        opacity: 0.6
      }
    });

    $.post(ajaxurl, data, function(response) {
      //Remove old messages
      $('.wc-szamlazz-message<?php echo $item[ 'ID' ]; ?>').remove();

      var responseText = response;

      //Generate the error/success messages
      if (responseText.data.error) {
        button.before('<div class="wc-szamlazz-error<?php echo $item[ 'ID' ]; ?> error wc-szamlazz-message<?php echo $item[ 'ID' ]; ?>"></div>');
      } else {
        button.before('<div class="wc-szamlazz-success<?php echo $item[ 'ID' ]; ?> updated wc-szamlazz-message<?php echo $item[ 'ID' ]; ?>"></div>');
      }

      //Get the error messages
      var ul = $('<ul>');
      $.each(responseText.data.messages, function(i, value) {
        var li = $('<li>')
        li.append(value);
        ul.append(li);
      });
      $('.wc-szamlazz-message<?php echo $item[ 'ID' ]; ?>').append(ul);

      //If success, show the button
      if (!responseText.data.error) {
        button.slideDown();
      }

      $('#szamlazz_already_div<?php echo $item[ 'ID' ]; ?>').unblock().slideUp();


    });
  });

  //Teljesítettnek jelölés
  $('#wc_szamlazz_generate_complete<?php echo $item[ 'ID' ]; ?>').click(function(e) {
    e.preventDefault();
    var r = confirm(""<?php _e('Biztosan teljesítve lett?','collectivedelivery'); ?>"");
    if (r != true) {
      return false;
    }

    var nonce = $(this).data('nonce');
    var order = $(this).data('order');
    var form = $('#wc-szamlazz-generate-button<?php echo $item[ 'ID' ]; ?>');
    var button = $(this);

    var data = {
      action: 'wc_szamlazz_complete',
      nonce: nonce,
      order: order
    };

    form.block({
      message: null,
      overlayCSS: {
        background: '#fff url(' + wc_szamlazz_params.loading + ') no-repeat center',
        backgroundSize: '16px 16px',
        opacity: 0.6
      }
    });

    $.post(ajaxurl, data, function(response) {
      //Remove old messages
      $('.wc-szamlazz-message<?php echo $item[ 'ID' ]; ?>').remove();

      var responseText = response;

      //Generate the error/success messages
      if (responseText.data.error) {
        form.before('<div class="wc-szamlazz-error<?php echo $item[ 'ID' ]; ?> error wc-szamlazz-message<?php echo $item[ 'ID' ]; ?>"></div>');
      } else {
        form.before('<div class="wc-szamlazz-success<?php echo $item[ 'ID' ]; ?> updated wc-szamlazz-message<?php echo $item[ 'ID' ]; ?>"></div>');
      }

      //Get the error messages
      var ul = $('<ul>');
      $.each(responseText.data.messages, function(i, value) {
        var li = $('<li>')
        li.append(value);
        ul.append(li);
      });
      $('.wc-szamlazz-message<?php echo $item[ 'ID' ]; ?>').append(ul);

      //If success, hide the button
      if (!responseText.data.error) {
        button.slideUp();
        button.before(responseText.data.link);
      }

      form.unblock();


    });
  });

  //Sztornózás
  $('#wc_szamlazz_generate_sztorno<?php echo $item[ 'ID' ]; ?>').click(function(e) {
    e.preventDefault();
    var r = confirm(""<?php _e('Biztosan sztornózva lesz?','collectivedelivery'); ?>"");
    if (r != true) {
      return false;
    }

    var nonce = $(this).data('nonce');
    var order = $(this).data('order');
    var form = $('#wc-szamlazz-generate-button<?php echo $item[ 'ID' ]; ?>');
    var button = $(this);

    var data = {
      action: 'wc_szamlazz_sztorno',
      nonce: nonce,
      order: order
    };

    form.block({
      message: null,
      overlayCSS: {
        background: '#fff url(' + wc_szamlazz_params.loading + ') no-repeat center',
        backgroundSize: '16px 16px',
        opacity: 0.6
      }
    });

    $.post(ajaxurl, data, function(response) {
      //Remove old messages
      $('.wc-szamlazz-message<?php echo $item[ 'ID' ]; ?>').remove();

      var responseText = response;

      //Generate the error/success messages
      if (responseText.data.error) {
        form.before('<div class="wc-szamlazz-error<?php echo $item[ 'ID' ]; ?> error wc-szamlazz-message<?php echo $item[ 'ID' ]; ?>"></div>');
      } else {
        form.before('<div class="wc-szamlazz-success<?php echo $item[ 'ID' ]; ?> updated wc-szamlazz-message<?php echo $item[ 'ID' ]; ?>"></div>');
      }

      //Get the error messages
      var ul = $('<ul>');
      $.each(responseText.data.messages, function(i, value) {
        var li = $('<li>')
        li.append(value);
        ul.append(li);
      });
      $('.wc-szamlazz-message<?php echo $item[ 'ID' ]; ?>').append(ul);

      //If success, hide the button
      if (!responseText.data.error) {
        button.slideUp();
        button.before(responseText.data.link);
        $('#wc-szamlazz-generated-data<?php echo $item[ 'ID' ]; ?>').slideUp();
      }

      form.unblock();

    });
  });

});
</script>
<?php	
}

    public function is_invoice_generated( $order_id ) {
		$invoice_name = get_post_meta($order_id,'_wc_szamlazz',true);
		$invoice_own = get_post_meta($order_id,'_wc_szamlazz_own',true);
		if($invoice_name || $invoice_own) {
			return true;
		} else {
			return false;
		}
	}

    function column_state( $item ) {
	$title=$item['state'];        
	if($item['state']=="close")
        $title = '<font color="red">'.__("Lezárt","collectivedelivery").'</font>';
        if($item['state']=="open"){
		strtotime($item['order_date']);
        	$title = '<font color="green">'.__("Folyamatban","collectivedelivery").'</font>';
	}
        return $title;
    }

    function column_ID( $item ) {
        $title = '<strong>' . $item['ID'] . '</strong>';
        return $title;
    }

    function column_value( $item ) {
        $order = new WC_Order($item[ 'ID' ]);
        return $order->get_formatted_order_total();
    }

    function column_name( $item ) {
        $title = '<strong>' . $item['name'] . '</strong>';
        return $title;
    }

    function column_order_date( $item ) {
        $_nonce = wp_create_nonce( 'sp_customer' );
        $title = '<strong>' . $item['order_date'] . '</strong>';
        
        $actions = ['details' => sprintf( '<a
        href="post.php?post=%s&action=edit">'.__("Részletek","collectivedelivery").'</a>', absint( $item['ID']
        ), $_nonce )];
        return $title . $this->row_actions($actions);
    }

    function column_post_date( $item ) {
        $_nonce = wp_create_nonce( 'sp_customer' );
        $now = time();
        $target = strtotime($item['post_date']);
        $diff = $now - $target;
        if ( $diff > 86400 ) {
            $title = '<strong>' . $item['post_date'] . ' <font color="red"> '.__("Letelt a 24 óra","collectivedelivery").'</font></strong>';
        }        
        else
            $title = '<strong>' . $item['post_date'] . '</strong>';
        return $title;
    }

    function column_members( $item ) {
        $_nonce = wp_create_nonce( 'sp_customer' );
        $collectiveID=get_post_meta($item['ID'],'collective_delivery_id',true);
	$title = $item['members'] ;
	$kezd=strpos($title, "{");
	$title=substr($title,$kezd+1);
	$title = str_replace("i:","",$title);
	$res_str = array_chunk(explode(";",$title),2);
	foreach( $res_str as &$val){
	   $val  = implode(",",$val);
	}
	$title= implode(" ; ",$res_str);
	$title = str_replace(","," = ",$title);
	$title=substr($title,0,strlen($title)-2);
        $actions = [
            'details' => sprintf( '<a
            href="?page=group_orders_list&action=%s&group=%s&_wpnonce=%s">Részletek</a>',
            'details', $collectiveID, $_nonce )
        ];
        return $title . $this->row_actions($actions);
    }

    protected function column_default( $item, $column_name ) {
	switch ( $column_name ) {
	    case 'ID':
            case 'post_date':
            case 'members':
            case 'state':
                return $item[ $column_name ];
            default:
                return print_r( $item, true );
        }
    }
	
    function prepare_items() {
	global $wpdb; 
	$per_page = 5;
	$columns  = $this->get_columns();
	$hidden   = array();
	$sortable = $this->get_sortable_columns();
	$this->_column_headers = array( $columns, $hidden, $sortable );
        if ( 'details' === $this->current_action() )
            $data = $this->get_orders();
        else
            $data = $this->get_customers();
        usort( $data, array( $this, 'usort_reorder' ) );
        $current_page = $this->get_pagenum();
        $total_items = count( $data );
        $data = array_slice( $data, ( ( $current_page - 1 ) * $per_page ), $per_page );
        $this->items = $data;
        $this->set_pagination_args( array(
            'total_items' => $total_items,                    
            'per_page'    => $per_page,  
            'total_pages' => ceil( $total_items / $per_page ), 
        ) );
    }	
    public function generate_download_link( $order_id, $payment_request = false, $sztorno = false ) {
        if($order_id) {
            if($payment_request) {
		$pdf_name = get_post_meta($order_id,'_wc_szamlazz_dijbekero_pdf',true);
            } 
            else 
                if($sztorno) {
                $pdf_name = get_post_meta($order_id,'_wc_szamlazz_sztorno_pdf',true);
            } 
                else {
                    $pdf_name = get_post_meta($order_id,'_wc_szamlazz_pdf',true);
                }
                $UploadDir = wp_upload_dir();
		$UploadURL = $UploadDir['baseurl'];
		$pdf_file_url = $UploadURL.'/wc_szamlazz/'.$pdf_name;
		return $pdf_file_url;
        } 
        else {
            return false;
	}
    }
}
