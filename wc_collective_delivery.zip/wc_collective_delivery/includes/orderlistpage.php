<div class="wrap">
<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
<form id="grouporder" method="get">
    <input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
    <?php $group_orders_table->display() ?>
    <?php if( $_GET["action"] == "details")
        e_('A gyűjtő szállítás összes résztvevőjének kezelése: ','collectivedelivery');
	echo "<br>";	
        if( $_GET["group"] ){
            if(implode(get_post_meta($_GET["group"] , 'collective_delivery_state', false ))=='open')
                _e("A rendelés még nincsen lezárva.","collectivedelivery");
            else {
		$cusarr[0]=$_GET["group"];
		$customers=get_post_meta($_GET["group"] , 'collective_delivery_join_orders', false );
		foreach ($customers as $values) {
			foreach ($values as $value) {
			$cusarr[]=$value;
			}
                } 
                $nincsszamlazva=false;                
                foreach ($cusarr as $value) {
                    $invoice_name = get_post_meta($value,'_wc_szamlazz',true);
                    if(!$invoice_name) {
			 $nincsszamlazva=true;
                    }    
                }          
                if($nincsszamlazva){
                ?>
                    <div style="text-align:left;" id="wc-szamlazz-generate-button-group">
                    <p>
                    <a href="#" id="wc_szamlazz_generate_group" data-nonce="<?php echo wp_create_nonce( "wc_generate_invoice" ); ?>" class="button button-primary" target="_blank"><?php _e('Számlakészítés','collectivedelivery'); ?>
                    </a><br>
                    <a href="#" id="wc_szamlazz_options_group"><?php _e('Opciók','colectivedelivery'); ?>
                    </a>
                    </p>
                    <div id="wc_szamlazz_options_form_group" style="display:none;">
			<div class="fields">
			<h4><?php _e('Megjegyzés','collectivedelivery'); ?></h4>
			<input type="text" id="wc_szamlazz_invoice_note_group" value="<?php echo get_option('wc_szamlazz_note'); ?>" />
			<h4><?php _e('Fizetési határidő(nap)','collectivedelivery'); ?></h4>
			<input type="text" id="wc_szamlazz_invoice_deadline_group" value="<?php echo get_option('wc_szamlazz_payment_deadline'); ?>" />
			<h4><?php _e('Teljesítés dátum','collectivedelivery'); ?></h4>
			<input type="text" class="date-picker" id="wc_szamlazz_invoice_completed_group" maxlength="10" value="<?php echo date('Y-m-d'); ?>" pattern="[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])">
			<h4><?php _e('Díjbekérő számla','collectivedelivery'); ?></h4>
			<input type="checkbox" id="wc_szamlazz_invoice_request_group" value="1" />
			</div>
                    </div>
                    </div>
</form>
</div>
<script type="text/javascript">
$(document).ready(function(){
$('#wc_szamlazz_generate_group').click(function(e) {
    e.preventDefault();
    var r = confirm(""<?php _e('Biztosan létrehozod a számlákat?','collectivedelivery'); ?>"");
    if (r != true) {
        return false;
    }
    var nonce = $(this).data('nonce');
    var order = 28329;
    var button = $('#wc-szamlazz-generate-button-group');
    var note = $('#wc_szamlazz_invoice_note_group').val();
    var deadline = $('#wc_szamlazz_invoice_deadline_group').val();
    var completed = $('#wc_szamlazz_invoice_completed_group').val();
    var request = $('#wc_szamlazz_invoice_request_group').is(':checked');
    if (request) {
        request = 'on';
    } 
    else {
        request = 'off';
    }
var ul = $('<ul>');
var hiba = 0; 
<?php
foreach ($cusarr as $value) {
    $invoice_name = get_post_meta($value,'_wc_szamlazz',true);
    if(!$invoice_name) {
?>
    var data<?php echo $value?> = {
        action: 'wc_szamlazz_generate_invoice',
        nonce: nonce,
        order: <?php echo $value?>,
        note: note,
        deadline: deadline,
        completed: completed,
        request: request
    };
    button.block({
        message: null,
        overlayCSS: {
            background: '#fff url(' + wc_szamlazz_params.loading + ') no-repeat center',
            backgroundSize: '16px 16px',
            opacity: 0.6
        }
    });
    $.post(ajaxurl, data<?php echo $value?>, function(response) {
        $('.wc-szamlazz-message-group').remove();
        var responseText = response;
        if (responseText.data.error) {
	    hiba = hiba+1;
        } 
        else {
        }
 
        $.each(responseText.data.messages, function(i, value) {
            var li = $('<li>');
            li.append(value);
            ul.append(li);
        });  
    });
<?php
}
//endif
}
//endforeach
?>
if(hiba==0){
    document.getElementById('successmessage').innerHTML += '<div class="updated"><ul><li>'.__("A számlák sikeresen létrehozva, megtekintésükhöz kérem frissítse az oldalt!","collectivedelivery").'<ul><li></div>';
    button.slideUp();
}
else{
    button.before('<div class="wc-szamlazz-error-group error wc-szamlazz-message-group"></div>');
    $('.wc-szamlazz-message-group').append(ul);
}
});

$('#wc_szamlazz_options_group').click(function() {
    $('#wc_szamlazz_options_form_group').slideToggle();
    return false;
});
});
</script>

<div id="successmessage"></div>
<?php
}
else
_e("Minden ügyfélnek ki lett állítva számla.","collectivedelivery");
}
}

?>
