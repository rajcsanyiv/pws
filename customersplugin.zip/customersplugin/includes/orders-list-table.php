<?php

class Customerorders_List_Table extends WP_List_Table {

    public static function get_customers( $per_page = 50, $page_number = 1 ) {
        global $wpdb;

$sql="SELECT count(orderposts.ID) as order_count, count(orderposts.ID) as order_count2,
        {$wpdb->prefix}users.ID, {$wpdb->prefix}users.user_nicename as name,
        {$wpdb->prefix}users.user_email as email,
        {$wpdb->prefix}users.user_status, {$wpdb->prefix}users.user_registered
        as registered FROM `{$wpdb->prefix}users`
        LEFT JOIN 
        (select * 
        FROM `{$wpdb->prefix}postmeta`
        LEFT JOIN {$wpdb->prefix}posts ON {$wpdb->prefix}posts.ID = {$wpdb->prefix}postmeta.post_id
        WHERE {$wpdb->prefix}postmeta.meta_key=\"_customer_user\" AND {$wpdb->prefix}posts.post_type=\"shop_order\")
        orderposts
        ON {$wpdb->prefix}users.ID = orderposts.meta_value";

        if ( isset( $_POST['s'] ) && $_POST['s']!="Nem volt rendelés" ) {
            $sql .= " WHERE ({$wpdb->prefix}users.user_email like
            '%".$_POST['s']."%' or {$wpdb->prefix}users.user_nicename like
            '%".$_POST['s']."%')";
        }
        $sql .= " group by {$wpdb->prefix}users.user_email";  

        if ( isset( $_POST['s'] ) && $_POST['s']=="Nem volt rendelés"){
            $sql .= " having count(orderposts.ID)<1";
        }

        if ( ! empty( $_REQUEST['orderby'] ) ) {
            $sql .= ' ORDER BY ' . esc_sql( $_REQUEST['orderby'] );
            $sql .= ! empty( $_REQUEST['order'] ) ? ' ' . esc_sql(
            $_REQUEST['order'] ) : ' ASC';
        }
        $sql .= " LIMIT $per_page";
        $sql .= ' OFFSET ' . ( $page_number - 1 ) * $per_page;
        $result = $wpdb->get_results( $sql, 'ARRAY_A' );
	return $result;
    }
     
public static function get_orders( $per_page = 50, $page_number = 1 ) {
        global $wpdb;

$sql2="SELECT {$wpdb->prefix}posts.ID, {$wpdb->prefix}posts.post_date as
        order_date, {$wpdb->prefix}users.user_nicename as name FROM
        `{$wpdb->prefix}users` left join `{$wpdb->prefix}postmeta` on
        {$wpdb->prefix}users.ID={$wpdb->prefix}postmeta.meta_value left join
        `{$wpdb->prefix}posts` on
        {$wpdb->prefix}posts.ID={$wpdb->prefix}postmeta.post_id WHERE
        post_type=\"shop_order\" AND meta_key=\"_customer_user\" AND
        {$wpdb->prefix}users.ID=".esc_sql( $_REQUEST['customer'] );
        if ( isset( $_POST['s'] ) ) {
            $sql2 .= "AND {$wpdb->prefix}users.user_email = \"".$_POST['s']."\"";
        }
        if ( ! empty( $_REQUEST['orderby'] ) ) {
            $sql2 .= ' ORDER BY ' . esc_sql( $_REQUEST['orderby'] );
            $sql2 .= ! empty( $_REQUEST['order'] ) ? ' ' . esc_sql(
            $_REQUEST['order'] ) : ' ASC';
        }
        $sql2 .= " LIMIT $per_page";
        $sql2 .= ' OFFSET ' . ( $page_number - 1 ) * $per_page;
        $result = $wpdb->get_results( $sql2, 'ARRAY_A' );
	return $result;
    }   

	public function __construct() {
		parent::__construct( array(
			'singular' => 'rendelés',     
			'plural'   => 'rendelések',    
			'ajax'     => false,       
		) );
	}

	
	public function get_columns() {
		if ( 'details' === $this->current_action() ) {
            $columns = ['name' => __( 'Név', 'sp' ),
                        'order_date' => __( 'Rendelés dátuma', 'sp' ),
                        'ID' => __( 'Rendelés értéke', 'sp' )];
        }
        else {
            $columns = [
            'name'    => __( 'Név' ),
            'email' => __( 'Email', 'sp' ),
            'user_status' => __( 'Státusz', 'sp' ),
            'order_count' => __( 'Rendelések', 'sp' ),
            'order_count2' => __( 'Rendelés', 'sp' ),
            'registered' => __( 'Hozzáadás dátuma', 'sp' )];
        }
        return $columns;
	}

	
	protected function get_sortable_columns() {
/*
	$sortable_columns = array(
            'name' => array( 'name', true ),
            'order_count' => array( 'order_count', false ),
            'order_count2' => array( 'order_count2', false ),
            'registered' => array( 'registered', false ));
        return $sortable_columns;
*/
	}

	
    function column_order_count( $item ) {
        $_nonce = wp_create_nonce( 'sp_customer' );
        $title = '<strong>' . $item['order_count'] . '</strong>';
        $actions = [
            'details' => sprintf( '<a
            href="?page=render_orders_list&action=%s&customer=%s&_wpnonce=%s">Részletek</a>',
            'details', absint( $item['ID'] ), $_nonce )
        ];
        return $title . $this->row_actions($actions);
    }

    function column_order_count2( $item ) {
        if($item['order_count2']==0)
        $title = '<font color="red">Nem volt rendelés</font>';
        if($item['order_count2']!=0)
        $title = '<font color="green">Volt rendelés</font>';
        return $title;
    }

    function column_name( $item ) {
        $title = '<strong>' . $item['name'] . '</strong>';
        return $title;
    }

function column_order_date( $item ) {
        $_nonce = wp_create_nonce( 'sp_customer' );
        $title = '<strong>' . $item['order_date'] . '</strong>';
        
        $actions = ['details' => sprintf( '<a
        href="post.php?post=%s&action=edit">Részletek</a>', absint( $item['ID']
        ), $_nonce )];
        return $title . $this->row_actions($actions);
    }


	protected function column_default( $item, $column_name ) {
		switch ( $column_name ) {
case 'ID':
                $order = new WC_Order($item[ $column_name ]);
                return $order->get_formatted_order_total();
            case 'user_status':
            case 'email':
            case 'order_count':
            case 'order_count2':
            case 'registered':
                return $item[ $column_name ];
            default:
                return print_r( $item, true );
        }
	}

	

	function prepare_items() {
		global $wpdb; 

		$per_page = 5;
		$columns  = $this->get_columns();
		$hidden   = array();
		$sortable = $this->get_sortable_columns();

		$this->_column_headers = array( $columns, $hidden, $sortable );
        if ( 'details' === $this->current_action() )
		$data = $this->get_orders();

else
		$data = $this->get_customers();
		usort( $data, array( $this, 'usort_reorder' ) );

		$current_page = $this->get_pagenum();

		$total_items = count( $data );

		$data = array_slice( $data, ( ( $current_page - 1 ) * $per_page ), $per_page );
		$this->items = $data;

		$this->set_pagination_args( array(
			'total_items' => $total_items,                    
			'per_page'    => $per_page,  
			'total_pages' => ceil( $total_items / $per_page ), 
		) );

	}

	
}
