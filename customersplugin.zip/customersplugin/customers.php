<?php
/*
Plugin Name: Customer Orders
Description: Customer orders list
Version: 1.5
Author: Viktor Rajcsányi / Promera
Author URI: http://promera.hu
Text Domain: customersorders
Domain Path: /languages
*/

$Customersorders_minimalRequiredPhpVersion = '5.0';

function Customersorders_noticePhpVersionWrong() {
    global $Customersorders_minimalRequiredPhpVersion;
    echo '<div class="updated fade">' .
      __('Error: plugin "Customersorders" requires a newer version of PHP to be running.',
      'customersorders').
            '<br/>' . __('Minimal version of PHP required: ', 'customersorders') .
            '<strong>' . $Customersorders_minimalRequiredPhpVersion . '</strong>' .
            '<br/>' . __('Your server\'s PHP version: ', 'customersorders') . '<strong>' .
            phpversion() . '</strong>' .
         '</div>';
}

function Customersorders_PhpVersionCheck() {
    global $Customersorders_minimalRequiredPhpVersion;
    if (version_compare(phpversion(), $Customersorders_minimalRequiredPhpVersion) < 0) {
        add_action('admin_notices', 'Customersorders_noticePhpVersionWrong');
        return false;
    }
    return true;
}

function Customersorders_i18n_init() {
    $pluginDir = dirname(plugin_basename(__FILE__));
    load_plugin_textdomain('customersorders', false, $pluginDir . '/languages/');
}

add_action('plugins_loaded','Customersorders_i18n_init');

if (Customersorders_PhpVersionCheck()) {
    include_once('Customersorders_init.php');
    Customersorders_init(__FILE__);
}
