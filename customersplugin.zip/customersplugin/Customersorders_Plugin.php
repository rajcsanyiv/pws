<?php

include_once('Customersorders_LifeCycle.php');

class Customersorders_Plugin extends Customersorders_LifeCycle {

    public function getOptionMetaData() {
        return array(
            'ATextInput' => array(__('Enter in some text', 'customersorders-plugin')),
            'AmAwesome' => array(__('I like this awesome plugin', 'customersorders-plugin'), 'false', 'true'),
            'CanDoSomething' => array(__('Which user role can do something', 'customersorders-plugin'), 'Administrator', 'Editor', 'Author', 'Contributor', 'Subscriber', 'Anyone')
        );
    }

    protected function initOptions() {
        $options = $this->getOptionMetaData();
        if (!empty($options)) {
            foreach ($options as $key => $arr) {
                if (is_array($arr) && count($arr > 1)) {
                    $this->addOption($key, $arr[1]);
                }
            }
        }
    }

    public function getPluginDisplayName() {
        return 'Customersorders';
    }

    protected function getMainPluginFileName() {
        return 'customersorders.php';
    }

    protected function unInstallDatabaseTables() {

    }

    public function upgrade() {
        
    }
    public function addActionsAndFilters() {
        add_action('admin_menu', array(&$this, 'addSettingsSubMenuPage'));
        add_action('admin_enqueue_scripts', function() {
//            wp_enqueue_style('admin-styles', plugins_url('css/admin.css', __FILE__));
//            wp_enqueue_script('admin-scripts', plugins_url('js/tooltip.min.js', __FILE__));
//            wp_enqueue_script('admin-scripts', plugins_url('js/admin.js', __FILE__));
        });
    }
}



